#include "slist.h"

//
// This is the implementation file for the SimpleList class.
// You will have to templatize this.
//

SimpleList::SimpleList(int sz) {
  size = sz;
  array = new int[size];
  n = 0;
}

// Sort does a very simple sort - a bubble sort that's not
// very efficient.
void SimpleList::sort() {
  int i, j;
  for (i = 1; i < n; i++)
    for (j = i; ((j > 0) && (array[j] < array[j - 1])); j--)
      swap(array[j], array[j - 1]);
}
 
void SimpleList::print(ofstream & of) {
  int i;
  for (i = 0; i < n; i++)
    of << array[i] << endl;
}
 
bool SimpleList::append(int x) {
  if (n == size)
    return false;
  array[n++] = x;
  return true;
}
