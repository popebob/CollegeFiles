﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace Kitchenv2
{
    public partial class mealbrowser : Form
    {
        //connection string to open new connection
        SqlConnection con = new SqlConnection(@"Data Source=WINB83-LAPTOP\SQLEXPRESS; Initial Catalog=Kitchen; Integrated Security=True");
        //dataadapter for commuinicating with sql data base
        SqlDataAdapter da = new SqlDataAdapter();
        //used to make sql commands
        SqlCommand cmd;
        public static Form1.mealitem [] tempmeal; //temp meal
        public static int cartremoveindex; //index of the array to be removed from cart
        //int tempcartq;
        //display the meal
        public void viewMeal()
        {
            //clear listbox
            listBox1.Items.Clear();
            //go through food item array and add items to listbox
            for (int i = 0; i <= Form1.cartc; i++)
            {
                //listBox1.Items.Add("Food # " + i + " " + Form1.cartf[i] + " " + Form1.cartq[i] + " servings");
                listBox1.Items.Add(Form1.meal[i].name + " " + Form1.meal[i].quantity + " servings");
            }

        }
        //remove an item from the cart. uses temp arrays to skip item removed and reset array
        public void deleteMeal()
        {
            tempmeal = Form1.meal; //temp cart array set to real cart            
            string removeditem; //used to store item to be removed
            removeditem = listBox1.SelectedItem.ToString();
            //finds the index of the item to be removed in the array and saves it
            for (int i = 0; i <= Form1.cartc; i++)
            {
                if (tempmeal[i].name == removeditem)
                    cartremoveindex = i;

            }
            //rebuilds the array without the removed item. if removed item is found it is skipped in the rebuilding
            for (int i = 0; i <= Form1.cartc; i++)
            {
                //as long as current item isn't item to be removed add it to the cart
                if (i != cartremoveindex)
                {
                    Form1.meal[i] = tempmeal[i];
                    //Form1.cartq[i] = Form1.tempcartq[i];
                }
                //if current item is to be removed skip it
                if (i == cartremoveindex)
                    i++;
            }
            //dec the cart count since it is one item smaller now
            Form1.cartc--;
            //clear then reset the listbox
            listBox1.Items.Clear();
            viewMeal();
        }
        //remove food items from db and reset meal
        public void checkOut()
        {
            //go through cart and update the counts
            for (int i = 0; i <= Form1.cartc; i++)
            {
                //sql command to remove item from table
                cmd = new SqlCommand("UPDATE tblFood SET quantity = @quantity WHERE Foodname = @Foodname", con);
                cmd.Parameters.Add("@Foodname", SqlDbType.VarChar).Value = Form1.meal[i].name;
                cmd.Parameters.Add("@quantity", SqlDbType.Int).Value = Form1.meal[i].quantity;
                //open connection remove item and close connection
                con.Open();
                da.UpdateCommand = cmd;
                da.UpdateCommand.ExecuteNonQuery();
                con.Close();
            }
            //reset cart to nothing
            Form1.meal = new Form1.mealitem[100];
            //set cart count to be nothing
            Form1.cartc = -1;
            //close form
            Close();
        }
        //lets user change the number of items in the cart
        public void editMeal()
        {
            //gets input from input box
            string newq = Microsoft.VisualBasic.Interaction.InputBox("Enter new quantity", "text", "", 10, 20);
            //sets item to be changed to current selection
            string changeitem = listBox1.SelectedItem.ToString();
            bool test1; //used to find item to be changed
            //goes through array and finds item to be changed
            for (int i = 0; i <= Form1.cartc; i++)
            {
                test1 = changeitem.StartsWith(Form1.meal[i].name);
                if (test1)
                    //if found changes item
                    Form1.meal[i].quantity = Convert.ToInt32(newq);

            }
            //display updated meal
            viewMeal();
        }
        public mealbrowser()
        {
            InitializeComponent();
            viewMeal();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            deleteMeal();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            editMeal();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            checkOut();
        }
    }
}
