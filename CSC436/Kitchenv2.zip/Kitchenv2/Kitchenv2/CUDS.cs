﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using System.IO;

namespace Kitchenv2
{
    public partial class CUDS : Form
    {
        private Form1 mainForm; //handle for main form
        DataSet ds = new DataSet(); //dataset from database
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeDataAdapter da = new SqlCeDataAdapter(); //for communicating with database
        SqlCeCommand command; //sql command
        string username; //used to store username from account form        
        bool hasicon; //does the user have an icon?
        bool frommain; //was this called from the main form
        public static string currentuser; //used to store current user
        int loginflag; //used to set current user to  user in db or default user

        OpenFileDialog ofd;
        //used if logged in to view info
        public CUDS()
        {
            InitializeComponent();
            cmdEditUser.Enabled = false;
        }
        //used if viewing account info
        public CUDS(string uname)
        {
            InitializeComponent();
            username = uname;
            cmdCreateUser.Visible = false;
            cmdEditUser.Visible = true;
            showuser();
            showicon();

        }
        public CUDS(string uname, Form1 main)
        {
            InitializeComponent();
            username = uname;
            frommain = true;
            mainForm = main;
            cmdCreateUser.Visible = false;
            cmdEditUser.Visible = true;
            showuser();
            showicon();

        }

        //from CUDS

        public CUDS(Form1 m)
        {
            InitializeComponent();
            mainForm = m;
            loginflag = 0;
            currentuser = "defaultuser";
            hasicon = false;
        }
        public CUDS(Form1 m, string u)
        {
            InitializeComponent();
            mainForm = m;
            loginflag = 0;
            currentuser = u;
            hasicon = false;
        }
        void showusers()    
        {
            con.Open();
            command = new SqlCeCommand("SELECT * FROM tblUser", con);
            da = new SqlCeDataAdapter(command);                        
            ds.Clear();
            da.Fill(ds);
            datUsers.DataSource = ds.Tables[0];
            con.Close();
            txtUserName.Text = currentuser;
            //need to also populate other fields
        }
        void showusericon()
        {
            MemoryStream m = null;
            con.Open();
            //code to show image again
            byte[] photo;
            //command to get all users from the user table
            command = new SqlCeCommand("SELECT * FROM tblUser WHERE UserName = @UserName", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@UserName"].Size = 100;
            command.Parameters[0].Value = CUDS.currentuser;
            command.Prepare();
            SqlCeDataReader reader = null;
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {

                photo = (byte[])reader[7];
                m = new MemoryStream(photo);
            }

            picUserIcon.Image = Image.FromStream(m);
            con.Close();

        }

        //user removes account
        void deleteuser()
        {
            //gets user name from inputbox
            //username = Microsoft.VisualBasic.Interaction.InputBox("Enter User Name To Delete", "text", "", 10, 20);
            //uses username to search database and delete
            if (datUsers.CurrentRow.Cells[0].Value.ToString() == currentuser)
            {
                MessageBox.Show("Cannot delete the logged-in user.  Log out and try again.");
                con.Close();
                return;
            }
              
            //open the connection 
            con.Open();
            //set command to remove the row the user has selected by using the uusername
            command = con.CreateCommand();
            command.CommandText = "Delete FROM tblUser WHERE ID = @ID";
            //set Parameter
            SqlCeParameter param = null;
            param = new SqlCeParameter("@ID", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@ID"].Size = 100;
            command.Prepare();
            //set Parameter value
            //old way   command.Parameters[0].Value = datUsers.CurrentRow.Cells[0].Value.ToString();
            int row = Convert.ToInt32(datUsers.CurrentRow.Index);
            command.Parameters[0].Value = (int)ds.Tables[0].Rows[row].ItemArray[0];
            //MessageBox.Show(datUsers.CurrentRow.Cells[0].Value.ToString());
            command.ExecuteNonQuery();
            command = con.CreateCommand();
            //refill the datagrid and show it again
            command.CommandText = "SELECT * FROM tblUser";
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            datUsers.DataSource = ds.Tables[0];
            con.Close();
            //confirm account removed
            MessageBox.Show("Account " + username + " removed.");
        }

        //change user account
        void switchuser()
        {
            if (ds.Tables[0].Rows.Count != 0)
            {
                currentuser = datUsers.CurrentRow.Cells[0].Value.ToString();

                MemoryStream m = null;
                con.Open();
                //code to show image again
                byte[] photo;
                //command to get all users from the user table
                command = new SqlCeCommand("SELECT * FROM tblUser WHERE UserName = @UserName", con);
                SqlCeParameter param = null;
                param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@UserName"].Size = 100;
                command.Parameters[0].Value = currentuser;
                command.Prepare();
                SqlCeDataReader reader = null;
                reader = command.ExecuteReader();
                //if pass user found show message
                while (reader.Read())
                {
                    if (reader[7] != DBNull.Value)
                    {
                        photo = (byte[])reader[7];
                        m = new MemoryStream(photo);
                        hasicon = true;
                    }
                }
                if (!hasicon)
                {
                    picUserIcon.Image = null;
                    Form1.usericon = null;
                    hasicon = false;

                }
                if (hasicon)
                {
                    picUserIcon.Image = Image.FromStream(m);
                    Form1.usericon = (Bitmap)picUserIcon.Image;
                    hasicon = false;

                }
                con.Close();

            }
            mainForm.showmain();
            mainForm.showicon();
        }

        private void cmdSwitchUser_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
            {
                //change user account
                switchuser();
                showusers();
                cmdChangeUser.Enabled = true;
                cmdEditUser.Visible = true;
                monthCalendar1.Enabled = true;
                string cd = DateTime.Now.ToString("M/d/yyyy");
                txtDate.Text = cd;
                showByUserDate();
                int total = 0;
                int total2 = 0;
                for (int i = 0; i < datDailyLog.Rows.Count; i++)
                {
                    //total2 = (int)datDailyLog.Rows[i].Cells[5].Value * (int)datDailyLog.Rows[i].Cells[6].Value;
                    total2 = Convert.ToInt32(datDailyLog.Rows[i].Cells[5].Value) * Convert.ToInt32(datDailyLog.Rows[i].Cells[6].Value);
                    total += total2;
                }
                label6.Text = total.ToString();
                cmdRemoveUser.Enabled = false;
                cmdEditIcon.Enabled = true;
                cmdLogOut.Enabled = true;
                mainForm.showicon();
            }
        }

        private void cmdEditIcon_Click(object sender, EventArgs e)
        {
            addicon();
            showicon();
            //display user accounts
            showusers();
            mainForm.showicon();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
                //delete user
                deleteuser();
            //reshow user table
            showusers();
        }

        private void accounts_Load(object sender, EventArgs e)
        {
            con.Open();
            command = new SqlCeCommand("SELECT * FROM tblUser", con);
            da = new SqlCeDataAdapter(command);
            ds = new DataSet();
            ds.Clear();
            da.Fill(ds);
            datUsers.DataSource = ds.Tables[0];
            datUsers.Columns.Remove(datUsers.Columns[0]);
            datUsers.Columns.Remove(datUsers.Columns[1]);
            datUsers.Columns.Remove(datUsers.Columns[2]);
            datUsers.Columns.Remove(datUsers.Columns[3]);
            datUsers.Columns.Remove(datUsers.Columns[3]);
            datUsers.Columns.Remove(datUsers.Columns[1]);
            con.Close();
            //currentuser = userlogon();
            //currentuser = "defaultuser";
            label2.Text = currentuser;            
        }


        private void cmdClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cmdCreateUser_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text != "")
            {
                //add user
                adduser();
                //accountinfo ai = new accountinfo();
                //ai.ShowDialog();
                //show user table
                showusers();
            }
            else
            {
                MessageBox.Show("Enter a new user name!");
                txtUserName.Focus();
            }
            cmdCreateUser.Enabled = false;
            cmdNewUser.Enabled = true;

        }

        //end from CUDS

        //from logview
                
        static DataGridViewHeaderBorderStyle ProperColumnHeadersBorderStyle
        {
            get
            {
                return (SystemFonts.MessageBoxFont.Name == "Segoe UI") ?
                    DataGridViewHeaderBorderStyle.Single :
                    DataGridViewHeaderBorderStyle.Raised;
            }
        }

        //fill grid bu user
        void showByUser()
        {
            //open connection
            con.Open();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //set sql command
            command = new SqlCeCommand("SELECT * FROM tbllog where userid = @userid", con);
            //set parameter
            SqlCeParameter param = null;
            param = new SqlCeParameter("@userid", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@userid"].Size = 100;
            command.Prepare();
            //set parameter value
            command.Parameters[0].Value = currentuser;
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            datUsers.DataSource = ds.Tables[0];
            //close connection
            con.Close();
        }
        
        /*Not needed ??
        //fill grid by date
        void showByDate()
        {
            //open connection
            con.Open();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //set sql command
            command = new SqlCeCommand("SELECT * FROM tbllog where date = @date", con);
            //set parameter
            SqlCeParameter param = null;
            param = new SqlCeParameter("@date", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@date"].Size = 100;
            command.Prepare();
            //set parameter value
            command.Parameters[0].Value = txtDate.Text;
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            datUsers.DataSource = ds.Tables[0];
            //close connection
            con.Close();
        }
        end Not Needed ?? */

        //show results by user and date
        void showByUserDate()
        {
            //open connection
            con.Open();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //set sql command
            command = new SqlCeCommand("SELECT * FROM tbllog WHERE date = @date AND userid = @userid", con);
            //set parameters
            SqlCeParameter param = null;
            param = new SqlCeParameter("@date", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@userid", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@date"].Size = 100;
            command.Parameters["@userid"].Size = 100;            
            command.Prepare();
            //set parameter values
            command.Parameters[0].Value = txtDate.Text;
            command.Parameters[1].Value = currentuser;
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            datDailyLog.DataSource = ds.Tables[0];
            con.Close();

        }

        /*moved to CUDS_Load
        private void logview_Load(object sender, EventArgs e)
        {
            //nothing here at the moment
            monthCalendar1.MaxSelectionCount = 1;
            dataGridView1.Columns.Remove(dataGridView1.Columns[4]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[0]);

        }
        end of moved to CUDS_Load*/
        
       private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {            
            txtDate.Text = e.Start.ToShortDateString();     
            showByUserDate();
           int total = 0;
           int total2 = 0;
            for (int i = 0; i < datDailyLog.Rows.Count; i++)
            {
                //total2 = (int)datDailyLog.Rows[i].Cells[5].Value * (int)datDailyLog.Rows[i].Cells[6].Value;
                total2 = Convert.ToInt32(datDailyLog.Rows[i].Cells[5].Value) * Convert.ToInt32(datDailyLog.Rows[i].Cells[6].Value);
                total += total2;
            }
            label6.Text = total.ToString();
        }

        //end from logview

        //user adds account to database

        void adduser()
        {
            username = txtUserName.Text;
            //open connection and do command
            con.Open();
            //get user name and password to add to database
            //username = Microsoft.VisualBasic.Interaction.InputBox("Enter User Name", "text", "", 10, 20);
            //userpass = Microsoft.VisualBasic.Interaction.InputBox("Enter User Password", "text", "", 10, 20);
            //insert command for sql database places username and password into table
            command = con.CreateCommand();
            command.CommandText = "INSERT INTO tblUser (username, weight, height, age, dailycalcount, lastdateused ) VALUES (@username, @weight, @height, @age, @dailycalcount, @lastdateused)";
            //set parameters
            SqlCeParameter param = null;
            param = new SqlCeParameter("@username", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@weight", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@height", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@age", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@dailycalcount", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@lastdateused", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            //set parameter values
            command.Parameters[0].Value = txtUserName.Text;
            command.Parameters[1].Value = txtWeight.Text;
            command.Parameters[2].Value = txtHeight.Text;
            command.Parameters[3].Value = txtAge.Text;
            command.Parameters[4].Value = 0;
            command.Parameters[5].Value = "3/31/2010";
            command.ExecuteNonQuery();
            //confirm account added
            MessageBox.Show("Account " + username + " created.");
            con.Close();
        }
        //edit user info
        void edituser()
        {
            //open connection and do command
            con.Open();
            //get user name and password to add to database
            //username = Microsoft.VisualBasic.Interaction.InputBox("Enter User Name", "text", "", 10, 20);
            //userpass = Microsoft.VisualBasic.Interaction.InputBox("Enter User Password", "text", "", 10, 20);
            //insert command for sql database places username and password into table
            command = con.CreateCommand();
            command.CommandText = "UPDATE tblUser SET weight = @weight, height = @height, age = @age WHERE UserName = @UserName";
            //set parameters
            SqlCeParameter param = null;
            param = new SqlCeParameter("@weight", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@height", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@age", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@username", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            //set parameter values
            command.Parameters[0].Value = txtWeight.Text;
            command.Parameters[1].Value = txtHeight.Text;
            command.Parameters[2].Value = txtAge.Text;
            command.Parameters[3].Value = currentuser;
            command.ExecuteNonQuery();
            //confirm account added
            MessageBox.Show("Account " + username + " updated.");
            con.Close();
        }

        //get user info from user db
        void showuser()
        {
            con.Open();
            //MessageBox.Show(s[i]);
            //cmd = new SqlCommand(s[i], con);
            command = new SqlCeCommand("SELECT * FROM tblUser where username = @username", con);
            //cmd.Parameters.Add("@" + colnames[i], SqlDbType.VarChar).Value = textBox12.Text;
            SqlCeParameter param = null;
            param = new SqlCeParameter("@username", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = username;
            //MessageBox.Show(recipefrommeal[j].name + " " + recipefrommeal[j].quantity.ToString());
            SqlCeDataReader reader = null;

            //execute the search and save results in reader
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {

                //username, weight, height, age, dailycalcount, lastdateused 
                //show username
                txtUserName.Text = reader[1].ToString();
                //show user age
                txtAge.Text = reader[4].ToString();
                //show user weight
                txtWeight.Text = reader[2].ToString();
                //show user height
                txtHeight.Text = reader[3].ToString();
            }
            con.Close();


        }

        void addicon()
        {
            try
            {
                ofd = new OpenFileDialog();
                if (ofd.ShowDialog() == DialogResult.OK)
                {


                    textBox5.Text = ofd.FileName;

                    byte[] photo = File.ReadAllBytes(textBox5.Text);

                    con.Open();
                    command = con.CreateCommand();
                    command.CommandText = "UPDATE tblUser SET icon = @icon WHERE UserName = @UserName";
                    SqlCeParameter param = null;
                    param = new SqlCeParameter("@icon", SqlDbType.VarBinary, 8000);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    command.Parameters["@UserName"].Size = 100;
                    command.Parameters[0].Value = photo;
                    command.Parameters[1].Value = CUDS.currentuser;
                    command.Prepare();
                    //execute the command and update the daily calories
                    command.ExecuteNonQuery();
                    MessageBox.Show("Data inserted");
                    con.Close();
                    
                    
                }
            }
            catch (Exception e2)
            {
                MessageBox.Show("Error adding icon");
                MessageBox.Show(e2.ToString());
            }

        }
        void showicon()
        {
            MemoryStream m = null;            
            con.Open();
            //code to show image again
            byte[] photo;
            //command to get all users from the user table
            command = new SqlCeCommand("SELECT * FROM tblUser WHERE UserName = @UserName", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@UserName"].Size = 100;
            command.Parameters[0].Value = CUDS.currentuser;
            command.Prepare();
            SqlCeDataReader reader = null;
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {
                if (reader[7] != DBNull.Value)
                {
                    photo = (byte[])reader[7];
                    //pictureBox1.Image = (Image)reader[10];
                    m = new MemoryStream(photo);
                    hasicon = true;
                }
            }
            if (hasicon)
            {
                picUserIcon.Image = Image.FromStream(m);
                Form1.usericon = (Bitmap)picUserIcon.Image;
                if (frommain)
                    mainForm.showicon();

            }
            else
                MessageBox.Show("User doesn't have an icon");

            con.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adduser();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addicon();
            showicon();
        }

        private void cmdViewIcon_Click(object sender, EventArgs e)
        {
            showicon();
        }

        private void cmdEditUser_Click(object sender, EventArgs e)
        {
            try
            {
                edituser();
            }
            catch (Exception e3)
            {
                MessageBox.Show("Error");
                MessageBox.Show(e3.ToString());
            }
            cmdEditUser.Enabled = false;
            cmdEditIcon.Enabled = false;
            txtUserName.Enabled = false;
            txtWeight.Enabled = false;
            txtHeight.Enabled = false;
            txtAge.Enabled = false;
            cmdChangeUser.Enabled = true;
        }

        private void CUDS_Load(object sender, EventArgs e)
        {
            if (currentuser == "defaultuser")
            {
                cmdEditUser.Enabled =false;
                cmdEditIcon.Enabled = false;
                monthCalendar1.Enabled = false;
                cmdRemoveUser.Enabled = true;
                cmdLogOut.Enabled = false;

            }
            else
            {
                cmdChangeUser.Enabled = true;
                cmdRemoveUser.Enabled = false;
                cmdLogOut.Enabled = true;
            }
            //show user table
            showusers();

            //from logview_load
            //nothing here at the moment
            monthCalendar1.MaxSelectionCount = 1;
            datUsers.Columns.Remove(datUsers.Columns[7]);
            datUsers.Columns.Remove(datUsers.Columns[6]);
            datUsers.Columns.Remove(datUsers.Columns[5]);
            datUsers.Columns.Remove(datUsers.Columns[0]);
            //end from logview_load

        }

        private void cmdRemoveUser_Click(object sender, EventArgs e)
        {
            //deleteuser();
            if (ds.Tables[0].Rows.Count != 0)
                //delete user
                deleteuser();
            //reshow user table
            showusers();
        }

        private void cmdNewUser_Click(object sender, EventArgs e)
        {
            cmdChangeUser.Enabled = false;
            txtUserName.Enabled = true;
            txtAge.Enabled = true;
            txtHeight.Enabled = true;
            txtWeight.Enabled = true;
            cmdCreateUser.Enabled = true;
            cmdNewUser.Enabled = false;
            txtUserName.Text = "";
            txtUserName.Focus();
            cmdSwitchUser.Enabled = false;
            cmdRemoveUser.Enabled = false;
        }

        private void cmdChangeUser_Click(object sender, EventArgs e)
        {
            txtUserName.Enabled = true;
            txtAge.Enabled = true;
            txtHeight.Enabled = true;
            txtWeight.Enabled = true;
            cmdEditUser.Enabled = true;
            cmdChangeUser.Enabled = false;
            cmdEditIcon.Enabled = true;
        }

        private void cmdLogOut_Click(object sender, EventArgs e)
        {
            currentuser = "defaultuser";
            showusers();
            mainForm.showmain();
            Close();
        }
    }
}