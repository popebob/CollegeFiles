﻿//this file is commented

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Timers;
using System.Data.SqlServerCe;
namespace Kitchenv2
{
    public partial class logview : Form
    {
        DataSet ds = new DataSet(); //data set from SQL database
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeDataAdapter da = new SqlCeDataAdapter(); //for communicating with database //used to communicate with SQL database
        SqlCeCommand command; //sql command
        string userid; //userid for search

        //for when a user other than default user is logged on
        public logview(string uid)
        {
            InitializeComponent();
            //set the user id to the current user
            userid = uid;
            //show table based on user
            showByUser();
            gridDailyLog.ColumnHeadersBorderStyle = ProperColumnHeadersBorderStyle;
            
        }

        static DataGridViewHeaderBorderStyle ProperColumnHeadersBorderStyle
        {
            get
            {
                return (SystemFonts.MessageBoxFont.Name == "Segoe UI") ?
                    DataGridViewHeaderBorderStyle.Single :
                    DataGridViewHeaderBorderStyle.Raised;
            }
        }

        //fill grid bu user
        void showByUser()
        {
            //open connection
            con.Open();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //set sql command
            command = new SqlCeCommand("SELECT * FROM tbllog where userid = @userid", con);
            //set parameter
            SqlCeParameter param = null;
            param = new SqlCeParameter("@userid", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@userid"].Size = 100;
            command.Prepare();
            //set parameter value
            command.Parameters[0].Value = userid;
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            //close connection
            con.Close();
        }
        //fill grid by date
        void showByDate()
        {
            //open connection
            con.Open();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //set sql command
            command = new SqlCeCommand("SELECT * FROM tbllog where date = @date", con);
            //set parameter
            SqlCeParameter param = null;
            param = new SqlCeParameter("@date", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@date"].Size = 100;
            command.Prepare();
            //set parameter value
            command.Parameters[0].Value = textBox2.Text;
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            //close connection
            con.Close();

        }
        //show results bu user and date
        void showByUserDate()
        {
            //open connection
            con.Open();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //set sql command
            command = new SqlCeCommand("SELECT * FROM tbllog WHERE date = @date AND userid = @userid", con);
            //set parameters
            SqlCeParameter param = null;
            param = new SqlCeParameter("@date", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@userid", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@date"].Size = 100;
            command.Parameters["@userid"].Size = 100;            
            command.Prepare();
            //set parameter values
            command.Parameters[0].Value = textBox2.Text;
            command.Parameters[1].Value = userid;
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();

        }

        private void logview_Load(object sender, EventArgs e)
        {
            //nothing here at the moment
            monthCalendar1.MaxSelectionCount = 1;
            dataGridView1.Columns.Remove(dataGridView1.Columns[4]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[0]);

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {            
            //if there is something in the textbox
            if (userid == "" && textBox2.Text != "")
            {                
                //display the results for that user if thye exist
                showByDate();
            }
            //if userid and date entered
            else if (userid != "" && textBox2.Text != "")
            {
                //show everything for given user by given date
                showByUserDate();
            }
            //if there is nothing in the textbox
            //else
                //show everything
                //showAll();

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            textBox2.Text = e.Start.ToShortDateString() ;
            

        }

   }
}
