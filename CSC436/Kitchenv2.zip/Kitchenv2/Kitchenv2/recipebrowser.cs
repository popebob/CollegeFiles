﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlServerCe;

namespace Kitchenv2
{
    public partial class recipebrowser : Form
    {
        DataSet ds = new DataSet();

        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeDataAdapter da = new SqlCeDataAdapter(); //for communicating with database //used to communicate with SQL database
        //SqlCommand cmd;
        SqlCeCommand command; //sql command
        SqlCommand cmd;
        string[] rnames; //names where string search is found
        string[] colnames;
        Form1.recipefooditem[] recipeitems; //used to build a cart with recipe items to test against food db
        Form1.recipefooditem[] recipefrommeal; //used to hole food items from meal
        Form1.reciperating[] rate; //used to rate recipes
        Form1.reciperating[] instock; //used to check instock status
        Form1.fooditem[] fds; //used to recieve food item array from form 1
        private Form1 mainForm; //handle for first form
        int count; //number of items in meal

        public recipebrowser(Form1.fooditem [] f, Form1 f1)
        {
            colnames = new string[10] { "ingredient1", "ingredient2", "ingredient3", "ingredient4", "ingredient5", "ingredient6", "ingredient7", "ingredient8", "ingredient9", "ingredient10" };
            rnames = new string[100];
            InitializeComponent();
            fds = f;
            mainForm = f1;
            stockRecipes();
        }

        public recipebrowser(Form1.recipefooditem[] r, Form1 f1, int c, Form1.fooditem[] f)
        {
            colnames = new string[10] { "ingredient1", "ingredient2", "ingredient3", "ingredient4", "ingredient5", "ingredient6", "ingredient7", "ingredient8", "ingredient9", "ingredient10" };
            rnames = new string[100];
            InitializeComponent();
            recipefrommeal = r;
            mainForm = f1;
            count = c;
            fds = f;
            rateRecipes();
        }

        void rateRecipes()
        {
            //show recipes in the data grid
            showRecipe();
            //struct for holding recipe ratings
            //should be more than 10?
            rate = new Form1.reciperating[10];
            //get all the recipe names and store them in the rating item
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                rate[k].name = ds.Tables[0].Rows[k].ItemArray[1].ToString();                
            }
            //string array for creating sql commands array
            string[] s = new string[9];
            //calls string maker to create sql command array
            s = stringmakerv2(9, colnames);
            //extrnal for loop to control
            for (int j = 0; j <= count; j++)
            {
                //internal loop to control sql command stringarray
                for (int i = 0; i <= 9; i++)
                {
                    //open connection
                    con.Open();
                    //create a new sql command based on the given array element
                    command = new SqlCeCommand(s[i], con);
                    //create sql Parameter
                    SqlCeParameter param = null;
                    //set sql Parameter
                    param = new SqlCeParameter("@" + colnames[i], SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@" + colnames[i] + "q", SqlDbType.Int);
                    command.Parameters.Add(param);
                    command.Prepare();
                    //set sql Parameter values
                    command.Parameters[0].Value = recipefrommeal[j].name;
                    command.Parameters[1].Value = recipefrommeal[j].quantity;
                    //reader to read from the recipe table
                    SqlCeDataReader reader = null;

                    //execute the search and save results in reader
                    reader = command.ExecuteReader();
                    //if the correct result is found
                    while (reader.Read())
                    {
                        int u = 0; //u is used to save the correct element in the rating array
                        bool wasfound = false; //was the recipe already found? set to false
                        //searches to see if recipe is already added to the rating array
                        for (int k = 0; k <= ds.Tables[0].Rows.Count; k++)
                        {
                            //if the recipe is found
                            if (rate[k].name == reader["name"].ToString())
                            {
                                //set was found to true 
                                wasfound = true;
                                u = k; //used to save spot where item found
                            }
                        }
                        //if the recipe was found increase the rating
                        if (wasfound)
                            rate[u].rating++;
                        //if it wasn't already in the rating array add it and increase the rating
                        else
                        {
                            rate[i].name = reader["name"].ToString();
                            rate[i].rating++;
                        }
                    }
                    //close the connection
                    con.Close();
                }

            }
            //external loop goes through the entire food array
            for (int j = 0; j < fds.Length; j++)
            {
                //internal loop goes through the sql commands
                for (int i = 0; i <= 9; i++)
                {
                    con.Open();
                    //command inc through sql command string array
                    command = new SqlCeCommand(s[i], con);
                    //create new sql Parameter
                    SqlCeParameter param = null;
                    //set up parameters
                    param = new SqlCeParameter("@" + colnames[i], SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@" + colnames[i] + "q", SqlDbType.Int);
                    command.Parameters.Add(param);
                    command.Prepare();
                    //set parameter values
                    command.Parameters[0].Value = fds[j].name;
                    command.Parameters[1].Value = fds[j].quantity;
                    //reader for reading through the table
                    SqlCeDataReader reader = null;
                    //execute the search and save results in reader
                    reader = command.ExecuteReader();
                    //if recipe name found
                    while (reader.Read())
                    {
                        int u = 0;
                        bool wasfound = false;
                        for (int k = 0; k <= ds.Tables[0].Rows.Count; k++)
                        {
                            //int o = String.Compare(instock[k].name, reader["name"].ToString(), true);
                            //if the two items are the same
                            if (rate[k].name == reader["name"].ToString())
                            {
                                wasfound = true;
                                u = k; //used to save spot where item found
                            }
                        }

                        if (wasfound)
                            rate[u].instock++;
                        else
                        {
                            MessageBox.Show("This should never happen.");
                            rate[i].name = reader["name"].ToString();
                            rate[i].instock++;
                        }
                    }
                    con.Close();
                }

            }
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                //opne connection
                con.Open();
                //make new sql command
                command = con.CreateCommand();
                //command changes rating in the table
                command.CommandText = "UPDATE tblRecipe SET rating = @rating WHERE name = @name";
                //new sql parameter
                SqlCeParameter param = null;
                //set up sql parameter values
                param = new SqlCeParameter("@rating", SqlDbType.Int);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@name", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@name"].Size = 100;
                command.Prepare();
                //set parameter values
                int finalrating = rate[k].rating + rate[k].instock;
                if(count > 0)
                command.Parameters[0].Value = finalrating / count;
                else
                command.Parameters[0].Value = finalrating;
                command.Parameters[1].Value = rate[k].name;
                //execute sql command
                command.ExecuteNonQuery();
                ds = new DataSet();
                da = new SqlCeDataAdapter();
                //new command to show all instock and high rated items
                command = new SqlCeCommand("SELECT * FROM tblRecipe ORDER BY rating", con);
                //refill the datagrid and show it 
                da = new SqlCeDataAdapter(command);
                ds.Clear();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                //close connection
                con.Close();

            }
        }
        //check all recipe in stock status
        void stockRecipes()
        {
            //fill the datagrid
            showRecipe();
            //struct for holding recipe ratings
            //should be more than 10?
            instock = new Form1.reciperating[10];
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                instock[k].name = ds.Tables[0].Rows[k].ItemArray[1].ToString();
                
            }
            string[] s = new string[9];
            s = stringmakerv2(9, colnames);

            //external loop goes through the entire food array
            for (int j = 0; j < fds.Length; j++)
            {
                //internal loop goes through the sql commands
                for (int i = 0; i <= 9; i++)
                {
                    con.Open();
                    //command inc through sql command string array
                    command = new SqlCeCommand(s[i], con);
                    //create new sql Parameter
                    SqlCeParameter param = null;
                    //set up parameters
                    param = new SqlCeParameter("@" + colnames[i], SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@" + colnames[i] + "q", SqlDbType.Int);
                    command.Parameters.Add(param);
                    command.Prepare();
                    //set parameter values
                    command.Parameters[0].Value = fds[j].name;
                    command.Parameters[1].Value = fds[j].quantity;
                    //reader for reading through the table
                    SqlCeDataReader reader = null;
                    //execute the search and save results in reader
                    reader = command.ExecuteReader();
                    //if recipe name found
                    while (reader.Read())
                    {
                        int u = 0;
                        bool wasfound = false;
                        for (int k = 0; k <= ds.Tables[0].Rows.Count; k++)
                        {
                            int o = String.Compare(instock[k].name, reader["name"].ToString(), true);
                            //if the two items are the same
                            if (instock[k].name == reader["name"].ToString())
                            {
                                wasfound = true;
                                u = k; //used to save spot where item found
                            }
                        }

                        if (wasfound)
                            instock[u].instock++;
                        else
                        {
                            instock[i].name = reader["name"].ToString();
                            instock[i].instock++;
                        }
                    }
                    con.Close();
                }

            }
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                con.Open();
                command = con.CreateCommand();
                command.CommandText = "UPDATE tblRecipe SET instock = @instock WHERE name = @name";
                SqlCeParameter param = null;
                param = new SqlCeParameter("@instock", SqlDbType.Int);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@name", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@name"].Size = 100;
                command.Prepare();
                command.Parameters[0].Value = instock[k].instock;
                command.Parameters[1].Value = instock[k].name;

                command.ExecuteNonQuery();

                ds = new DataSet();
                da = new SqlCeDataAdapter();
                command = new SqlCeCommand("SELECT * FROM tblRecipe ORDER BY instock", con);
                //refill the datagrid and show it again
                da = new SqlCeDataAdapter(command);
                ds.Clear();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                con.Close();

            }
        }
        //fills the datagrid with updated data
        void showRecipe()
        {
            con.Open();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            command = new SqlCeCommand("SELECT * FROM tblRecipe", con);
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            for (int i = 0; i < 60; i++)
                dataGridView1.Columns.Remove(dataGridView1.Columns[2]);

            dataGridView1.Columns.Remove(dataGridView1.Columns[7]);

            con.Close();

        }

        void checkRecipe()
        {
            bool allinfooddb = true;
            int a = Convert.ToInt32(dataGridView1.CurrentRow.Index);
            int c = (int)dataGridView1.CurrentRow.Cells[0].Value;
            int currentcell = 2;
            //c--;
            recipeitems = new Form1.recipefooditem[c];
            for (int i = 0; i < c; i++)
                recipeitems[i].infdb = false;
            int fdslen = fds.GetLength(0);
            //MessageBox.Show(fdslen.ToString());
            for (int i = 0; i < c; i++)
            {
                //ds.Tables[0].Rows[a].ItemArray[currentcell].ToString()
                //recipeitems[i].name = dataGridView1.CurrentRow.Cells[currentcell].Value.ToString();
                recipeitems[i].name = ds.Tables[0].Rows[a].ItemArray[currentcell].ToString();
                //MessageBox.Show(recipeitems[i].name);
                currentcell++;
                recipeitems[i].quantity = (int)ds.Tables[0].Rows[a].ItemArray[currentcell];
                //MessageBox.Show(recipeitems[i].quantity.ToString());
                currentcell++;
                currentcell++;

            }
            for (int i = 0; i < c; i++)
            {
                //MessageBox.Show(recipeitems[i].name + " recipe item");
                for (int j = 0; j < fdslen; j++)
                {
                    //MessageBox.Show(fds[j].name + " food db");
                    
                    
                    
                    int o = String.Compare(recipeitems[i].name, fds[j].name, true);
                    //if the two items are the same
                    if (o == 0)
                    {
                        if (fds[j].quantity >= recipeitems[i].quantity)
                        {
                            //MessageBox.Show(recipeitems[i].name + "true quantity correct names match");
                            recipeitems[i].infdb = true;
                            recipeitems[i].calories = fds[j].calories;
                        }
                        else
                        {
                            //MessageBox.Show(recipeitems[i].name + "false quantity to low");
                            recipeitems[i].infdb = false;

                        }
                    }
                }
            }
            for (int i = 0; i < c; i++)
            {
                if (recipeitems[i].infdb == false)
                {
                    //MessageBox.Show(recipeitems[i].name + " was set to false");
                    allinfooddb = false;
                }
            }
            if (allinfooddb == false)
                MessageBox.Show("Items Missing");
            else
            {
                MessageBox.Show("Items All Instock");
                
                mainForm.addMeal(recipeitems);

            }

        }
        void searchRecipe()
        {
            string[] s = new string[9];
            s = stringmaker(9, colnames);
            for (int i = 0; i <= 9; i++)
            {
                con.Open();
                //MessageBox.Show(s[i]);
                //cmd = new SqlCommand(s[i], con);
                command = new SqlCeCommand(s[i], con);
                //cmd.Parameters.Add("@" + colnames[i], SqlDbType.VarChar).Value = textBox12.Text;
                SqlCeParameter param = null;
                param = new SqlCeParameter("@" + colnames[i], SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Prepare();
                command.Parameters[0].Value = textBox12.Text;
                SqlCeDataReader reader = null;

                //execute the search and save results in reader
                reader = command.ExecuteReader();
                //if pass user found show message
                while (reader.Read())
                {
                    rnames[i] = reader["name"].ToString();
                    MessageBox.Show("Found in " + reader["name"].ToString());
                    //MessageBox.Show("Placed in " + rnames[i]);
                }
                con.Close();


            }
            //close connection
        }
        //allows user to delete Recipe from db 
        void deleteRecipe()
        {
            //delete
            //open the connection 
            con.Open();
            //set command to remove the row the user has selected by using the unique item ID
            command = con.CreateCommand();
            command.CommandText = "Delete FROM tblRecipe WHERE NAME = @NAME";
            SqlCeParameter param = null;
            param = new SqlCeParameter("@NAME", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            command.ExecuteNonQuery();
            command = con.CreateCommand();
            con.Close();
            showRecipe();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            recipeadd form4 = new recipeadd(dataGridView1.CurrentRow.Cells[1].Value.ToString());
            form4.ShowDialog();
            showRecipe();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox12.Text != "")
            searchRecipe();
            else
                MessageBox.Show("No String Entered.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
            deleteRecipe();
            //showRecipe();
        }
        //builds sql string for food item search
        public static string[] stringmaker(int qu, string [] colnames)
        {
            string sql = "SELECT * FROM tblRecipe WHERE ";
            
            string[] sql2 = new string[10];            
            //@ingredient#, @ingredient1, @ingredient2, @ingredient3, @ingredient4, @ingredient5, @ingredient6, @ingredient7, @ingredient8, @ingredient9, @ingredient10
            //string[] colnames = new string[10] {"ingredient1", "ingredient2", "ingredient3", "ingredient4", "ingredient5", "ingredient6", "ingredient7", "ingredient8", "ingredient9", "ingredient10" };
            //cmd = new SqlCommand("SELECT * FROM tblRecipe WHERE ingredient1 = @ingredient1", con);
            for (int i = 0; i <= qu; i++)
            {
                sql2[i] = sql + colnames[i] + " = @" + colnames[i] + "";
                //MessageBox.Show(sql2);
            }
            return sql2;

        }
        //builds sql string for food item search
        public static string[] stringmakerv2(int qu, string[] colnames)
        {
            string sql = "SELECT * FROM tblRecipe WHERE ";

            string[] sql2 = new string[10];
            //@ingredient#, @ingredient1, @ingredient2, @ingredient3, @ingredient4, @ingredient5, @ingredient6, @ingredient7, @ingredient8, @ingredient9, @ingredient10
            //string[] colnames = new string[10] {"ingredient1", "ingredient2", "ingredient3", "ingredient4", "ingredient5", "ingredient6", "ingredient7", "ingredient8", "ingredient9", "ingredient10" };
            //cmd = new SqlCommand("SELECT * FROM tblRecipe WHERE ingredient1 = @ingredient1", con);
            for (int i = 0; i <= qu; i++)
            {
                sql2[i] = sql + colnames[i] + " = @" + colnames[i] + " AND " + colnames[i] + "q " + " <= @" + colnames[i] +"q";

                //MessageBox.Show(sql2);
            }
            return sql2;

        }


        private void button3_Click(object sender, EventArgs e)
        {
            recipeadd form4 = new recipeadd();
            form4.ShowDialog();
            showRecipe();

        }

        private void recipebrowser_Load(object sender, EventArgs e)
        {
            showRecipe();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
            {
                checkRecipe();
                Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            stockRecipes();
            showRecipe();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
