﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kitchenv2
{
    class DualLinkedList
    {
        //first link in list
        private Link first;
        //last link in list
        private Link last;
        int l; //used as link number
        int totalLinks;

        public DualLinkedList()
        {
            first = null;
            last = null;
            l = 0;
            totalLinks = 0;
        }

        public bool isEmpty()
        {
            //if the first link points to nothing and the last link points to nothing
            //the list is empty and return true else return the list has values
            if (first == null && last == null)
                return true;
            else
                return false;
        }

        public void insert(Form1.fooditem f)
        {
            //make a new link
            Link newLink = new Link(f, l);
            //MessageBox.Show(newLink.displayLink());
            //if the list is empty first = new link
            if (isEmpty())
                first = newLink;
            //or else
            else
            {
                //the next link in the list after the last one is equal to new link
                last.next = newLink;
                
                newLink.previous = last;
            }
            last = newLink;
            l++;
            totalLinks++;
        }
        //moves the node's strings foward
        public int display6nodes(int start, Label[] l, int e, NumericUpDown [] n, PictureBox [] p)
        {
            if (totalLinks <= 0)
            {
                MessageBox.Show("There is no food in the food database.");
                for (int i = 0; i <= 5; i++)
                {
                    l[i].Text = "-";
                }
                return 0;
            }
            //something is needed to show that
            //the user has reached the end of the array

            //something is needed to deal with food db < 5
            //MessageBox.Show("e " + e);
            int begin = start; //where to start
            int end = begin + 5; // where printing finished
            Link current = first; // start at beginning
            if (totalLinks > 5)
            {
                while (begin < end)
                {
                    if (current == null || begin > totalLinks - 5)
                    {
                        current = first;
                        begin = totalLinks - 5;
                        end = totalLinks;
                    }
                    if (current.linkNumber == begin)
                    {
                        int i = 0;

                        while (begin <= end)
                        {
                            if (current == null)
                            {
                                current = first;
                            }
                            l[i].Text = current.displayLink();
                            n[i].Maximum = current.max;
                            if (current.hasicon)
                                p[i].Image = current.icon;
                            else
                                p[i].Image = null;
                            //MessageBox.Show(current.linkNumber.ToString());
                            //MessageBox.Show(current.displayLink());
                            current = current.next;
                            begin++;
                            i++;
                        }
                    }
                    else
                    {
                        current = current.next;

                    }


                }

            }

            if (totalLinks <= 5)
            {
                current = first;
                //MessageBox.Show("end " + end);
                //MessageBox.Show("totalLinks " + totalLinks);
                
                    //MessageBox.Show("");
                    for (int i = 0; i < totalLinks; i++)
                    {
                        
                        l[i].Text = current.displayLink();
                        n[i].Maximum = current.max;
                        if (current.hasicon)
                            p[i].Image = current.icon;
                        else
                            p[i].Image = null;
                        //MessageBox.Show(current.linkNumber.ToString());
                        //MessageBox.Show("inside " + current.displayLink());
                        current = current.next;
                        begin = i;
                        //MessageBox.Show("begin " + begin);
                        //i++;
                    }
                    current = first;
                    //MessageBox.Show("begin " + begin);
                    begin++;

                    while (begin <= 5)
                    {
                        if (current == null)
                            current = first;
                        l[begin].Text = current.displayLink();
                        n[begin].Maximum = current.max;
                        if (current.hasicon)
                            p[begin].Image = current.icon;
                        else
                            p[begin].Image = null;
                        current = current.next;
                        begin++;
                    }
            }
            return end;
        }
        //moves the displayed node's string back
        public int display6nodes(int start, Button[] l, int e, PictureBox[] p)
        {
            if (totalLinks <= 0)
            {
                MessageBox.Show("There is no food in the food database.");
                for (int i = 0; i <= 5; i++)
                {
                    l[i].Text = "-";
                }
                return 0;
            }
            //something is needed to show that
            //the user has reached the end of the array

            //something is needed to deal with food db < 5
            //MessageBox.Show("e " + e);
            int begin = start; //where to start
            int end = begin + 5; // where printing finished
            Link current = first; // start at beginning
            if (totalLinks > 5)
            {
                while (begin < end)
                {
                    if (current == null || begin > totalLinks - 5)
                    {
                        current = first;
                        begin = totalLinks - 5;
                        end = totalLinks;
                    }
                    if (current.linkNumber == begin)
                    {
                        int i = 0;

                        while (begin <= end)
                        {
                            if (current == null)
                            {
                                current = first;
                            }
                            l[i].Text = current.displayLink();
                            //n[i].Maximum = current.max;
                            if (current.hasicon)
                                p[i].Image = current.icon;
                            else
                                p[i].Image = null;
                            //MessageBox.Show(current.linkNumber.ToString());
                            //MessageBox.Show(current.displayLink());
                            current = current.next;
                            begin++;
                            i++;
                        }
                    }
                    else
                    {
                        current = current.next;

                    }


                }

            }

            if (totalLinks <= 5)
            {
                current = first;
                //MessageBox.Show("end " + end);
                //MessageBox.Show("totalLinks " + totalLinks);

                //MessageBox.Show("");
                for (int i = 0; i < totalLinks; i++)
                {

                    l[i].Text = current.displayLink();
                    //n[i].Maximum = current.max;
                    if (current.hasicon)
                        p[i].Image = current.icon;
                    else
                        p[i].Image = null;
                    //MessageBox.Show(current.linkNumber.ToString());
                    //MessageBox.Show("inside " + current.displayLink());
                    current = current.next;
                    begin = i;
                    //MessageBox.Show("begin " + begin);
                    //i++;
                }
                current = first;
                //MessageBox.Show("begin " + begin);
                begin++;

                while (begin <= 5)
                {
                    if (current == null)
                        current = first;
                    l[begin].Text = current.displayLink();
                    //n[begin].Maximum = current.max;
                    if (current.hasicon)
                        p[begin].Image = current.icon;
                    else
                        p[begin].Image = null;
                    current = current.next;
                    begin++;
                }
            }
            return end;
        }

    }
}
