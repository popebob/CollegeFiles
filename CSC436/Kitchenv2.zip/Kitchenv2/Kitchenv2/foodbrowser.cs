﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using System.IO;

namespace Kitchenv2
{
    public partial class foodbrowser : Form
    {
        private Form1 mainForm; //handle for first form
        private foodbrowser fb; //handle for second form

        //shopping cart items
        Form1.mealitem[] shoppingcart;
        Form1.mealitem[] tempcart;
        int shoppingcartcount;
        TextWriter tw;

        //Dataset to hold data from sql table
        DataSet ds = new DataSet();
        //connection string to open new connection
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        //dataadapter for commuinicating with sql data base
        SqlCeDataAdapter da = new SqlCeDataAdapter();
        //used to make sql commands
        SqlCeCommand command; //sql command
        int q;
        public foodbrowser()
        {
            q = 1;
            InitializeComponent();
            fb = this;
            shoppingcartcount = -1;
            shoppingcart = new Form1.mealitem[100];
            
        }
        public foodbrowser(Form1 m)
        {
            q = 1;
            InitializeComponent();
            mainForm = m;
            fb = this;
            shoppingcartcount = -1;
            shoppingcart = new Form1.mealitem[100];

        }
        //allows user to browse food User specifies instock or depleted 
        public void showfood()
        {
            con.Open();
            

            //choose instock or depleated based on user input which is shown as int q
            //if user wants instock search food db for food where
            //quantity > 0
            if (q == 0)
            {
                command = con.CreateCommand();
                command.CommandText = "SELECT * FROM tblFood where quantity <= Depletedcount";
                //command.CommandText = "SELECT * FROM tblFood where quantity < 1";
            }
            if (q > 0)
            {
                command = con.CreateCommand();
                command.CommandText = "SELECT * FROM tblFood where quantity > Depletedcount";
            }
            da = new SqlCeDataAdapter(command);
                        
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            //dataGridView1.Columns.Remove(dataGridView1.Columns[5]);
            con.Close();
    
        }
        //allows user to delete food from db 
        void deletefood()
        {
            //open the connection 
            con.Open();            
            //set command to remove the row the user has selected by using the unique item ID
            command = con.CreateCommand();
            command.CommandText = "Delete FROM tblFood WHERE ID = @ID";
            SqlCeParameter param = null;
            param = new SqlCeParameter("@ID", SqlDbType.Int);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = dataGridView1.CurrentRow.Cells[0].Value;
            command.ExecuteNonQuery();
            command = con.CreateCommand();
            //refill the datagrid and show it again
            command.CommandText = "SELECT * FROM tblFood where quantity > 0";
            da = new SqlCeDataAdapter(command);                        
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            //dataGridView1.Columns.Remove(dataGridView1.Columns[5]);
            con.Close();
        }
        //user is able to sort food
        void sortfood()
        {
            //open the connection 
            con.Open();
            //use foodname to sort db rows
            command = con.CreateCommand();
            command.CommandText = "SELECT * FROM tblFood ORDER BY foodName";
            da = new SqlCeDataAdapter(command); 
            //refill the datagrid and show it again
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            //dataGridView1.Columns.Remove(dataGridView1.Columns[5]);
            con.Close();
        }
        //user updates food quantity
        void updatefood()
        {
            //update quantity in the database where user changes quantity in the datagrid view
            // only does one at a time right now    
            //open the connection 
            con.Open();
            //set command to update the row the user has selected by using the unique item ID
            command = con.CreateCommand();
            command.CommandText = "UPDATE tblFood SET quantity = @quantity WHERE ID = @ID";
            SqlCeParameter param = null;
            param = new SqlCeParameter("@ID", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@quantity", SqlDbType.Int);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = dataGridView1.CurrentRow.Cells[0].Value;
            command.Parameters[1].Value = dataGridView1.CurrentRow.Cells[3].Value;
            int j = 0;
            string n = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            while (j < ds.Tables[0].Rows.Count)
            {
                if (Form1.foods[j].name == n)
                    Form1.foods[j].quantity = (int)dataGridView1.CurrentRow.Cells[3].Value;
                j++;
            }
            command.ExecuteNonQuery();
            //refill the datagrid and show it again
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            //dataGridView1.Columns.Remove(dataGridView1.Columns[5]);
            con.Close();
        }
        void addtocart()
        {
            shoppingcartcount++;
            shoppingcart[shoppingcartcount].name = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            shoppingcart[shoppingcartcount].quantity = (int)dataGridView1.CurrentRow.Cells[3].Value;
        }

        //display the meal
        public void viewCart()
        {
            //clear listbox
            listBox1.Items.Clear();
            //go through food item array and add items to listbox
            for (int i = 0; i <= shoppingcartcount; i++)
            {
                listBox1.Items.Add(shoppingcart[i].name + " " + shoppingcart[i].quantity + " servings in stock.");
            }

        }

        //remove an item from the cart. uses temp arrays to skip item removed and reset array
        public void deleteCart()
        {
            tempcart = shoppingcart; //temp cart array set to real cart            
            string removeditem; //used to store item to be removed
            int cartremoveindex = 0; //used to store item to be removed
            removeditem = listBox1.SelectedItem.ToString();
            //finds the index of the item to be removed in the array and saves it
            for (int i = 0; i <= shoppingcartcount; i++)
            {
                if (tempcart[i].name == removeditem)
                    cartremoveindex = i;

            }
            //rebuilds the array without the removed item. if removed item is found it is skipped in the rebuilding
            for (int i = 0; i <= shoppingcartcount; i++)
            {
                //as long as current item isn't item to be removed add it to the cart
                if (i != cartremoveindex)
                {
                    shoppingcart[i] = tempcart[i];
                    //Form1.cartq[i] = Form1.tempcartq[i];
                }
                //if current item is to be removed skip it
                if (i == cartremoveindex)
                    i++;
            }
            //dec the cart count since it is one item smaller now
            shoppingcartcount--;
            //clear then reset the listbox
            listBox1.Items.Clear();
            viewCart();
        }
        //remove food items from db and reset meal
        public void checkOut()
        {
            //write file results to text file
            //tw = new StreamWriter((System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "caltrack.txt");
            try
            {
                //tw = new StreamWriter();
                tw = File.AppendText("cart.txt");
            }
            catch (Exception e)
            {
                tw = new StreamWriter("cart.txt");
            }
            tw.WriteLine("");
            tw.WriteLine(DateTime.Now.ToString("M/d/yyyy"));
            for (int i = 0; i <= shoppingcartcount; i++)
                tw.WriteLine(shoppingcart[i].name + " " + shoppingcart[i].quantity);


            //reset cart to nothing
            shoppingcart = new Form1.mealitem[100];
            //set cart count to be nothing
            shoppingcartcount = -1;
            viewCart();
            tw.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
            addtocart();
            viewCart();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //user input changes q to instock or depleated
            if (comboBox1.SelectedIndex == 0)
                q = 1;
            if (comboBox1.SelectedIndex == 1)
                q = 0;
            showfood();

        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)            
            deletefood();
            //form 1 needs to be reloaded
            mainForm.showmain();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
            updatefood();
            //form 1 needs to be reloaded
            mainForm.showmain();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.TopMost = false;
            //foodadd form3 = new foodadd(mainForm, fb);
            //form3.ShowDialog();
            this.TopMost = true;
        }

        private void foodbrowser_Load(object sender, EventArgs e)
        {
            showfood();
            dataGridView1.Columns.Remove(dataGridView1.Columns[5]);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            mainForm.showmain();
            Close();
        }


        private void button21_Click(object sender, EventArgs e)
        {
            if (shoppingcartcount > -1)
            {
                deleteCart();
                viewCart();
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (shoppingcartcount > -1)
            {
                checkOut();
                viewCart();
            }
        }
    }
}
