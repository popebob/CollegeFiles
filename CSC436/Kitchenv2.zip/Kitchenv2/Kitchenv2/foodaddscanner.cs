﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
namespace Kitchenv2
{
    public partial class foodaddscanner : Form
    {
        //tblUpc 
        DataSet ds = new DataSet(); //dataset from database
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeConnection con2 = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeDataAdapter da = new SqlCeDataAdapter(); //for communicating with database
        SqlCeCommand command; //sql command
        SqlCeCommand command2; //sql command
        BindingSource bs = new BindingSource(); //used to bind fields from the database to items in the program
        string upc; //current upc scanned
        string foodname; //food name fetched from upcdb
        string foodtype; //food found in fooddb
        int quantity; //quantity in the food db of found food
        string previousupc; //upc scanned before the current one
        int addcount; //how many to add to the food db
        bool foodfound; //if there was a new scan or not
        bool upcfound; //if there was a new scan or not

        private Form1 mainForm; //handle for first form 
        private foodaddscanner fs;

        public foodaddscanner()
        {
            InitializeComponent();
            foodfound = false; //no new scan
            addcount = 1;
            fs = this;
        }
        public foodaddscanner(string upccode, Form1 m)
        {
            InitializeComponent();
            mainForm = m;
            upc = upccode; //take the upc code passed and set it to be the current upc
            addcount = 1;
            upcfound = false;
            foodfound = false; //no new scan
            //textBox1.Text = upccode;
            lblUPC.Text = upccode;
            //textBox1.Text = upccode;
            label2.Text = addcount.ToString();
            fs = this;
            checkupcdb(upc);
            
            //upc = "";

        }
        void checkupcdb(string upc)
        {

            MessageBox.Show("Food Scanned", "Attention");
            // Open Connection
            con.Open();
            if (upc == previousupc)
                label3.Text = "Scanned " + previousupc + " again. Adding 1 to count.";
            else
                label3.Text = "Scanned " + upc + " ready to search fdb.";

            //command for user / pass search
            //set command to update the row the user has selected by using the unique item ID
            command = new SqlCeCommand("SELECT * FROM tblUpc WHERE upc = @UPC", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@UPC", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@UPC"].Size = 100;
            command.Parameters[0].Value = upc;
            command.Prepare();
            SqlCeDataReader reader = null;
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {
                label3.Text = upc + " Found in upc db";
                label4.Text = reader["foodname"].ToString();
                foodname = label4.Text;
                label5.Text = reader["foodtype"].ToString();
                foodtype = label5.Text;
                upcfound = true;

            }
            previousupc = upc;
            //close connection
            con.Close();
            checkfooddb();
        }
        void checkfooddb()
        {
            foodfound = false; //no new scan
            if (upcfound)
            {
                // Open Connection
                con.Open();
                //command for user / pass search
                //set command to update the row the user has selected by using the unique item ID
                command = new SqlCeCommand("SELECT * FROM tblFood WHERE foodname = @foodname", con);
                SqlCeParameter param = null;
                param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@foodname"].Size = 100;
                command.Parameters[0].Value = foodname;
                command.Prepare();
                //command.ExecuteNonQuery();
                //reader to hold the results of the search
                SqlCeDataReader reader = null;
                //execute the search and save results in reader
                reader = command.ExecuteReader();
                //if pass user found show message
                while (reader.Read())
                {
                    label3.Text = foodname + " Found in food db";
                    label4.Text = reader["foodname"].ToString();
                    //foodname = label4.Text;
                    label5.Text = reader["foodtype"].ToString();
                    //foodtype = label5.Text;
                    foodfound = true;
                    quantity = reader.GetInt32(3);
                    label6.Text = quantity.ToString();
                    //con.Close();                    
                }
                //close connection
                con.Close();
                addfood();
            }
            else
                addfood();
        }
        //add scanned food to food db
        void addfood()
        {

            if (foodfound)
            {

                // Open Connection
                con2.Open();
                //command for user / pass search
                //set command to update the row the user has selected by using the unique item ID
                command2 = con2.CreateCommand();
                command2.CommandText = "UPDATE tblFood SET quantity = @quantity WHERE foodname = @foodname";
                SqlCeParameter param = null;
                param = new SqlCeParameter("@quantity", SqlDbType.Int);
                command2.Parameters.Add(param);
                param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
                command2.Parameters.Add(param);
                command2.Parameters["@foodname"].Size = 100;
                command2.Parameters[0].Value = quantity + 1;
                command2.Parameters[1].Value = foodname;
                command2.Prepare();
                command2.ExecuteNonQuery();
                con2.Close();
                label6.Text = quantity.ToString();

            }
            if (!foodfound && !upcfound)
            {
                MessageBox.Show("Unrecognized food scanned. Proceeding to food add screen.");
                foodadd form3 = new foodadd(mainForm, fs, upc);
                form3.ShowDialog();
                label3.Text = "Food and upc wasn't found.";
            }
            if (!foodfound && upcfound)
            {
                con.Open();
            command = new SqlCeCommand("SELECT * FROM tblUpc WHERE upc = @UPC", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@UPC", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@UPC"].Size = 100;
            //command.Parameters[0].Value = upc;
            command.Prepare();
            command.Parameters[0].Value = upc;
            SqlCeDataReader reader = null;
            reader = command.ExecuteReader();
            //if upc found set upcfound
            while (reader.Read())
            {
               foodname = reader[1].ToString();
               foodtype = reader[2].ToString();
               upc = reader[0].ToString();

            }
            con.Close();
            
                 
                MessageBox.Show("Recognized food scanned. Proceeding to food add screen.");
                foodadd form3 = new foodadd(mainForm, fs, upc, foodname, foodtype);
                form3.ShowDialog();
                label3.Text = "Food wasn't found.";
            }
            foodfound = false;
            upcfound = false;
            upc = "";

        }
      

        private void foodaddscanner_KeyDown(object sender, KeyEventArgs e)
        {
            //save the last iten scanned
            bool nonNumberEntered; //input wasn't a number

            // Initialize the flag to false.
            nonNumberEntered = false;
            //if (e.KeyCode == Keys.Enter) { MessageBox.Show("Enter pressed", "Attention"); }
            // Determine whether the keystroke is a number from the top of the keyboard.
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                // Determine whether the keystroke is a number from the keypad.
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    // Determine whether the keystroke is a backspace.
                    if (e.KeyCode != Keys.Back)
                    {

                        // A non-numerical keystroke was pressed.
                        // Set the flag to true and evaluate in KeyPress event.
                        nonNumberEntered = true;
                    }

                }
            }
            //If shift key was pressed, it's not a number.
            if (Control.ModifierKeys == Keys.Shift)
            {
                nonNumberEntered = true;
            }
            // Check for the flag being set in the KeyDown event.
            //if the key pressed was a letter
            if (nonNumberEntered == true)
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }
            //if the key pressed was a number check timer
            //if timer wasn't started then start it

            if (nonNumberEntered == false)
            {
                //MessageBox.Show("Was number" + upc);
                //append the key to the end of the input collecting string
                //sKey += e.KeyCode.ToString();
                upc += (char)e.KeyValue;
                int sKeyLen = upc.Length;
                //label2.Text = sKeyLen.ToString();
                if (sKeyLen == 12)
                {
                    mainForm.showmain();
                    if (upc == previousupc)
                    {
                        //label3.Text = "Scanned " + previousupc + " again. Adding 1 to count.";
                        //MessageBox.Show("you scanned " + previousupc + " again. Adding 1 to count.");
                        addcount++;
                        //textBox1.Text = upc;
                        lblUPC.Text = upc;
                        label2.Text = addcount.ToString();
                        //addcount = 1;
                        lblUPC.Text = upc;
                        //MessageBox.Show("!", "Attention");
                        //MessageBox.Show("!", "Attention");                  
                        checkupcdb(upc);
                        upc = "";
                    }
                    else
                    {
                        //textBox1.Text = upc;
                        lblUPC.Text = upc;
                        //MessageBox.Show("!", "Attention");
                        //MessageBox.Show("!", "Attention");
                        checkupcdb(upc);
                        addcount = 1;
                        lblUPC.Text = upc;
                        label2.Text = addcount.ToString();
                        upc = "";

                    }
                }
            }
        }

        private void foodaddscanner_Load(object sender, EventArgs e)
        {
            
        }
        protected override bool IsInputKey(Keys keyData)
        {
            if (keyData == Keys.Enter)
            {
                MessageBox.Show("!", "Attention");
                return true;
            }
            if (keyData == Keys.Return)
            {
                MessageBox.Show("!", "Attention");
                return true;
            }
            else
            {
                return base.IsInputKey(keyData);
            }
        }

    }
}
