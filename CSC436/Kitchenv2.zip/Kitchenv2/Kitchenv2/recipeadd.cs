﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlServerCe;

namespace Kitchenv2
{
    public partial class recipeadd : Form
    {
        DataSet ds = new DataSet();
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeDataAdapter da = new SqlCeDataAdapter(); //for communicating with database //used to communicate with SQL database
        SqlCommand cmd;
        SqlCeCommand command; //sql command
        //string[] rnames; //names where string search is found
        string recipe; //to view a single recipe
        public recipeadd()
        {
            InitializeComponent();
            //rnames = new string[100];
        }

        public recipeadd(string r)
        {
            InitializeComponent();
            //rnames = new string[100];
            recipe = r;
            button1.Visible = false;
            viewrecipe();
        }

        void viewrecipe()
        {
            con.Open();
            //MessageBox.Show(s[i]);
            //cmd = new SqlCommand(s[i], con);
            command = new SqlCeCommand("SELECT * FROM tblRecipe where name = @name", con);
            //cmd.Parameters.Add("@" + colnames[i], SqlDbType.VarChar).Value = textBox12.Text;
            SqlCeParameter param = null;
            param = new SqlCeParameter("@name", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = recipe;
            //MessageBox.Show(recipefrommeal[j].name + " " + recipefrommeal[j].quantity.ToString());
            SqlCeDataReader reader = null;

            //execute the search and save results in reader
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {

                //username, weight, height, age, dailycalcount, lastdateused 
                //show ing#
                numericUpDown11.Value = Convert.ToDecimal(reader[0]);
                //recipe name
                textBox1.Text = reader[1].ToString();
                //show Ingredient 1
                textBox2.Text = reader[2].ToString();
                //show Ingredient # for 1
                numericUpDown1.Value = Convert.ToDecimal(reader[3]);

                //show Ingredient 2
                textBox3.Text = reader[5].ToString();
                //show Ingredient # for 2
                numericUpDown2.Value = Convert.ToDecimal(reader[6]);

                //show Ingredient 1
                textBox4.Text = reader[8].ToString();
                //show Ingredient # for 1
                numericUpDown3.Value = Convert.ToDecimal(reader[9]);

                //show Ingredient 1
                textBox5.Text = reader[11].ToString();
                //show Ingredient # for 1
                numericUpDown4.Value = Convert.ToDecimal(reader[12]);

                //show Ingredient 1
                textBox6.Text = reader[14].ToString();
                //show Ingredient # for 1
                numericUpDown5.Value = Convert.ToDecimal(reader[15]);

                //show Ingredient 1
                textBox7.Text = reader[17].ToString();
                //show Ingredient # for 1
                numericUpDown6.Value = Convert.ToDecimal(reader[18]);

                //show Ingredient 1
                textBox8.Text = reader[20].ToString();
                //show Ingredient # for 1
                numericUpDown7.Value = Convert.ToDecimal(reader[21]);

                //show Ingredient 1
                textBox9.Text = reader[23].ToString();
                //show Ingredient # for 1
                numericUpDown8.Value = Convert.ToDecimal(reader[24]);

                //show Ingredient 1
                textBox10.Text = reader[26].ToString();
                //show Ingredient # for 1
                numericUpDown9.Value = Convert.ToDecimal(reader[27]);

                //show Ingredient 10
                textBox11.Text = reader[29].ToString();
                //show Ingredient # for 10
                numericUpDown10.Value = Convert.ToDecimal(reader[30]);

                numericUpDown13.Value = Convert.ToDecimal(reader[62]);
                numericUpDown12.Value = Convert.ToDecimal(reader[63]);
                numericUpDown15.Value = Convert.ToDecimal(reader[64]);
                textBox14.Text = reader[65].ToString();
                richTextBox1.Text = reader[66].ToString();
                textBox12.Text = reader[67].ToString();

            }
            con.Close();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            command = con.CreateCommand();
            //command.CommandText = ("INSERT INTO tblRecipe (ingredient#, name, ingredient1, ingredient1q, ingredient1uom, ingredient2, ingredient2q,ingredient2uom, ingredient3, ingredient3q, ingredient3uom, ingredient4, ingredient4q, ingredient4uom, ingredient5, ingredient5q, ingredient5uom, ingredient6, ingredient6q, ingredient6uom, ingredient7, ingredient7q, ingredient7uom, ingredient8, ingredient8q, ingredient8uom, ingredient9, ingredient9q, ingredient9uom, ingredient10, ingredient10q, ingredient10uom, ingredient11, ingredient11q, ingredient11uom, ingredient12, ingredient12q, ingredient12uom, ingredient13, ingredient13q, ingredient13uom, ingredient14, ingredient14q, ingredient14uom, ingredient15, ingredient15q, ingredient15uom, ingredient16, ingredient16q, ingredient16uom, ingredient17, ingredient17q, ingredient17uom, ingredient18, ingredient18q, ingredient18uom, ingredient19, ingredient19q, ingredient19uom, ingredient20, ingredient20q, ingredient20uom, preptime, cooktime, yieldquantity, yielduom, directions, tod) VALUES (@ingredient#, @name, @ingredient1, @ingredient1q, @ingredient1uom, @ingredient2, @ingredient2q, @ingredient2uom, @ingredient3, @ingredient3q, @ingredient3uom, @ingredient4, @ingredient4q, @ingredient4uom, @ingredient5, @ingredient5q, @ingredient5uom, @ingredient6, @ingredient6q, @ingredient6uom, @ingredient7, @ingredient7q, @ingredient7uom, @ingredient8, @ingredient8q, @ingredient8uom, @ingredient9, @ingredient9q, @ingredient9uom, @ingredient10, @ingredient10q, @ingredient10uom, @ingredient11, @ingredient11q, @ingredient11uom, @ingredient12, @ingredient12q, @ingredient12uom, @ingredient13, @ingredient13q, @ingredient13uom, @ingredient14, @ingredient14q, @ingredient14uom, @ingredient15, @ingredient15q, @ingredient15uom, @ingredient16, @ingredient16q, @ingredient16uom, @ingredient17, @ingredient17q, @ingredient17uom, @ingredient18, @ingredient18q, @ingredient18uom, @ingredient19, @ingredient19q, @ingredient19uom, @ingredient20, @ingredient20q, @ingredient20uom, @preptime, @cooktime, @yieldquantity, @yielduom, @directions, @tod)";
            //da.InsertCommand = new SqlCommand("INSERT INTO tblRecipe VALUES(@name, @ingredient#, @ingredient1, @ingredient2, @ingredient3, @ingredient4, @ingredient5, @ingredient6, @ingredient7, @ingredient8, @ingredient9, @ingredient10)", con);
             command.CommandText = "INSERT INTO tblRecipe (ingredient#, name, ingredient1, ingredient1q, ingredient1uom, ingredient2, ingredient2q, ingredient2uom, ingredient3, ingredient3q, ingredient3uom, ingredient4, ingredient4q, ingredient4uom, ingredient5, ingredient5q, ingredient5uom, ingredient6, ingredient6q, ingredient6uom, ingredient7, ingredient7q, ingredient7uom, ingredient8, ingredient8q, ingredient8uom, ingredient9, ingredient9q, ingredient9uom, ingredient10, ingredient10q, ingredient10uom, preptime, cooktime, yieldquantity, yielduom, directions, tod) VALUES (@ingredient#, @name, @ingredient1, @ingredient1q, @ingredient1uom, @ingredient2, @ingredient2q, @ingredient2uom, @ingredient3, @ingredient3q, @ingredient3uom, @ingredient4, @ingredient4q, @ingredient4uom, @ingredient5, @ingredient5q, @ingredient5uom, @ingredient6, @ingredient6q, @ingredient6uom, @ingredient7, @ingredient7q, @ingredient7uom, @ingredient8, @ingredient8q, @ingredient8uom, @ingredient9, @ingredient9q, @ingredient9uom, @ingredient10, @ingredient10q, @ingredient10uom,  @preptime, @cooktime, @yieldquantity, @yielduom, @directions, @tod)";
            //
            SqlCeParameter param = null;

            param = new SqlCeParameter("@ingredient#", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@name", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient1", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient1q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient1uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient2", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient2q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient2uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient3", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            //10
            param = new SqlCeParameter("@ingredient3q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient3uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient4", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient4q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient4uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient5", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient5q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient5uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient6", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient6q", SqlDbType.Int);
            command.Parameters.Add(param);
            //20
            param = new SqlCeParameter("@ingredient6uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient7", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient7q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient7uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient8", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient8q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient8uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient9", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient9q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient9uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            //30
            param = new SqlCeParameter("@ingredient10", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient10q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient10uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            
            /*
            param = new SqlCeParameter("@ingredient11", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient11q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient11uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient12", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient12q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient12uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient13", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            //40
            param = new SqlCeParameter("@ingredient13q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient13uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient14", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient14q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient14uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient15", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient15q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient5uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient16", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient16q", SqlDbType.Int);
            command.Parameters.Add(param);
            //50
            param = new SqlCeParameter("@ingredient16uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient17", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient17q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient17uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient18", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient18q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient18uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient19", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient19q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient19uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            //60
            param = new SqlCeParameter("@ingredient20", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient20q", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@ingredient20uom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            */
            param = new SqlCeParameter("@preptime", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@cooktime", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@yieldquantity", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@yielduom", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@directions", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@tod", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            //68
            //ingredient#, name, ingredient1, ingredient1q, ingredient1uom,

            command.Parameters["@name"].Size = 100;
            command.Parameters["@ingredient1"].Size = 100;
            command.Parameters["@ingredient1uom"].Size = 100;
            command.Parameters["@ingredient2"].Size = 100;
            command.Parameters["@ingredient2uom"].Size = 100;
            command.Parameters["@ingredient3"].Size = 100;
            command.Parameters["@ingredient3uom"].Size = 100;
                        command.Parameters["@ingredient4"].Size = 100;
            command.Parameters["@ingredient4uom"].Size = 100;
            command.Parameters["@ingredient5"].Size = 100;
            command.Parameters["@ingredient5uom"].Size = 100;
            command.Parameters["@ingredient6"].Size = 100;
            command.Parameters["@ingredient6uom"].Size = 100;
                        command.Parameters["@ingredient7"].Size = 100;
            command.Parameters["@ingredient7uom"].Size = 100;
            command.Parameters["@ingredient8"].Size = 100;
            command.Parameters["@ingredient8uom"].Size = 100;
            command.Parameters["@ingredient9"].Size = 100;
            command.Parameters["@ingredient9uom"].Size = 100;
                        command.Parameters["@ingredient10"].Size = 100;
            command.Parameters["@ingredient10uom"].Size = 100;
            /*
            command.Parameters["@ingredient11"].Size = 100;
            command.Parameters["@ingredient11uom"].Size = 100;
            command.Parameters["@ingredient12"].Size = 100;
            command.Parameters["@ingredient12uom"].Size = 100;
                        command.Parameters["@ingredient13"].Size = 100;
            command.Parameters["@ingredient13uom"].Size = 100;
            command.Parameters["@ingredient14"].Size = 100;
            command.Parameters["@ingredient14uom"].Size = 100;
            command.Parameters["@ingredient15"].Size = 100;
            command.Parameters["@ingredient15uom"].Size = 100;
                        command.Parameters["@ingredient16"].Size = 100;
            command.Parameters["@ingredient16uom"].Size = 100;
            command.Parameters["@ingredient17"].Size = 100;
            command.Parameters["@ingredient17uom"].Size = 100;
            command.Parameters["@ingredient18"].Size = 100;
            command.Parameters["@ingredient18uom"].Size = 100;
                        command.Parameters["@ingredient19"].Size = 100;
            command.Parameters["@ingredient19uom"].Size = 100;
            command.Parameters["@ingredient20"].Size = 100;
            command.Parameters["@ingredient20uom"].Size = 100;
             * */
            command.Parameters["@yielduom"].Size = 100;
            command.Parameters["@directions"].Size = 100;
            command.Parameters["@tod"].Size = 100;
            command.Prepare();
            command.Parameters[0].Value = Convert.ToInt32(numericUpDown11.Value);
            command.Parameters[1].Value = textBox1.Text;
            command.Parameters[2].Value = textBox2.Text;
            command.Parameters[3].Value = Convert.ToInt32(numericUpDown1.Value);
            command.Parameters[4].Value = "Servings";
            command.Parameters[5].Value = textBox3.Text;
            command.Parameters[6].Value = Convert.ToInt32(numericUpDown2.Value);
            command.Parameters[7].Value = "Servings";
            command.Parameters[8].Value = textBox4.Text;
            command.Parameters[9].Value = Convert.ToInt32(numericUpDown3.Value);
            command.Parameters[10].Value = "Servings";
            command.Parameters[11].Value = textBox5.Text;
            command.Parameters[12].Value = Convert.ToInt32(numericUpDown4.Value);
            command.Parameters[13].Value = "Servings";
            command.Parameters[14].Value = textBox6.Text;
            command.Parameters[15].Value = Convert.ToInt32(numericUpDown5.Value);
            command.Parameters[16].Value = "Servings";
            command.Parameters[17].Value = textBox7.Text;
            command.Parameters[18].Value = Convert.ToInt32(numericUpDown6.Value);
            command.Parameters[19].Value = "Servings";
            command.Parameters[20].Value = textBox8.Text;
                        command.Parameters[21].Value = Convert.ToInt32(numericUpDown7.Value);
            command.Parameters[22].Value = "Servings";
            command.Parameters[23].Value = textBox9.Text;
            command.Parameters[24].Value = Convert.ToInt32(numericUpDown8.Value);
            command.Parameters[25].Value = "Servings";
            command.Parameters[26].Value = textBox10.Text;
            command.Parameters[27].Value = Convert.ToInt32(numericUpDown9.Value);
            command.Parameters[28].Value = "Servings";
            command.Parameters[29].Value = textBox11.Text;
            command.Parameters[30].Value = Convert.ToInt32(numericUpDown10.Value);
                        command.Parameters[31].Value = "Servings";
            command.Parameters[32].Value = Convert.ToInt32(numericUpDown13.Value);
            command.Parameters[33].Value = Convert.ToInt32(numericUpDown12.Value);
            command.Parameters[34].Value = Convert.ToInt32(numericUpDown15.Value);
            command.Parameters[35].Value = textBox14.Text;
            command.Parameters[36].Value = richTextBox1.Text;
            command.Parameters[37].Value = textBox12.Text;
            /*

                        command.Parameters[32].Value = numericUpDown1.Value;
            command.Parameters[33].Value = textBox2.Text;
            command.Parameters[34].Value = numericUpDown4.Value;
            command.Parameters[35].Value = (float)numericUpDown2.Value;
            command.Parameters[36].Value = (float)numericUpDown3.Value;
            command.Parameters[37].Value = (float)numericUpDown5.Value;
            command.Parameters[38].Value = (float)numericUpDown6.Value;
            command.Parameters[39].Value = (float)numericUpDown7.Value;
            command.Parameters[40].Value = (float)numericUpDown8.Value;
                        command.Parameters[41].Value = ftype;
            command.Parameters[42].Value = numericUpDown1.Value;
            command.Parameters[43].Value = textBox2.Text;
            command.Parameters[44].Value = numericUpDown4.Value;
            command.Parameters[45].Value = (float)numericUpDown2.Value;
            command.Parameters[46].Value = (float)numericUpDown3.Value;
            command.Parameters[47].Value = (float)numericUpDown5.Value;
            command.Parameters[48].Value = (float)numericUpDown6.Value;
            command.Parameters[49].Value = (float)numericUpDown7.Value;
            command.Parameters[50].Value = (float)numericUpDown8.Value;
                        command.Parameters[51].Value = ftype;
            command.Parameters[52].Value = numericUpDown1.Value;
            command.Parameters[53].Value = textBox2.Text;
            command.Parameters[54].Value = numericUpDown4.Value;
            command.Parameters[55].Value = (float)numericUpDown2.Value;
            command.Parameters[56].Value = (float)numericUpDown3.Value;
            command.Parameters[57].Value = (float)numericUpDown5.Value;
            command.Parameters[58].Value = (float)numericUpDown6.Value;
            command.Parameters[59].Value = (float)numericUpDown7.Value;
            command.Parameters[60].Value = (float)numericUpDown8.Value;
                                    command.Parameters[61].Value = ftype;
            command.Parameters[62].Value = numericUpDown1.Value;
            command.Parameters[63].Value = textBox2.Text;
            command.Parameters[64].Value = numericUpDown4.Value;
            command.Parameters[65].Value = (float)numericUpDown2.Value;
            command.Parameters[66].Value = (float)numericUpDown3.Value;
            command.Parameters[67].Value = (float)numericUpDown5.Value;
            command.Parameters[68].Value = (float)numericUpDown6.Value;
             * */
            command.ExecuteNonQuery();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
