﻿namespace Kitchenv2
{
    partial class foodadd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.cmdAddFood = new System.Windows.Forms.Button();
            this.tblFoodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kitchenDataSet1 = new Kitchenv2.KitchenDataSet1();
            this.tblFoodTableAdapter = new Kitchenv2.KitchenDataSet1TableAdapters.tblFoodTableAdapter();
            this.numDepleted = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numServings = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.numContainer = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.numProtein = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.numCarbs = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.numSugars = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.numSodium = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.numFat = new System.Windows.Forms.NumericUpDown();
            this.txtFat = new System.Windows.Forms.Label();
            this.numCalories = new System.Windows.Forms.NumericUpDown();
            this.txtxCalories = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUoM = new System.Windows.Forms.TextBox();
            this.txtServingSize = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.txtUPC = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.txtType = new System.Windows.Forms.TextBox();
            this.cmdDelete = new System.Windows.Forms.Button();
            this.cmdAddtoList = new System.Windows.Forms.Button();
            this.cmdUpdateFood = new System.Windows.Forms.Button();
            this.cmdAddtoMeal = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.numQuantity = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.cmdEditFood = new System.Windows.Forms.Button();
            this.lstFoodType = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.tblFoodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kitchenDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDepleted)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numServings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numContainer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProtein)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCarbs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSugars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSodium)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCalories)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtServingSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(1053, 645);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(161, 77);
            this.button4.TabIndex = 25;
            this.button4.Text = "Close";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Food Type";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(129, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Food Name";
            // 
            // txtName
            // 
            this.txtName.Enabled = false;
            this.txtName.Font = new System.Drawing.Font("Lucida Grande", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(205, 33);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(679, 57);
            this.txtName.TabIndex = 18;
            // 
            // cmdAddFood
            // 
            this.cmdAddFood.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdAddFood.Location = new System.Drawing.Point(52, 645);
            this.cmdAddFood.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmdAddFood.Name = "cmdAddFood";
            this.cmdAddFood.Size = new System.Drawing.Size(161, 77);
            this.cmdAddFood.TabIndex = 15;
            this.cmdAddFood.Text = "Add New Food";
            this.cmdAddFood.UseVisualStyleBackColor = true;
            this.cmdAddFood.Click += new System.EventHandler(this.cmdAddFood_Click);
            // 
            // tblFoodBindingSource
            // 
            this.tblFoodBindingSource.DataMember = "tblFood";
            this.tblFoodBindingSource.DataSource = this.kitchenDataSet1;
            // 
            // kitchenDataSet1
            // 
            this.kitchenDataSet1.DataSetName = "KitchenDataSet1";
            this.kitchenDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblFoodTableAdapter
            // 
            this.tblFoodTableAdapter.ClearBeforeFill = true;
            // 
            // numDepleted
            // 
            this.numDepleted.Enabled = false;
            this.numDepleted.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numDepleted.Location = new System.Drawing.Point(267, 573);
            this.numDepleted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numDepleted.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numDepleted.Name = "numDepleted";
            this.numDepleted.Size = new System.Drawing.Size(113, 30);
            this.numDepleted.TabIndex = 37;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(75, 507);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(186, 22);
            this.label6.TabIndex = 36;
            this.label6.Text = "Servings per container";
            // 
            // numServings
            // 
            this.numServings.Enabled = false;
            this.numServings.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numServings.Location = new System.Drawing.Point(267, 433);
            this.numServings.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numServings.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numServings.Name = "numServings";
            this.numServings.Size = new System.Drawing.Size(113, 30);
            this.numServings.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(156, 363);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 22);
            this.label4.TabIndex = 34;
            this.label4.Text = "Serving Size";
            // 
            // numContainer
            // 
            this.numContainer.Enabled = false;
            this.numContainer.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numContainer.Location = new System.Drawing.Point(267, 505);
            this.numContainer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numContainer.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numContainer.Name = "numContainer";
            this.numContainer.Size = new System.Drawing.Size(113, 30);
            this.numContainer.TabIndex = 33;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(149, 435);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 22);
            this.label3.TabIndex = 32;
            this.label3.Text = "# of Servings";
            // 
            // numProtein
            // 
            this.numProtein.Enabled = false;
            this.numProtein.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numProtein.Location = new System.Drawing.Point(681, 505);
            this.numProtein.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numProtein.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numProtein.Name = "numProtein";
            this.numProtein.Size = new System.Drawing.Size(203, 30);
            this.numProtein.TabIndex = 57;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(609, 507);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 22);
            this.label12.TabIndex = 56;
            this.label12.Text = "Protein";
            // 
            // numCarbs
            // 
            this.numCarbs.Enabled = false;
            this.numCarbs.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numCarbs.Location = new System.Drawing.Point(682, 361);
            this.numCarbs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numCarbs.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numCarbs.Name = "numCarbs";
            this.numCarbs.Size = new System.Drawing.Size(202, 30);
            this.numCarbs.TabIndex = 55;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(621, 363);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 22);
            this.label11.TabIndex = 54;
            this.label11.Text = "Carbs";
            // 
            // numSugars
            // 
            this.numSugars.Enabled = false;
            this.numSugars.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSugars.Location = new System.Drawing.Point(680, 433);
            this.numSugars.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numSugars.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numSugars.Name = "numSugars";
            this.numSugars.Size = new System.Drawing.Size(204, 30);
            this.numSugars.TabIndex = 53;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(611, 435);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 22);
            this.label10.TabIndex = 52;
            this.label10.Text = "Sugars";
            // 
            // numSodium
            // 
            this.numSodium.Enabled = false;
            this.numSodium.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSodium.Location = new System.Drawing.Point(682, 280);
            this.numSodium.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numSodium.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numSodium.Name = "numSodium";
            this.numSodium.Size = new System.Drawing.Size(202, 30);
            this.numSodium.TabIndex = 51;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(607, 282);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 22);
            this.label9.TabIndex = 50;
            this.label9.Text = "Sodium";
            // 
            // numFat
            // 
            this.numFat.Enabled = false;
            this.numFat.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numFat.Location = new System.Drawing.Point(682, 210);
            this.numFat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numFat.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numFat.Name = "numFat";
            this.numFat.Size = new System.Drawing.Size(202, 30);
            this.numFat.TabIndex = 49;
            // 
            // txtFat
            // 
            this.txtFat.AutoSize = true;
            this.txtFat.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFat.Location = new System.Drawing.Point(642, 212);
            this.txtFat.Name = "txtFat";
            this.txtFat.Size = new System.Drawing.Size(34, 22);
            this.txtFat.TabIndex = 48;
            this.txtFat.Text = "Fat";
            // 
            // numCalories
            // 
            this.numCalories.Enabled = false;
            this.numCalories.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numCalories.Location = new System.Drawing.Point(682, 158);
            this.numCalories.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numCalories.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numCalories.Name = "numCalories";
            this.numCalories.Size = new System.Drawing.Size(202, 30);
            this.numCalories.TabIndex = 47;
            // 
            // txtxCalories
            // 
            this.txtxCalories.AutoSize = true;
            this.txtxCalories.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtxCalories.Location = new System.Drawing.Point(601, 160);
            this.txtxCalories.Name = "txtxCalories";
            this.txtxCalories.Size = new System.Drawing.Size(74, 22);
            this.txtxCalories.TabIndex = 46;
            this.txtxCalories.Text = "Calories";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(542, 575);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 22);
            this.label5.TabIndex = 45;
            this.label5.Text = "Unit of Measure";
            // 
            // txtUoM
            // 
            this.txtUoM.Enabled = false;
            this.txtUoM.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUoM.Location = new System.Drawing.Point(682, 572);
            this.txtUoM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtUoM.Name = "txtUoM";
            this.txtUoM.Size = new System.Drawing.Size(205, 30);
            this.txtUoM.TabIndex = 44;
            this.txtUoM.Text = "Servings";
            // 
            // txtServingSize
            // 
            this.txtServingSize.Enabled = false;
            this.txtServingSize.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServingSize.Location = new System.Drawing.Point(267, 361);
            this.txtServingSize.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtServingSize.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.txtServingSize.Name = "txtServingSize";
            this.txtServingSize.Size = new System.Drawing.Size(113, 30);
            this.txtServingSize.TabIndex = 59;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(129, 575);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(132, 22);
            this.label13.TabIndex = 58;
            this.label13.Text = "Depleted Count";
            // 
            // txtUPC
            // 
            this.txtUPC.Enabled = false;
            this.txtUPC.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUPC.Location = new System.Drawing.Point(618, 101);
            this.txtUPC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtUPC.MaxLength = 11;
            this.txtUPC.Name = "txtUPC";
            this.txtUPC.Size = new System.Drawing.Size(266, 30);
            this.txtUPC.TabIndex = 60;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(573, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 22);
            this.label14.TabIndex = 61;
            this.label14.Text = "UPC";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1044, 9);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 192);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 63;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1044, 212);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(128, 58);
            this.button3.TabIndex = 62;
            this.button3.Text = "Edit Icon";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtType
            // 
            this.txtType.Enabled = false;
            this.txtType.Font = new System.Drawing.Font("Lucida Grande", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtType.Location = new System.Drawing.Point(205, 93);
            this.txtType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(177, 57);
            this.txtType.TabIndex = 66;
            // 
            // cmdDelete
            // 
            this.cmdDelete.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdDelete.Location = new System.Drawing.Point(451, 645);
            this.cmdDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmdDelete.Name = "cmdDelete";
            this.cmdDelete.Size = new System.Drawing.Size(161, 77);
            this.cmdDelete.TabIndex = 67;
            this.cmdDelete.Text = "Delete Food";
            this.cmdDelete.UseVisualStyleBackColor = true;
            this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
            // 
            // cmdAddtoList
            // 
            this.cmdAddtoList.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdAddtoList.Location = new System.Drawing.Point(651, 645);
            this.cmdAddtoList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmdAddtoList.Name = "cmdAddtoList";
            this.cmdAddtoList.Size = new System.Drawing.Size(161, 77);
            this.cmdAddtoList.TabIndex = 68;
            this.cmdAddtoList.Text = "Add To Shopping List";
            this.cmdAddtoList.UseVisualStyleBackColor = true;
            this.cmdAddtoList.Click += new System.EventHandler(this.button6_Click);
            // 
            // cmdUpdateFood
            // 
            this.cmdUpdateFood.Enabled = false;
            this.cmdUpdateFood.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdUpdateFood.Location = new System.Drawing.Point(253, 645);
            this.cmdUpdateFood.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmdUpdateFood.Name = "cmdUpdateFood";
            this.cmdUpdateFood.Size = new System.Drawing.Size(161, 77);
            this.cmdUpdateFood.TabIndex = 69;
            this.cmdUpdateFood.Text = "Update Food";
            this.cmdUpdateFood.UseVisualStyleBackColor = true;
            this.cmdUpdateFood.Click += new System.EventHandler(this.button7_Click);
            // 
            // cmdAddtoMeal
            // 
            this.cmdAddtoMeal.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdAddtoMeal.Location = new System.Drawing.Point(854, 645);
            this.cmdAddtoMeal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmdAddtoMeal.Name = "cmdAddtoMeal";
            this.cmdAddtoMeal.Size = new System.Drawing.Size(161, 77);
            this.cmdAddtoMeal.TabIndex = 91;
            this.cmdAddtoMeal.Text = "Add to Meal";
            this.cmdAddtoMeal.UseVisualStyleBackColor = true;
            this.cmdAddtoMeal.Click += new System.EventHandler(this.cmdAddtoMeal_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(1044, 301);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(128, 24);
            this.textBox5.TabIndex = 65;
            this.textBox5.Visible = false;
            // 
            // numQuantity
            // 
            this.numQuantity.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numQuantity.Location = new System.Drawing.Point(970, 610);
            this.numQuantity.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.numQuantity.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numQuantity.Name = "numQuantity";
            this.numQuantity.Size = new System.Drawing.Size(45, 30);
            this.numQuantity.TabIndex = 168;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Cursor = System.Windows.Forms.Cursors.Default;
            this.label15.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(892, 612);
            this.label15.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(76, 22);
            this.label15.TabIndex = 167;
            this.label15.Text = "Quantity";
            // 
            // cmdEditFood
            // 
            this.cmdEditFood.Location = new System.Drawing.Point(1044, 361);
            this.cmdEditFood.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmdEditFood.Name = "cmdEditFood";
            this.cmdEditFood.Size = new System.Drawing.Size(128, 58);
            this.cmdEditFood.TabIndex = 169;
            this.cmdEditFood.Text = "Edit Food Item";
            this.cmdEditFood.UseVisualStyleBackColor = true;
            this.cmdEditFood.Click += new System.EventHandler(this.cmdEditFood_Click);
            // 
            // lstFoodType
            // 
            this.lstFoodType.Enabled = false;
            this.lstFoodType.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstFoodType.FormattingEnabled = true;
            this.lstFoodType.ItemHeight = 22;
            this.lstFoodType.Items.AddRange(new object[] {
            "Fruit",
            "Veg",
            "Meat",
            "Snack",
            "Drink",
            "Other"});
            this.lstFoodType.Location = new System.Drawing.Point(205, 93);
            this.lstFoodType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lstFoodType.Name = "lstFoodType";
            this.lstFoodType.Size = new System.Drawing.Size(177, 224);
            this.lstFoodType.TabIndex = 23;
            this.lstFoodType.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // foodadd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1282, 724);
            this.Controls.Add(this.cmdEditFood);
            this.Controls.Add(this.numQuantity);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cmdAddtoMeal);
            this.Controls.Add(this.cmdUpdateFood);
            this.Controls.Add(this.cmdAddtoList);
            this.Controls.Add(this.cmdDelete);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtUPC);
            this.Controls.Add(this.txtServingSize);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.numProtein);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.numCarbs);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.numSugars);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.numSodium);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.numFat);
            this.Controls.Add(this.txtFat);
            this.Controls.Add(this.numCalories);
            this.Controls.Add(this.txtxCalories);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtUoM);
            this.Controls.Add(this.numDepleted);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.numServings);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numContainer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.cmdAddFood);
            this.Controls.Add(this.lstFoodType);
            this.Controls.Add(this.txtType);
            this.Font = new System.Drawing.Font("Lucida Grande", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "foodadd";
            this.Text = "Food Item Details Screen";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.foodadd_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblFoodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kitchenDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDepleted)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numServings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numContainer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProtein)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCarbs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSugars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSodium)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCalories)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtServingSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button cmdAddFood;
        private KitchenDataSet1 kitchenDataSet1;
        private System.Windows.Forms.BindingSource tblFoodBindingSource;
        private KitchenDataSet1TableAdapters.tblFoodTableAdapter tblFoodTableAdapter;
        private System.Windows.Forms.NumericUpDown numDepleted;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numServings;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numContainer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numProtein;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numCarbs;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numSugars;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numSodium;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown numFat;
        private System.Windows.Forms.Label txtFat;
        private System.Windows.Forms.NumericUpDown numCalories;
        private System.Windows.Forms.Label txtxCalories;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUoM;
        private System.Windows.Forms.NumericUpDown txtServingSize;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtUPC;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Button cmdDelete;
        private System.Windows.Forms.Button cmdAddtoList;
        private System.Windows.Forms.Button cmdUpdateFood;
        private System.Windows.Forms.Button cmdAddtoMeal;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.NumericUpDown numQuantity;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button cmdEditFood;
        private System.Windows.Forms.ListBox lstFoodType;
    }
}