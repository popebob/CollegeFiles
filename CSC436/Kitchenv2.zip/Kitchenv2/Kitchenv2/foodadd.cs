﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using System.IO;

namespace Kitchenv2
{
    public partial class foodadd : Form
    {
        //static string connect = "Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;Persist Security Info=False;";
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        //SqlCeConnection con = new SqlCeConnection(@"Data Source=C:\Users\winb83\Desktop\Kitchenv2\Kitchenv2\Kitchenv2\Kitchen.sdf;");

        DataSet ds = new DataSet();
        //SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\D1.mdf;Integrated Security=True;User Instance=True");
        //SqlCeConnection con = new SqlCeConnection(connect);
        //"Data Source = MyDatabase.sdf;"
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand cmd; //sql command
        SqlCeCommand command; //sql command
        string ftype; //string for food type
        string upc; //upc from scanner
        string foodname; //name of food for info pull
        bool foodexist; //does the food already exist in the food db
        bool fromscan; //was form called from scanner form
        bool upcfound; //assumes upc was found and is set to true if upc wasn't found then set to false
        int quantity; //from food db
        private Form1 mainForm; //handle for main form
        private foodaddscanner foodscannerform;
        Label ll;
        NumericUpDown mm;

        bool hasicon; //does the user have an icon?
        bool frommain; //was this called from the main form

        OpenFileDialog ofd;
        public foodadd()
        {
            InitializeComponent();
            foodexist = false;
            fromscan = false;
            upcfound = true;
            numContainer.Minimum = 1;
            txtType.Visible = false;
            lstFoodType.Visible = true;
        }
        //get handle on main form
        public foodadd(Form1 m)
        {            
            InitializeComponent();
            foodexist = false;
            fromscan = false;
            upcfound = true;
            txtType.Visible = false;
            lstFoodType.Visible = true;
            numContainer.Minimum = 1;
            mainForm = m;

        }
        //show food info
        public foodadd(Form1 m, string fn, Label l, NumericUpDown m2)
        {
            InitializeComponent();
            mainForm = m;
            ll = l;
            mm = m2;
            foodname = fn;
            txtType.Visible = true;
            lstFoodType.Visible = false;
            //MessageBox.Show(foodname);
            getFoodInfo();
            //this overloaded method means the food exists, so you don't need Add New
            cmdAddFood.Enabled = false;
            //make the QTY sensical
            if (numQuantity.Value >= mm.Minimum)
                    numQuantity.Value = mm.Value;

        }
        //from upc
        public foodadd(Form1 m, foodaddscanner fs, string u)
        {
            InitializeComponent();
            foodexist = false;
            fromscan = true;
            upcfound = true;
            txtType.Visible = false;
            lstFoodType.Visible = true;
            cmdDelete.Enabled = false;
            numContainer.Minimum = 1;
            mainForm = m;
            foodscannerform = fs;
            upc = u;
            txtUPC.Text = u;


        }
        //from upc
        public foodadd(Form1 m, foodaddscanner fs, string u, string fn, string ft)
        {
            InitializeComponent();
            foodexist = false;
            fromscan = true;
            upcfound = true;
            txtType.Visible = true;
            lstFoodType.Visible = false;
            numContainer.Minimum = 1;
            mainForm = m;
            foodscannerform = fs;
            upc = u;
            txtUPC.Text = upc;
            txtName.Text = fn;
            txtType.Text = ft;

        }
        //
        //user adds food to food db name comes from textbox type comes from listbox quantity comes from updown
        void addfood()
        {
            // Open Connection
            con.Open();
            upc = txtUPC.Text;
            checkupcdb();
            while (upcfound != true || upc == "")
                checkupcdb();


            command = con.CreateCommand();
            command.CommandText = "INSERT INTO tblFood (foodname, foodtype, quantity, Depletedcount ) VALUES (@FOODNAME, @FOODTYPE, @quantity, @Depletedcount)";
            //servingsize, servingsper, fat, sodium, sugars, carbs, protein, Depletedcount
            SqlCeParameter param = null;

            param = new SqlCeParameter("@FOODNAME", SqlDbType.NVarChar,100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@FOODTYPE", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@quantity", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@Depletedcount", SqlDbType.Int);
            command.Parameters.Add(param);

            command.Parameters["@FOODNAME"].Size = 100;
            command.Parameters["@FOODTYPE"].Size = 100;
            command.Prepare();
            command.Parameters[0].Value = txtName.Text;
            if (ftype == null)
                ftype = txtType.Text;
            command.Parameters[1].Value = ftype;
            command.Parameters[2].Value = numContainer.Value;
            command.Parameters[3].Value = txtServingSize.Value;

            command.ExecuteNonQuery();


            if (fromscan || upcfound)
            {
                command = con.CreateCommand();
                command.CommandText = "INSERT INTO tblUPC (UPC, FOODNAME, FOODTYPE, uofm, calories, servingsize, servingsper, fat, sodium, sugars, carbs, protein) VALUES (@UPC, @FOODNAME, @FOODTYPE,  @uofm, @calories, @servingsize, @servingsper, @fat, @sodium, @sugars, @carbs, @protein)";
                param = null;
                param = new SqlCeParameter("@UPC", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@FOODNAME", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@FOODTYPE", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@uofm", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@calories", SqlDbType.Int);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@servingsize", SqlDbType.Float);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@servingsper", SqlDbType.Float);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@fat", SqlDbType.Float);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@sodium", SqlDbType.Float);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@sugars", SqlDbType.Float);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@carbs", SqlDbType.Float);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@protein", SqlDbType.Float);
                command.Parameters.Add(param);
                command.Parameters["@UPC"].Size = 100;
                command.Parameters["@FOODNAME"].Size = 100;
                command.Parameters["@FOODTYPE"].Size = 100;
                command.Prepare();
                //upc
                command.Parameters[0].Value = upc;
                //foodname
                command.Parameters[1].Value = txtName.Text;
                //foodtype
                command.Parameters[2].Value = ftype;
                //uom
                command.Parameters[3].Value = txtUoM.Text;
                //calories
                command.Parameters[4].Value = numCalories.Value;
                //serving size
                command.Parameters[5].Value = (float)numServings.Value;
                //servings per
                command.Parameters[6].Value = (float)numDepleted.Value;
                //fat
                command.Parameters[7].Value = (float)numFat.Value;
                //sodium
                command.Parameters[8].Value = (float)numSodium.Value;
                //sugars
                command.Parameters[9].Value = (float)numSugars.Value;
                //carbs
                command.Parameters[10].Value = (float)numCarbs.Value;
                //protein
                command.Parameters[11].Value = (float)numProtein.Value;
                command.ExecuteNonQuery();                
            }            
            con.Close();

        }
        void getFoodInfo()
        {
            //MessageBox.Show(foodname);
            con.Open();
            //MessageBox.Show(s[i]);
            //cmd = new SqlCommand(s[i], con);
            command = new SqlCeCommand("SELECT * FROM tblUpc where foodname = @foodname", con);
            //cmd.Parameters.Add("@" + colnames[i], SqlDbType.VarChar).Value = textBox12.Text;
            SqlCeParameter param = null;
            param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = foodname;
            //MessageBox.Show(recipefrommeal[j].name + " " + recipefrommeal[j].quantity.ToString());
            SqlCeDataReader reader = null;

            //execute the search and save results in reader
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {

                //UPC, FOODNAME, FOODTYPE, uofm, calories, servingsize, servingsper, fat, sodium, sugars, carbs, protein
                //command.Parameters[0].Value = textBox3.Text;
                //foodname
                txtName.Text = reader[1].ToString();
                //foodtype
                txtType.Text = reader[2].ToString();
                //uom
                txtUoM.Text = reader[3].ToString();
                //upc
                txtUPC.Text = reader[0].ToString();
                //calories
                numCalories.Value = Convert.ToDecimal(reader[4]);
                //servingsize
                numServings.Value = Convert.ToDecimal(reader[10]);
                //servingsper
                numDepleted.Value = Convert.ToDecimal(reader[11]);
                //fat
                numFat.Value = Convert.ToDecimal(reader[5]);
                //sodium
                numSodium.Value = Convert.ToDecimal(reader[6]);
                //sugars
                numSugars.Value = Convert.ToDecimal(reader[7]);
                //carbs
                numCarbs.Value = Convert.ToDecimal(reader[8]);
                //protein
                numProtein.Value = Convert.ToDecimal(reader[9]);
                //servingsper
                numContainer.Value = Convert.ToDecimal(reader[10]);

                upc = txtUPC.Text;
            }
            command = new SqlCeCommand("SELECT * FROM tblFood where foodname = @foodname", con);
            //cmd.Parameters.Add("@" + colnames[i], SqlDbType.VarChar).Value = textBox12.Text;
            param = null;
            param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = txtName.Text;
            //MessageBox.Show(recipefrommeal[j].name + " " + recipefrommeal[j].quantity.ToString());
            reader = null;

            //execute the search and save results in reader
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {
                numServings.Value = Convert.ToDecimal(reader[3]);
                txtServingSize.Value = Convert.ToDecimal(reader[4]);
            }
            con.Close();
            numQuantity.Maximum = numServings.Value;
            mainForm.showmain();
        }

        void updatefood()
        {
            con.Open();
            command = con.CreateCommand();
            command.CommandText = "UPDATE tblUpc SET foodname = @foodname, foodtype = @foodtype, uofm = @uofm, calories = @calories, servingsize = @servingsize, servingsper = @servingsper, fat = @fat, sodium = @sodium, sugars = @sugars, carbs = @carbs, protein = @protein WHERE foodname = @foodname2";
            SqlCeParameter param = null;
            param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@FOODTYPE", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@uofm", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@calories", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@servingsize", SqlDbType.Float);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@servingsper", SqlDbType.Float);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@fat", SqlDbType.Float);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@sodium", SqlDbType.Float);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@sugars", SqlDbType.Float);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@carbs", SqlDbType.Float);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@protein", SqlDbType.Float);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@foodname2", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();            
            //foodname
            command.Parameters[0].Value = txtName.Text;
            //foodtype
            command.Parameters[1].Value = txtType.Text;
            //uom
            command.Parameters[2].Value = txtUoM.Text;
            //calories
            command.Parameters[3].Value = numCalories.Value;
            //serving size
            command.Parameters[4].Value = (float)numServings.Value;
            //servings per
            command.Parameters[5].Value = (float)numDepleted.Value;
            //fat
            command.Parameters[6].Value = (float)numFat.Value;
            //sodium
            command.Parameters[7].Value = (float)numSodium.Value;
            //sugars
            command.Parameters[8].Value = (float)numSugars.Value;
            //carbs
            command.Parameters[9].Value = (float)numCarbs.Value;
            //protein
            command.Parameters[10].Value = (float)numProtein.Value;
            //upc
            command.Parameters[11].Value = foodname;
            command.ExecuteNonQuery();
            command = con.CreateCommand();
            command.CommandText = "UPDATE tblFood SET foodname = @foodname, foodtype = @foodtype, quantity = @quantity, Depletedcount = @Depletedcount where foodname = @foodname2";
            //servingsize, servingsper, fat, sodium, sugars, carbs, protein, Depletedcount
            param = null;

            param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@foodtype", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@quantity", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@Depletedcount", SqlDbType.Int);
            command.Parameters.Add(param);
            param = new SqlCeParameter("@FOODNAME2", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Prepare();
            command.Parameters[0].Value = txtName.Text;
            command.Parameters[1].Value = txtType.Text;
            command.Parameters[2].Value = (float)numServings.Value;
            command.Parameters[3].Value = (float)numDepleted.Value;
            command.Parameters[4].Value = foodname;
            command.ExecuteNonQuery();
            con.Close();
            foodname = txtName.Text;
        }
        void checkfooddb()
        {
            // Open Connection
            con.Open();
            //command for user / pass search
            command = new SqlCeCommand("SELECT * FROM tblFood WHERE foodname = @foodname", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@FOODNAME", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@FOODNAME"].Size = 100;
            command.Parameters[0].Value = txtName.Text;
            command.Prepare();
            //reader to hold the results of the search
            SqlCeDataReader reader = null;
            //execute the search and save results in reader
            reader = command.ExecuteReader();
            //if food name found show message
            while (reader.Read())
            {                
                quantity = (int)reader[3];
                foodexist = true;
            }
            //close connection
            con.Close();
        }
        void checkupcdb()
        {

            upcfound = true;
            command = new SqlCeCommand("SELECT * FROM tblUpc WHERE upc = @UPC", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@UPC", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@UPC"].Size = 100;
            //command.Parameters[0].Value = upc;
            command.Prepare();
            command.Parameters[0].Value = upc;
            SqlCeDataReader reader = null;
            reader = command.ExecuteReader();
            //if upc found set upcfound
            while (reader.Read())
            {
                //upcfount ini to true if a upc is really found set it to false
                upcfound = false;
                mainForm.SendToBack();
                this.SendToBack();
                upc = Microsoft.VisualBasic.Interaction.InputBox("Please enter a different UPC for food item " + txtName.Text, "text", "", 100, 100);                
                mainForm.TopMost = true;
                this.TopMost = true;

            }
            MessageBox.Show(upc);
        }
        void addicon()
        {
            try
            {
                ofd = new OpenFileDialog();
                if (ofd.ShowDialog() == DialogResult.OK)
                {


                    textBox5.Text = ofd.FileName;
                    foodname = txtName.Text;
                    byte[] photo = File.ReadAllBytes(textBox5.Text);

                    con.Open();
                    command = con.CreateCommand();
                    command.CommandText = "UPDATE tblFood SET icon = @icon WHERE foodname = @foodname";
                    SqlCeParameter param = null;
                    param = new SqlCeParameter("@icon", SqlDbType.VarBinary, 8000);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    command.Parameters["@foodname"].Size = 100;
                    command.Parameters[0].Value = photo;
                    command.Parameters[1].Value = foodname;
                    command.Prepare();
                    //execute the command and update the daily calories
                    command.ExecuteNonQuery();
                    MessageBox.Show("Data inserted");
                    con.Close();
                    showicon();


                }
            }
            catch (Exception e2)
            {
                MessageBox.Show("Error adding icon");
                MessageBox.Show(e2.ToString());
            }

        }
        void showicon()
        {
            foodname = txtName.Text;
            MemoryStream m = null;
            con.Open();
            //code to show image again
            byte[] photo;
            //command to get all users from the user table
            command = new SqlCeCommand("SELECT * FROM tblFood WHERE foodname = @foodname", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@foodname"].Size = 100;
            command.Parameters[0].Value = foodname;
            command.Prepare();
            SqlCeDataReader reader = null;
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {
                if (reader[5] != DBNull.Value)
                {
                    photo = (byte[])reader[5];
                    //pictureBox1.Image = (Image)reader[10];
                    m = new MemoryStream(photo);
                    hasicon = true;
                }
            }
            if (hasicon)
            {                
                pictureBox1.Image = Image.FromStream(m);
                //Form1.foodicon = (Bitmap)pictureBox1.Image;
                if (frommain)
                    mainForm.showicon();

            }
            else
                MessageBox.Show("Food doesn't have an icon");

            con.Close();

        }

        //allows user to delete food from db 
        void deletefood()
        {
            //open the connection 
            con.Open();
            //set command to remove the row the user has selected by using the unique item ID
            command = con.CreateCommand();
            command.CommandText = "Delete FROM tblFood WHERE foodname = @foodname";
            SqlCeParameter param = null;
            param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@foodname"].Size = 100;
            command.Parameters[0].Value = foodname;
            command.Prepare();
            command.ExecuteNonQuery();
            con.Close();
            Close();
        }

        private void cmdAddFood_Click(object sender, EventArgs e)
        {
            //check to see if food is already in food db, if it is update the count if not add it to food db
            checkfooddb();
            if (foodexist)
            {
                updatefood();
                MessageBox.Show("Food Count Updated");
            }
            else
            {
                if (lstFoodType.Enabled == true) //was visible is now enabled
                {
                    if (lstFoodType.SelectedIndex < 0 || lstFoodType.SelectedIndex == 5)
                    {
                        //mainForm.TopMost = false;
                        this.TopMost = false;
                        ftype = Microsoft.VisualBasic.Interaction.InputBox("Please enter food type for " + txtName.Text, "text", "", 100, 100);
                        //mainForm.TopMost = true;
                                              
                        
                    }this.TopMost = true;  
                }
                addfood();
                MessageBox.Show("Food Added");
                
            }
            
            if (fromscan)
            {
                int w = 1;
                //foodscannerform.textBox1.Text = upc;
                //foodscannerform.label3.Text = "Food or upc wasn't found.";
            }
            //else
            //foodbrowserform.showfood();
            mainForm.showmain();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            mainForm.showmain();
            Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //set food type
            ftype = lstFoodType.SelectedItem.ToString();
        }

        private void foodadd_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'kitchenDataSet1.tblFood' table. You can move, or remove it, as needed.
            //this.tblFoodTableAdapter.Fill(this.kitchenDataSet1.tblFood);
            this.txtName.Focus();
            txtName.Select(5, 5);
            //get QTY from mainscreen
            showicon();

        }
        protected override void OnShown(EventArgs e)
        {
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = this.txtName.Text.Length;
            base.OnShown(e);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            showicon();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addicon();
            mainForm.showmain();
        }

        private void cmdDelete_Click(object sender, EventArgs e)
        {
            deletefood();
            //form 1 needs to be reloaded
            mainForm.showmain();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //these functions need to be changed to public on form 1

            //addtocart();
            //viewCart();
            mainForm.addtocart(ll, numQuantity);
            mainForm.showmain("SELECT * FROM tblFood where quantity > Depletedcount");
            mainForm.function = 0;
            mainForm.mealcartswitch();
            MessageBox.Show(numQuantity.Value.ToString() + " added to Shopping List !! ");
            Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //            updatefood();
            //form 1 needs to be reloaded
            //mainForm.showmain();
            try
            {
                updatefood();
            }
            catch (Exception e3)
            {
                MessageBox.Show("Error");
                MessageBox.Show(e3.ToString());
            }
            mainForm.showmain();
        }

        private void cmdAddtoMeal_Click(object sender, EventArgs e)
        {
            mainForm.addMeal(ll, numQuantity);
            mainForm.showmain();
            mainForm.function = 1;
            mainForm.mealcartswitch();
            MessageBox.Show(numQuantity.Value.ToString() + " added to Meal !! ");
            Close();
        }

        private void cmdEditFood_Click(object sender, EventArgs e)
        {
            lstFoodType.Enabled = true;
            txtName.Enabled = true;
            txtType.Enabled = true;
            txtServingSize.Enabled = true;
            numServings.Enabled = true;
            numContainer.Enabled = true;
            numDepleted.Enabled = true;
            numCalories.Enabled = true;
            numFat.Enabled = true;
            numSodium.Enabled = true;
            numCarbs.Enabled = true;
            numSugars.Enabled = true;
            numProtein.Enabled = true;
            txtUoM.Enabled = true;
            cmdEditFood.Enabled = false;
            cmdUpdateFood.Enabled = true;
            cmdAddtoList.Enabled = false;
            cmdAddtoMeal.Enabled = false;

        }


    }
}
