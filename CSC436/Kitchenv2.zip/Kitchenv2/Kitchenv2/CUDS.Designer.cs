﻿namespace Kitchenv2
{
    partial class CUDS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdCreateUser = new System.Windows.Forms.Button();
            this.cmdClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmdEditIcon = new System.Windows.Forms.Button();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.picUserIcon = new System.Windows.Forms.PictureBox();
            this.cmdEditUser = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.cmdRemoveUser = new System.Windows.Forms.Button();
            this.datUsers = new System.Windows.Forms.DataGridView();
            this.cmdSwitchUser = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.datDailyLog = new System.Windows.Forms.DataGridView();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.cmdNewUser = new System.Windows.Forms.Button();
            this.cmdChangeUser = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmdLogOut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picUserIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datDailyLog)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdCreateUser
            // 
            this.cmdCreateUser.Enabled = false;
            this.cmdCreateUser.Location = new System.Drawing.Point(30, 232);
            this.cmdCreateUser.Margin = new System.Windows.Forms.Padding(2);
            this.cmdCreateUser.Name = "cmdCreateUser";
            this.cmdCreateUser.Size = new System.Drawing.Size(93, 54);
            this.cmdCreateUser.TabIndex = 0;
            this.cmdCreateUser.Text = "Create Account";
            this.cmdCreateUser.UseVisualStyleBackColor = true;
            this.cmdCreateUser.Click += new System.EventHandler(this.cmdCreateUser_Click);
            // 
            // cmdClose
            // 
            this.cmdClose.Location = new System.Drawing.Point(281, 232);
            this.cmdClose.Margin = new System.Windows.Forms.Padding(2);
            this.cmdClose.Name = "cmdClose";
            this.cmdClose.Size = new System.Drawing.Size(93, 54);
            this.cmdClose.TabIndex = 1;
            this.cmdClose.Text = "Close";
            this.cmdClose.UseVisualStyleBackColor = true;
            this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "User Name";
            // 
            // cmdEditIcon
            // 
            this.cmdEditIcon.Enabled = false;
            this.cmdEditIcon.Location = new System.Drawing.Point(431, 230);
            this.cmdEditIcon.Margin = new System.Windows.Forms.Padding(2);
            this.cmdEditIcon.Name = "cmdEditIcon";
            this.cmdEditIcon.Size = new System.Drawing.Size(93, 54);
            this.cmdEditIcon.TabIndex = 3;
            this.cmdEditIcon.Text = "Edit Icon";
            this.cmdEditIcon.UseVisualStyleBackColor = true;
            this.cmdEditIcon.Click += new System.EventHandler(this.cmdEditIcon_Click);
            // 
            // txtUserName
            // 
            this.txtUserName.Enabled = false;
            this.txtUserName.Location = new System.Drawing.Point(151, 32);
            this.txtUserName.Margin = new System.Windows.Forms.Padding(2);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(223, 26);
            this.txtUserName.TabIndex = 4;
            // 
            // txtWeight
            // 
            this.txtWeight.Enabled = false;
            this.txtWeight.Location = new System.Drawing.Point(151, 62);
            this.txtWeight.Margin = new System.Windows.Forms.Padding(2);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(223, 26);
            this.txtWeight.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 64);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "Weight";
            // 
            // txtHeight
            // 
            this.txtHeight.Enabled = false;
            this.txtHeight.Location = new System.Drawing.Point(151, 91);
            this.txtHeight.Margin = new System.Windows.Forms.Padding(2);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(223, 26);
            this.txtHeight.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 93);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Height";
            // 
            // txtAge
            // 
            this.txtAge.Enabled = false;
            this.txtAge.Location = new System.Drawing.Point(151, 121);
            this.txtAge.Margin = new System.Windows.Forms.Padding(2);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(223, 26);
            this.txtAge.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 123);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Age";
            // 
            // picUserIcon
            // 
            this.picUserIcon.Location = new System.Drawing.Point(406, 32);
            this.picUserIcon.Margin = new System.Windows.Forms.Padding(2);
            this.picUserIcon.Name = "picUserIcon";
            this.picUserIcon.Size = new System.Drawing.Size(150, 192);
            this.picUserIcon.TabIndex = 11;
            this.picUserIcon.TabStop = false;
            // 
            // cmdEditUser
            // 
            this.cmdEditUser.Enabled = false;
            this.cmdEditUser.Location = new System.Drawing.Point(151, 232);
            this.cmdEditUser.Margin = new System.Windows.Forms.Padding(2);
            this.cmdEditUser.Name = "cmdEditUser";
            this.cmdEditUser.Size = new System.Drawing.Size(93, 54);
            this.cmdEditUser.TabIndex = 14;
            this.cmdEditUser.Text = "Save Change";
            this.cmdEditUser.UseVisualStyleBackColor = true;
            this.cmdEditUser.Click += new System.EventHandler(this.cmdEditUser_Click);
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Location = new System.Drawing.Point(429, 3);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(95, 26);
            this.textBox5.TabIndex = 16;
            this.textBox5.Visible = false;
            // 
            // cmdRemoveUser
            // 
            this.cmdRemoveUser.Location = new System.Drawing.Point(1084, 3);
            this.cmdRemoveUser.Name = "cmdRemoveUser";
            this.cmdRemoveUser.Size = new System.Drawing.Size(94, 23);
            this.cmdRemoveUser.TabIndex = 292;
            this.cmdRemoveUser.Text = "Remove User";
            this.cmdRemoveUser.UseVisualStyleBackColor = true;
            this.cmdRemoveUser.Click += new System.EventHandler(this.cmdRemoveUser_Click);
            // 
            // datUsers
            // 
            this.datUsers.AllowUserToAddRows = false;
            this.datUsers.AllowUserToDeleteRows = false;
            this.datUsers.AllowUserToResizeColumns = false;
            this.datUsers.AllowUserToResizeRows = false;
            this.datUsers.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.datUsers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.datUsers.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datUsers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datUsers.GridColor = System.Drawing.SystemColors.Menu;
            this.datUsers.Location = new System.Drawing.Point(754, 32);
            this.datUsers.Name = "datUsers";
            this.datUsers.ReadOnly = true;
            this.datUsers.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datUsers.RowHeadersVisible = false;
            this.datUsers.RowTemplate.Height = 24;
            this.datUsers.Size = new System.Drawing.Size(424, 254);
            this.datUsers.TabIndex = 291;
            // 
            // cmdSwitchUser
            // 
            this.cmdSwitchUser.Location = new System.Drawing.Point(754, 3);
            this.cmdSwitchUser.Name = "cmdSwitchUser";
            this.cmdSwitchUser.Size = new System.Drawing.Size(94, 23);
            this.cmdSwitchUser.TabIndex = 289;
            this.cmdSwitchUser.Text = "Switch User";
            this.cmdSwitchUser.UseVisualStyleBackColor = true;
            this.cmdSwitchUser.Click += new System.EventHandler(this.cmdSwitchUser_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Font = new System.Drawing.Font("Lucida Grande", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthCalendar1.Location = new System.Drawing.Point(951, 300);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 301;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // datDailyLog
            // 
            this.datDailyLog.AllowUserToAddRows = false;
            this.datDailyLog.AllowUserToDeleteRows = false;
            this.datDailyLog.AllowUserToResizeColumns = false;
            this.datDailyLog.AllowUserToResizeRows = false;
            this.datDailyLog.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.datDailyLog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.datDailyLog.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datDailyLog.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datDailyLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datDailyLog.GridColor = System.Drawing.SystemColors.Menu;
            this.datDailyLog.Location = new System.Drawing.Point(9, 300);
            this.datDailyLog.Name = "datDailyLog";
            this.datDailyLog.ReadOnly = true;
            this.datDailyLog.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datDailyLog.RowHeadersVisible = false;
            this.datDailyLog.RowTemplate.Height = 24;
            this.datDailyLog.Size = new System.Drawing.Size(937, 399);
            this.datDailyLog.TabIndex = 300;
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(999, 481);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(116, 26);
            this.txtDate.TabIndex = 298;
            this.txtDate.Visible = false;
            // 
            // cmdNewUser
            // 
            this.cmdNewUser.Location = new System.Drawing.Point(30, 170);
            this.cmdNewUser.Margin = new System.Windows.Forms.Padding(2);
            this.cmdNewUser.Name = "cmdNewUser";
            this.cmdNewUser.Size = new System.Drawing.Size(93, 54);
            this.cmdNewUser.TabIndex = 302;
            this.cmdNewUser.Text = "&New User";
            this.cmdNewUser.UseVisualStyleBackColor = true;
            this.cmdNewUser.Click += new System.EventHandler(this.cmdNewUser_Click);
            // 
            // cmdChangeUser
            // 
            this.cmdChangeUser.Enabled = false;
            this.cmdChangeUser.Location = new System.Drawing.Point(151, 170);
            this.cmdChangeUser.Margin = new System.Windows.Forms.Padding(2);
            this.cmdChangeUser.Name = "cmdChangeUser";
            this.cmdChangeUser.Size = new System.Drawing.Size(93, 54);
            this.cmdChangeUser.TabIndex = 303;
            this.cmdChangeUser.Text = "Change Details";
            this.cmdChangeUser.UseVisualStyleBackColor = true;
            this.cmdChangeUser.Click += new System.EventHandler(this.cmdChangeUser_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(952, 542);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 18);
            this.label5.TabIndex = 305;
            this.label5.Text = "Total Calories for the day:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1163, 565);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 18);
            this.label6.TabIndex = 306;
            this.label6.Text = "-";
            // 
            // cmdLogOut
            // 
            this.cmdLogOut.Location = new System.Drawing.Point(922, 3);
            this.cmdLogOut.Name = "cmdLogOut";
            this.cmdLogOut.Size = new System.Drawing.Size(94, 23);
            this.cmdLogOut.TabIndex = 307;
            this.cmdLogOut.Text = "Log Out";
            this.cmdLogOut.UseVisualStyleBackColor = true;
            this.cmdLogOut.Click += new System.EventHandler(this.cmdLogOut_Click);
            // 
            // CUDS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1282, 724);
            this.Controls.Add(this.cmdLogOut);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmdChangeUser);
            this.Controls.Add(this.cmdNewUser);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.datDailyLog);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.cmdRemoveUser);
            this.Controls.Add(this.datUsers);
            this.Controls.Add(this.cmdSwitchUser);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.cmdEditUser);
            this.Controls.Add(this.picUserIcon);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtHeight);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.cmdEditIcon);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdClose);
            this.Controls.Add(this.cmdCreateUser);
            this.Font = new System.Drawing.Font("Lucida Grande", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CUDS";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "accountinfo";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.CUDS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picUserIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datDailyLog)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCreateUser;
        private System.Windows.Forms.Button cmdClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdEditIcon;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox picUserIcon;
        private System.Windows.Forms.Button cmdEditUser;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button cmdRemoveUser;
        private System.Windows.Forms.DataGridView datUsers;
        private System.Windows.Forms.Button cmdSwitchUser;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.DataGridView datDailyLog;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Button cmdNewUser;
        private System.Windows.Forms.Button cmdChangeUser;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button cmdLogOut;
    }
}