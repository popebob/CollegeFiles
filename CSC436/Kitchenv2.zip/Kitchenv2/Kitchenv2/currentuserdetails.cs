﻿/*
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using System.IO;
namespace Kitchenv2
{
    public partial class currentuserdetails : Form
    {
        private Form1 mainForm; //handle for first form

        DataSet ds = new DataSet(); //dataset from database
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeDataAdapter da = new SqlCeDataAdapter(); //for communicating with database
        SqlCeCommand command; //sql command
        string username; //used to store username from user input
        string userpass; //used to store password from user input
        public static string currentuser; //used to store current user
        int loginflag; //used to set current user to  user in db or default user
        bool hasicon; //does the user have an icon?
        OpenFileDialog ofd;

        public currentuserdetails(Form1 m)
        {
            InitializeComponent();
            mainForm = m;
            loginflag = 0;
            currentuser = "defaultuser";
            hasicon = false;
        }
        public currentuserdetails(Form1 m, string u)
        {
            InitializeComponent();
            mainForm = m;
            loginflag = 0;
            currentuser = u;
            hasicon = false;
        }
        void showusers()
        {
            con.Open();
            command = new SqlCeCommand("SELECT * FROM tblUser", con);
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
            label2.Text = currentuser;
        }
        void showusericon()
        {
            MemoryStream m = null;
            con.Open();
            //code to show image again
            byte[] photo;
            //command to get all users from the user table
            command = new SqlCeCommand("SELECT * FROM tblUser WHERE UserName = @UserName", con);
            SqlCeParameter param = null;
            param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@UserName"].Size = 100;
            command.Parameters[0].Value = currentuserdetails.currentuser;
            command.Prepare();
            SqlCeDataReader reader = null;
            reader = command.ExecuteReader();
            //if pass user found show message
            while (reader.Read())
            {

                photo = (byte[])reader[7];
                m = new MemoryStream(photo);
            }

            pictureBox1.Image = Image.FromStream(m);
            con.Close();

        }

        //user removes account
        void deleteuser()
        {
            //gets user name from inputbox
            //username = Microsoft.VisualBasic.Interaction.InputBox("Enter User Name To Delete", "text", "", 10, 20);
            //uses username to search database and delete
            //open the connection 
            con.Open();
            //set command to remove the row the user has selected by using the uusername
            command = con.CreateCommand();
            command.CommandText = "Delete FROM tblUser WHERE USERNAME = @USERNAME";
            //set Parameter
            SqlCeParameter param = null;
            param = new SqlCeParameter("@USERNAME", SqlDbType.NVarChar, 100);
            command.Parameters.Add(param);
            command.Parameters["@USERNAME"].Size = 100;
            command.Prepare();
            //set Parameter value
            command.Parameters[0].Value = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            command.ExecuteNonQuery();
            command = con.CreateCommand();
            //refill the datagrid and show it again
            command.CommandText = "SELECT * FROM tblUser";
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
            //confirm account removed
            MessageBox.Show("Account " + username + " removed.");
        }

        //change user account
        void switchuser()
        {
            if (ds.Tables[0].Rows.Count != 0)
            {
                currentuser = dataGridView1.CurrentRow.Cells[0].Value.ToString();

                MemoryStream m = null;
                con.Open();
                //code to show image again
                byte[] photo;
                //command to get all users from the user table
                command = new SqlCeCommand("SELECT * FROM tblUser WHERE UserName = @UserName", con);
                SqlCeParameter param = null;
                param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@UserName"].Size = 100;
                command.Parameters[0].Value = currentuser;
                command.Prepare();
                SqlCeDataReader reader = null;
                reader = command.ExecuteReader();
                //if pass user found show message
                while (reader.Read())
                {
                    if (reader[7] != DBNull.Value)
                    {
                        photo = (byte[])reader[7];
                        m = new MemoryStream(photo);
                        hasicon = true;
                    }
                }
                if (!hasicon)
                {
                    pictureBox1.Image = null;
                    Form1.usericon = null;
                    hasicon = false;

                }
                if (hasicon)
                {
                    pictureBox1.Image = Image.FromStream(m);
                    Form1.usericon = (Bitmap)pictureBox1.Image;
                    hasicon = false;

                }
                con.Close();

            }
            mainForm.showmain();
            mainForm.showicon();
        }

        private void cmdSwitchUser_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
                //change user account
                switchuser();
            showusers();
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            //display user accounts
            showusers();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
                //delete user
                deleteuser();
            //reshow user table
            showusers();
        }

        private void accounts_Load(object sender, EventArgs e)
        {
            con.Open();
            command = new SqlCeCommand("SELECT * FROM tblUser", con);
            da = new SqlCeDataAdapter(command);
            ds = new DataSet();
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns.Remove(dataGridView1.Columns[0]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[1]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[2]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[3]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[3]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[1]);
            con.Close();
            //currentuser = userlogon();
            //currentuser = "defaultuser";
            label2.Text = currentuser;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            accountinfo ai = new accountinfo(currentuser);
            ai.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //add user
            //adduser();
            accountinfo ai = new accountinfo();
            ai.ShowDialog();
            //show user table
            showusers();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}

*/