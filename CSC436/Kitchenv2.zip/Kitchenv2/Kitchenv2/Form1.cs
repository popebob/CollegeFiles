﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Timers;
using System.Data.SqlServerCe;
using System.IO;

namespace Kitchenv2
{
    public partial class Form1 : Form
    {
        DataSet ds = new DataSet(); //data set from SQL database
        DataSet dsuser = new DataSet(); //data set from SQL database used for user tracking
        DataSet dsupc = new DataSet(); //data set from SQL database used for upc
        DataSet dslog = new DataSet(); //data set from SQL database used for upc
        SqlCeConnection con = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeConnection con2 = new SqlCeConnection(@"Data Source=" + (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "\\Kitchen.sdf;");
        SqlCeDataAdapter da = new SqlCeDataAdapter(); //for communicating with database //used to communicate with SQL database
        SqlCeDataAdapter dauser = new SqlCeDataAdapter(); //for communicating with database //used to communicate with SQL database
        SqlCeDataAdapter daupc = new SqlCeDataAdapter(); //for communicating with database //used to communicate with SQL database
        SqlCeDataAdapter dalog = new SqlCeDataAdapter(); //for communicating with database //used to communicate with SQL database
        SqlCeCommand command; //sql command
        int counter; //used to keep track or location in food linked list
        int whattoshow; //from the combo box to show on the main screen
        string[] labeldisplays; //array stores food names        
        public static string sKey; //string keyboard input
        public static int cartc; //count of total foods in cart
        Bitmap MyImage; //image object used for food pics
        Bitmap foodicon; //used to save food icons
        public static Bitmap usericon; //image object used for food pics
        string path; //path for image files
        string temppath; //path for image files for each image
        DualLinkedList dl; //link list for in stock foods
        DualLinkedList dl2; //link list for out of stock foods 
        DualLinkedList dl3; //link list for log check 
        Label[] l = new Label[6]; //label array
        NumericUpDown[] n = new NumericUpDown[6]; //updown array to set max values
        PictureBox[] p = new PictureBox[6]; //picturebox array
        PictureBox[] pr = new PictureBox[6]; //picturebox array for recent items
        Button[] b = new Button[6]; //button array for recent items
        public static bool wasScanned; //if the item was scanned
        public static fooditem[] foods; //array of in stockfood items
        public static fooditem[] foods2; //array of low/out stock food items
        public static fooditem[] foods3; //array used to check log
        public static mealitem[] meal; //array of meal items
        public static Form1.mealitem[] tempmeal; //temp meal
        public static int cartremoveindex; //index of the array to be removed from cart
        public static int mealcalories; //number of calories in the entire meal
        public static bool changesmade; //if another form makes changes that should be reflected in main
        Form1 m; //used to get a handle on main form for updating
        TextWriter tw;
        string currentdate;
        string lastdateused;
        recipefooditem[] rfi; //recipe food item passed to recipe browser
        //shopping cart items
        Form1.mealitem[] shoppingcart;
        Form1.mealitem[] tempcart;
        int shoppingcartcount;
        public int function; //in stock or depleated if < 1 depleated if > 1 instock
        int logcount; //how many log entries are there?
        string show; //for overloaded show main
//for calls outside the main form use mainForm.showmain(mainForm.show); 

        //food item
        public struct fooditem
        {
            public string name; //stores food item name
            public string type; //stores food item type
            public int quantity; //number of the food item in the food database
            public int calories; //number of calories 
            public Bitmap icon; //icon from food item
            public bool hasicon; //does this food item have an icon?
        };

        //meal / cart item
        public struct mealitem
        {
            public string name; //stores food item name
            public int quantity; //number of the food item in the meal
            public int calories; //number of calories in the current meal food
            public string type; //stores food item type
        };

        public struct recipefooditem
        {
            public string name; //stores food item name
            public int quantity; //number of this item needed to make recipe
            public bool infdb; //is enough of this item in the food db to make recipe
            public int calories; //number of calories in the current meal food
        };

        public struct reciperating
        {
            public string name; //stores food item name
            public int rating; //number of this item needed to make recipe
            public int instock; //instock status of this recipe
        };

        //Constructor
        public Form1()
        {
            InitializeComponent();
            counter = 0;
            labeldisplays = new string[100];
            foods = new fooditem[100];
            meal = new mealitem[100];
            cartc = -1;
            //path for pitcures (needs to be changed on different PCs)
            path = @"C:\Users\winb83\Documents\Visual Studio 2010\Projects\Kitchenv2\Kitchenv2\";
            //path = @"C:\Users\student\Desktop\Kitchenv2\Kitchenv2\Kitchenv2\Kitchenv2\Kitchenv2\";
            //if the item was scanned set to false 
            wasScanned = false;
            //array of labels for easier access to labelnames            
            l[0] = lblNode1;
            l[1] = lblNode2;
            l[2] = lblNode3;
            l[3] = lblNode4;
            l[4] = lblNode5;
            l[5] = lblNode6;
            //set updown array values
            n[0] = numericUpDown1;
            n[1] = numericUpDown2;
            n[2] = numericUpDown3;
            n[3] = numericUpDown4;
            n[4] = numericUpDown5;
            n[5] = numericUpDown6;
            //set picturebox array
            p[0] = pictureBox100;
            p[1] = pictureBox200;
            p[2] = pictureBox300;
            p[3] = pictureBox400;
            p[4] = pictureBox500;
            p[5] = pictureBox600;
            //set picturebox array
            pr[0] = pictureBox1;
            pr[1] = pictureBox2;
            pr[2] = pictureBox3;
            pr[3] = pictureBox4;
            pr[4] = pictureBox5;
            pr[5] = pictureBox7;
            //set picturebox array
            b[0] = button1;
            b[1] = button2;
            b[2] = button3;
            b[3] = button4;
            b[4] = button5;
            b[5] = button37;
            //for form handle to refresh
            m = this;
            //default user set to default upon load
            CUDS.currentuser = "defaultuser";
            //checkDate();
            //set current date to the system's current date
            currentdate = DateTime.Now.ToString("M/d/yyyy");
            function = 1;
            shoppingcartcount = -1;
            shoppingcart = new Form1.mealitem[100];
            show = "SELECT * FROM tblFood quantity > 0"; 
            //dataGridView1.ColumnHeadersBorderStyle = ProperColumnHeadersBorderStyle;

        }
        static DataGridViewHeaderBorderStyle ProperColumnHeadersBorderStyle
        {
            get
            {
                return (SystemFonts.MessageBoxFont.Name == "Segoe UI") ?
                    DataGridViewHeaderBorderStyle.None:
                    DataGridViewHeaderBorderStyle.Raised;
            }
        }



        //add food item to shopping cart
        /*old way
        public void addtocart(Label l, NumericUpDown n)
        {
            //inc shopping cart count
            shoppingcartcount++;
            //set cart item name
            shoppingcart[shoppingcartcount].name = l.Text;
            //set cart item count
            shoppingcart[shoppingcartcount].quantity = (int)n.Maximum;
            //show cart with new item
            viewCart();
        }
        */

        //add food item to shopping cart
        public void addtocart(Label l, NumericUpDown n)
        {
            bool wasincart = false;
            for (int i = 0; i <= shoppingcartcount; i++)
            {
                if (shoppingcart[i].name == l.Text)
                    wasincart = true;
            }
            if (!wasincart)
            {
                //inc shopping cart count
                shoppingcartcount++;
                //set cart item name
                shoppingcart[shoppingcartcount].name = l.Text;
                //set cart item count
                shoppingcart[shoppingcartcount].quantity = (int)n.Maximum;
            }
            //show cart with new item
            viewCart();
        } 

        //view shopping cart
        public void viewCart()
        {
            //clear listbox
            lstCart.Items.Clear();
            //go through food item array and add items to listbox
            for (int i = 0; i <= shoppingcartcount; i++)
            {
                lstCart.Items.Add(shoppingcart[i].name + " " + shoppingcart[i].quantity + " servings in stock.");
            }

        }
        //remove an item from the cart. uses temp arrays to skip item removed and reset array
        public void deleteCart()
        {
            tempcart = shoppingcart; //temp cart array set to real cart            
            string removeditem; //used to store item to be removed
            int cartremoveindex = 0; //used to store item to be removed
            removeditem = lstCart.SelectedItem.ToString();
            //finds the index of the item to be removed in the array and saves it
            for (int i = 0; i <= shoppingcartcount; i++)
            {
                if (tempcart[i].name == removeditem)
                    cartremoveindex = i;

            }
            //rebuilds the array without the removed item. if removed item is found it is skipped in the rebuilding
            for (int i = 0; i <= shoppingcartcount; i++)
            {
                //as long as current item isn't item to be removed add it to the cart
                if (i != cartremoveindex)
                {
                    shoppingcart[i] = tempcart[i];
                    //Form1.cartq[i] = Form1.tempcartq[i];
                }
                //if current item is to be removed skip it
                if (i == cartremoveindex)
                    i++;
            }
            //dec the cart count since it is one item smaller now
            shoppingcartcount--;
            //clear then reset the listbox
            lstCart.Items.Clear();
            viewCart();
        }
        //remove food items from db and reset meal
        public void checkOutCart()
        {
            //write file results to text file
            //tw = new StreamWriter((System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)) + "caltrack.txt");
            try
            {
                //tw = new StreamWriter();
                tw = File.AppendText("cart.txt");
            }
            catch (Exception e)
            {
                tw = new StreamWriter("cart.txt");
            }
            tw.WriteLine("");
            tw.WriteLine(DateTime.Now.ToString("M/d/yyyy"));
            for (int i = 0; i <= shoppingcartcount; i++)
                tw.WriteLine(shoppingcart[i].name + " " + shoppingcart[i].quantity);


            //reset cart to nothing
            shoppingcart = new Form1.mealitem[100];
            //set cart count to be nothing
            shoppingcartcount = -1;
            viewCart();
            tw.Close();
        }

        /* old ver
        //add meal item
        public void addMeal(Label ll, NumericUpDown mm)
        {
            //temp to hold food item name
            string t = ll.Text;
            bool isinmeal = false;
            for (int i = 0; i <= cartc; i++)
            {
                if (t == meal[i].name)
                {                    
                    meal[i].quantity += Convert.ToInt32(mm.Value);
                    isinmeal = true;
                    for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                    {
                        if (meal[i].name == foods[j].name)
                        {
                            //meal[cartc].quantity = foods[i].quantity;
                            meal[i].calories = foods[j].calories;
                            meal[i].type = foods[j].type; //stores food item type
                            if (meal[i].quantity > foods[j].quantity)
                                meal[i].quantity = foods[j].quantity;
                        }
                    }
                }
            }
            if (isinmeal == false)
            {
                //inc cart
                cartc++;
                //set food in cart to label name
                meal[cartc].name = ll.Text;
                //set food in cart to user's count
                meal[cartc].quantity = Convert.ToInt32(mm.Value);
                //MessageBox.Show(meal[cartc].name + " cartc " + cartc.ToString());
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (meal[cartc].name == foods[i].name)
                    {
                        //meal[cartc].quantity = foods[i].quantity;
                        meal[cartc].calories = foods[i].calories;
                    }
                }
            }
            viewMeal();
        }
        

        //add meal item
        public void addMeal(Button ll, int u)
        {
            //temp to hold food item name
            string t = ll.Text;
            bool isinmeal = false;
            for (int i = 0; i <= cartc; i++)
            {
                if (t == meal[i].name)
                {
                    meal[i].quantity += u;
                    isinmeal = true;
                    for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                    {
                        if (meal[i].name == foods[j].name)
                        {
                            //meal[cartc].quantity = foods[i].quantity;
                            meal[i].calories = foods[j].calories;
                            meal[i].type = foods[i].type; //stores food item type
                            if (meal[i].quantity > foods[j].quantity)
                                meal[i].quantity = foods[j].quantity;
                        }
                    }
                }
            }
            if (isinmeal == false)
            {
                //inc cart
                cartc++;
                //set food in cart to label name
                meal[cartc].name = ll.Text;
                //set food in cart to user's count
                meal[cartc].quantity = u;
                //MessageBox.Show(meal[cartc].name + " cartc " + cartc.ToString());
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (meal[cartc].name == foods[i].name)
                    {
                        //meal[cartc].quantity = foods[i].quantity;
                        meal[cartc].calories = foods[i].calories;
                    }
                }
            }
            viewMeal();
        }
        */

        //new

        //add meal item
        public void addMeal(Label ll, NumericUpDown mm)
        {
            //temp to hold food item name
            string t = ll.Text;
            bool isinmeal = false;
            for (int i = 0; i <= cartc; i++)
            {
                if (t == meal[i].name)
                {
                    meal[i].quantity += Convert.ToInt32(mm.Value);
                    isinmeal = true;
                    for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                    {
                        if (meal[i].name == foods[j].name)
                        {
                            //meal[cartc].quantity = foods[i].quantity;
                            meal[i].calories = foods[j].calories;
                            meal[i].type = foods[j].type; //stores food item type
                            if (meal[i].quantity > foods[j].quantity)
                            {
                                meal[i].quantity = foods[j].quantity;
                                MessageBox.Show("Max reached");
                            }
                        }
                    }
                }
            }
            if (isinmeal == false)
            {
                //inc cart
                cartc++;
                //set food in cart to label name
                meal[cartc].name = ll.Text;
                //set food in cart to user's count
                meal[cartc].quantity = Convert.ToInt32(mm.Value);
                //MessageBox.Show(meal[cartc].name + " cartc " + cartc.ToString());
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (meal[cartc].name == foods[i].name)
                    {
                        //meal[cartc].quantity = foods[i].quantity;
                        meal[cartc].calories = foods[i].calories;
                    }
                }
            }
            viewMeal();
        }

        //add meal item
        public void addMeal(Button ll, int u)
        {
            //temp to hold food item name
            string t = ll.Text;
            bool isinmeal = false;
            for (int i = 0; i <= cartc; i++)
            {
                if (t == meal[i].name)
                {
                    meal[i].quantity += u;
                    isinmeal = true;
                    for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                    {
                        if (meal[i].name == foods[j].name)
                        {
                            //meal[cartc].quantity = foods[i].quantity;
                            meal[i].calories = foods[j].calories;
                            meal[i].type = foods[i].type; //stores food item type
                            if (meal[i].quantity > foods[j].quantity)
                            {
                                meal[i].quantity = foods[j].quantity;
                                MessageBox.Show("Max reached");
                            }
                        }
                    }
                }
            }
            if (isinmeal == false)
            {
                //inc cart
                cartc++;
                //set food in cart to label name
                meal[cartc].name = ll.Text;
                //set food in cart to user's count
                meal[cartc].quantity = u;
                //MessageBox.Show(meal[cartc].name + " cartc " + cartc.ToString());
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (meal[cartc].name == foods[i].name)
                    {
                        //meal[cartc].quantity = foods[i].quantity;
                        meal[cartc].calories = foods[i].calories;
                    }
                }
            }
            viewMeal();
        } 
        //end new

        public void addMeal(recipefooditem [] r)
        {
            cartc = r.GetLength(0);
            //meal = new mealitem [100];
            //MessageBox.Show(" cartc " + cartc.ToString());
            if (cartc > 0)
                cartc--;
            for (int i = 0; i <= cartc; i++)
            {
                //MessageBox.Show(" i " + i.ToString());
                //MessageBox.Show(r[i].name);
                meal[i].name = r[i].name;
                meal[i].quantity = r[i].quantity;
                meal[i].calories = r[i].calories;
            }
            viewMeal();


        }

        //display the meal
        public void viewMeal()
        {
            //clear listbox
            lstCart.Items.Clear();
            //go through food item array and add items to listbox
            for (int i = 0; i <= cartc; i++)
            {
                lstCart.Items.Add(meal[i].name + " " + meal[i].quantity + " servings " + meal[i].calories + " calorie(s) per serving");
            }

        }

        //remove an item from the cart. uses temp arrays to skip item removed and reset array
        public void deleteMeal()
        {
            tempmeal = meal; //temp cart array set to real cart            
            string removeditem; //used to store item to be removed
            removeditem = lstCart.SelectedItem.ToString();
            //finds the index of the item to be removed in the array and saves it
            for (int i = 0; i <= cartc; i++)
            {
                if (tempmeal[i].name == removeditem)
                    cartremoveindex = i;

            }
            //rebuilds the array without the removed item. if removed item is found it is skipped in the rebuilding
            for (int i = 0; i <= cartc; i++)
            {
                //as long as current item isn't item to be removed add it to the cart
                if (i != cartremoveindex)
                {
                    meal[i] = tempmeal[i];
                    //Form1.cartq[i] = Form1.tempcartq[i];
                }
                //if current item is to be removed skip it
                if (i == cartremoveindex)
                    i++;
            }
            //dec the cart count since it is one item smaller now
            cartc--;
            //clear then reset the listbox
            lstCart.Items.Clear();
            viewMeal();
        }
        //remove food items from db and reset meal
        public void checkOut()
        {
            //write file results to text file
            try
            {
                //tw = new StreamWriter();
                tw = File.AppendText("caltrack.txt");
            }
            catch (Exception e)
            {
                tw = new StreamWriter("caltrack.txt");
            }
            

            //go through cart and update the counts
            int q;
            int tmk = 0;
            int rightindex = 0; //used to search for the index the correct food item is related to
            tw.WriteLine("");
            tw.WriteLine(DateTime.Now.ToString("M/d/yyyy")); 
            for (int i = 0; i <= cartc; i++)
            {
                
                //find the proper food index for the food item array and save it
                //double nested for loop used to search entire food array for right index
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                   
                        if (foods[k].name == meal[i].name)
                        {
                            rightindex = k;
                            //MessageBox.Show("right index found at " + rightindex);
                        }
                    
                }
                q = foods[rightindex].quantity - meal[i].quantity;
                //MessageBox.Show(meal[i].name + " " + q.ToString());
                mealcalories += meal[i].calories * meal[i].quantity;
                tmk += meal[i].calories * meal[i].quantity;
                if (q < 0)
                {
                    //MessageBox.Show("1");
                    while (q < 0)
                    {
                        //MessageBox.Show("2");
                        MessageBox.Show("Quantity for food " + meal[i].name + " will be less than zero.");
                        string temp = "Enter new quantity for meal item " + meal[i].name + " equal to or less than " + foods[rightindex].quantity.ToString();
                        string q2 = Microsoft.VisualBasic.Interaction.InputBox(temp, "text", "", 10, 20);
                        if (q2 != "")
                        {
                            meal[i].quantity = Convert.ToInt32(q2);
                            //something needed here to correct calories count
                            q = foods[rightindex].quantity - meal[i].quantity;
                        }
                    }

                }
                con.Open();
                command = con.CreateCommand();
                command.CommandText = "UPDATE tblFood SET quantity = @quantity WHERE Foodname = @Foodname";
                SqlCeParameter param = null;
                param = new SqlCeParameter("@quantity", SqlDbType.Int);
                command.Parameters.Add(param);
                param = new SqlCeParameter("@FOODNAME", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@FOODNAME"].Size = 100;
                command.Prepare();
                command.Parameters[0].Value = q;
                command.Parameters[1].Value = meal[i].name;
                //MessageBox.Show(meal[i].name + " " + q.ToString());
               
                tw.WriteLine(meal[i].name + " " + meal[i].quantity);
                
                command.ExecuteNonQuery();
                //check to see if current user isn't default
                if (CUDS.currentuser != "defaultuser")
                {
                    command = con.CreateCommand();
                    command.CommandText = "UPDATE tblUser SET dailycalcount = @dailycalcount WHERE UserName = @UserName";
                    param = null;
                    param = new SqlCeParameter("@dailycalcount", SqlDbType.Int);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    command.Parameters["@UserName"].Size = 100;
                    command.Parameters[0].Value = mealcalories;
                    command.Parameters[1].Value = CUDS.currentuser;
                    command.Prepare();
                    //execute the command and update the daily calories
                    command.ExecuteNonQuery();
                    //check food type, seems to have an error
                    command = con.CreateCommand();
                    command.CommandText = "INSERT INTO tblLog (foodname, userID, date, calories, servings) VALUES (@FOODNAME, @userID, @date, @calories, @servings)";
                    //servingsize, servingsper, fat, sodium, sugars, carbs, protein, Depletedcount
                    param = null;

                    param = new SqlCeParameter("@FOODNAME", SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    //param = new SqlCeParameter("@FOODYTPE", SqlDbType.NVarChar, 100);
                    //command.Parameters.Add(param);
                    param = new SqlCeParameter("@userID", SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@date", SqlDbType.NVarChar, 100);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@calories", SqlDbType.Int);
                    command.Parameters.Add(param);
                    param = new SqlCeParameter("@servings", SqlDbType.Int);
                    command.Parameters.Add(param);

                    command.Parameters["@FOODNAME"].Size = 100;
                    //command.Parameters["@FOODYTPE"].Size = 100;
                    command.Parameters["@userID"].Size = 100;
                    command.Parameters["@date"].Size = 100;
                    command.Prepare();
                    //MessageBox.Show(meal[i].type);
                    command.Parameters[0].Value = meal[i].name;
                    //command.Parameters[1].Value = meal[i].type;
                    command.Parameters[1].Value = CUDS.currentuser;
                    command.Parameters[2].Value = currentdate;
                    command.Parameters[3].Value = meal[i].calories;
                    command.Parameters[4].Value = meal[i].quantity;
                    command.ExecuteNonQuery();
                }
                con.Close();
                
            }
            //reset cart to nothing
            meal = new mealitem[100];
            //set cart count to be nothing
            cartc = -1;
            MessageBox.Show(tmk.ToString() + " Total Calories for meal that was checked out, " + mealcalories + " total for the day");
            viewMeal();
            tw.WriteLine("Total calories for current meal for user " + cmdCurrentUser.Text + " " + tmk.ToString());
            tw.WriteLine("Total calories for user " + cmdCurrentUser.Text + " " + mealcalories.ToString());
            tw.Close();
            mealcalories = 0;
        }

        //lets user change the number of items in the cart
        public void editMeal()
        {
            //gets input from input box
            string newq = Microsoft.VisualBasic.Interaction.InputBox("Enter new quantity", "text", "", 10, 20);
            //sets item to be changed to current selection
            string changeitem = lstCart.SelectedItem.ToString();
            bool test1; //used to find item to be changed
            //goes through array and finds item to be changed
            for (int i = 0; i <= Form1.cartc; i++)
            {
                test1 = changeitem.StartsWith(Form1.meal[i].name);
                if (test1)
                    //if found changes item
                    Form1.meal[i].quantity = Convert.ToInt32(newq);

            }
            //display updated meal
            viewMeal();
        }

        public void editMealUpDown(int l)
        {
            //sets item to be changed to current selection
            string changeitem = lstCart.SelectedItem.ToString();
            int ci = lstCart.SelectedIndex;
            bool test1; //used to find item to be changed
            //goes through array and finds item to be changed
            for (int i = 0; i <= Form1.cartc; i++)
            {
                test1 = changeitem.StartsWith(Form1.meal[i].name);
                if (test1)
                    //if found changes item
                    if (l == 1) //increase QTY
                        Form1.meal[i].quantity++;
                    else
                    {
                        if (Form1.meal[i].quantity == 1)
                        {
                            deleteMeal();
                            viewMeal();
                            return;
                        }
                        else
                            Form1.meal[i].quantity--;
                    }


            }
            //display updated meal
            viewMeal();
            lstCart.SelectedIndex = ci;
        }

        //rate recipes on cart items
        void rateRecipes1()
        {
            //MessageBox.Show(" cartc " + cartc.ToString());
            rfi = new recipefooditem[cartc+1];
            //MessageBox.Show(rfi.Length.ToString());
            //dump cart to recipe items
            for (int i = 0; i <= cartc; i++)
            {
                rfi[i].name = meal[i].name;
                //MessageBox.Show(rfi[i].name + " cartc " + cartc.ToString() + " i " + i.ToString());
                rfi[i].calories = meal[i].calories;
                for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                {
                    if (foods[j].name == rfi[i].name)
                        rfi[i].quantity = foods[j].quantity;
                }

            }
            recipebrowser rb = new recipebrowser(rfi, m, cartc, foods);
            rb.ShowDialog();
        }

        //show foods on main screen
        public void showmain()
        {
            con.Open();
            //bug where food array is only reset when sort change is made needs to be fixed.
            Refresh();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //command = new SqlCeCommand("SELECT * FROM tblFood", con);
            //"SELECT * FROM tblFood where quantity <= Depletedcount"
            //command = new SqlCeCommand("SELECT * FROM tblFood where quantity < Depletedcount", con);
            command = new SqlCeCommand("SELECT * FROM tblFood where quantity > 0", con);
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns.Remove(dataGridView1.Columns[0]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[1]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[2]);
            dataGridView1.Columns.Remove(dataGridView1.Columns[2]);
            
             //dataGridView1.Columns.Remove(dataGridView1.Columns[3]);

            //close connection
            con.Close();
            //set current user       
            cmdCurrentUser.Text = CUDS.currentuser;
            //set min qty for numericupdowns
            numericUpDown1.Minimum = 1;
            numericUpDown2.Minimum = 1;
            numericUpDown3.Minimum = 1;
            numericUpDown4.Minimum = 1;
            numericUpDown5.Minimum = 1;
            numericUpDown6.Minimum = 1;
            //make a new linked list
            dl = new DualLinkedList();
            //make a new food item array
            foods = new fooditem[ds.Tables[0].Rows.Count];
            //populate the food item array by going through the dataset table and filling the item fields
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                foods[i].name = ds.Tables[0].Rows[i].ItemArray[1].ToString();
                foods[i].type = ds.Tables[0].Rows[i].ItemArray[2].ToString();
                foods[i].quantity = (int)ds.Tables[0].Rows[i].ItemArray[3];
                //if there is an icon for the food save it
                if (ds.Tables[0].Rows[i].ItemArray[5] != DBNull.Value)
                {
                    byte[] photo;
                    MemoryStream m = null;
                    photo = (byte[])ds.Tables[0].Rows[i].ItemArray[5];
                    m = new MemoryStream(photo);
                    foods[i].icon = (Bitmap)Image.FromStream(m);
                    foods[i].hasicon = true;
                }
                dl.insert(foods[i]);
                //open connection to sql db
                con2.Open();
                //dauser used for user db
                daupc = new SqlCeDataAdapter();
                //command to get all users from the user table
                command = new SqlCeCommand("SELECT * FROM tblUpc WHERE foodname = @foodname", con2);
                SqlCeParameter param = null;
                param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@foodname"].Size = 100;
                command.Parameters[0].Value = foods[i].name;
                command.Prepare();
                SqlCeDataReader reader = null;
                reader = command.ExecuteReader();
                //if pass user found show message
                while (reader.Read())
                {
                    
                    foods[i].calories = (int)reader[4];
                    //MessageBox.Show("found " + foods[i].name + " " + foods[i].calories.ToString());
                }
                //close connection
                con2.Close();
            }
            //show correct 6 nodes
            //MessageBox.Show("Food Db", "Attention");
            dl.display6nodes(counter, l, ds.Tables[0].Rows.Count, n, p);
            //
            //call check date to see if user chaged
            checkDate();
            showpreviousnext();
            //show correct 6 nodes
            if (checklog())
                dl3.display6nodes(counter, b, logcount, pr);
            else
                dl.display6nodes(counter, b, ds.Tables[0].Rows.Count, pr);
        }
        //show foods on main screen
        public void showmain( string s)
        {
            con.Open();
            //bug where food array is only reset when sort change is made needs to be fixed.
            Refresh();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //command = new SqlCeCommand("SELECT * FROM tblFood", con);
            command = new SqlCeCommand(s, con);
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();

            cmdCurrentUser.Text = CUDS.currentuser;
            numericUpDown1.Minimum = 1;
            numericUpDown2.Minimum = 1;
            numericUpDown3.Minimum = 1;
            numericUpDown4.Minimum = 1;
            numericUpDown5.Minimum = 1;
            numericUpDown6.Minimum = 1;
            //check the sort and if it was sorted the opposite way reset the flag
            dl2 = new DualLinkedList();
            foods2 = new fooditem[ds.Tables[0].Rows.Count];
            numericUpDown1.Minimum = 1;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                
                foods2[i].name = ds.Tables[0].Rows[i].ItemArray[1].ToString();
                //MessageBox.Show(foods2[i].name);
                foods2[i].type = ds.Tables[0].Rows[i].ItemArray[2].ToString();
                foods2[i].quantity = (int)ds.Tables[0].Rows[i].ItemArray[3];
                if (ds.Tables[0].Rows[i].ItemArray[5] != DBNull.Value)
                {
                    byte[] photo;
                    MemoryStream m = null;
                    photo = (byte[])ds.Tables[0].Rows[i].ItemArray[5];
                    m = new MemoryStream(photo);
                    foods2[i].icon = (Bitmap)Image.FromStream(m);
                    foods2[i].hasicon = true;
                }
                dl2.insert(foods2[i]);
                //open connection to sql db
                con2.Open();
                //dauser used for user db
                daupc = new SqlCeDataAdapter();
                //command to get all users from the user table
                command = new SqlCeCommand("SELECT * FROM tblUpc WHERE foodname = @foodname", con2);
                SqlCeParameter param = null;
                param = new SqlCeParameter("@foodname", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@foodname"].Size = 100;
                command.Parameters[0].Value = foods2[i].name;
                command.Prepare();
                SqlCeDataReader reader = null;
                reader = command.ExecuteReader();
                //if pass user found show message
                while (reader.Read())
                {

                    foods2[i].calories = (int)reader[4];
                    //MessageBox.Show("found " + foods[i].name + " " + foods[i].calories.ToString());
                }
                //close connection
                con2.Close();
            }
            //show correct 6 nodes
            //MessageBox.Show("Food Db", "Attention");
            dl2.display6nodes(counter, l, ds.Tables[0].Rows.Count, n, p);
            //
            //call check date to see if user chaged
            checkDate();
            showpreviousnext();
            //show correct 6 nodes
            if (checklog())
                dl3.display6nodes(counter, b, logcount, pr);
            else
                dl.display6nodes(counter, b, ds.Tables[0].Rows.Count, pr);
        }

        //show foods on main screen for sort by calories
        public void showmain(string s, string s2)
        {
            con.Open();
            //bug where food array is only reset when sort change is made needs to be fixed.
            Refresh();
            ds = new DataSet();
            da = new SqlCeDataAdapter();
            //command = new SqlCeCommand("SELECT * FROM tblFood", con);
            command = new SqlCeCommand(s, con);
            //refill the datagrid and show it again
            da = new SqlCeDataAdapter(command);
            ds.Clear();
            da.Fill(ds);
            con.Close();

            cmdCurrentUser.Text = CUDS.currentuser;
            numericUpDown1.Minimum = 1;
            numericUpDown2.Minimum = 1;
            numericUpDown3.Minimum = 1;
            numericUpDown4.Minimum = 1;
            numericUpDown5.Minimum = 1;
            numericUpDown6.Minimum = 1;
            //check the sort and if it was sorted the opposite way reset the flag
            dl2 = new DualLinkedList();
            foods2 = new fooditem[ds.Tables[0].Rows.Count];
            numericUpDown1.Minimum = 1;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {

                foods2[i].name = ds.Tables[0].Rows[i].ItemArray[1].ToString();
                //MessageBox.Show(foods2[i].name);
                foods2[i].type = ds.Tables[0].Rows[i].ItemArray[2].ToString();
                foods2[i].quantity = (int)ds.Tables[0].Rows[i].ItemArray[3];
                if (ds.Tables[0].Rows[i].ItemArray[5] != DBNull.Value)
                {
                    byte[] photo;
                    MemoryStream m = null;
                    photo = (byte[])ds.Tables[0].Rows[i].ItemArray[5];
                    m = new MemoryStream(photo);
                    foods2[i].icon = (Bitmap)Image.FromStream(m);
                    foods2[i].hasicon = true;
                }
                foods2[i].calories = (int)ds.Tables[0].Rows[i].ItemArray[10];
                dl2.insert(foods2[i]);
            }
            //show correct 6 nodes
            //MessageBox.Show("Food Db", "Attention");
            dl2.display6nodes(counter, l, ds.Tables[0].Rows.Count, n, p);
            //
            //call check date to see if user chaged
            checkDate();
            showpreviousnext();
            //show correct 6 nodes
            if (checklog())
                dl3.display6nodes(counter, b, logcount, pr);
            else
                dl.display6nodes(counter, b, ds.Tables[0].Rows.Count, pr);
        } 

        //check to see if there are enough recent items for main form recent items list
        bool checklog()
        {
            int insertcount = 0; //how many links were put in d3
            foods3 = new fooditem[1000];
            dl3 = new DualLinkedList();
            //open connection
            con.Open();
            //refresh ds
            dslog = new DataSet();
            //refresh da
            dalog = new SqlCeDataAdapter();
            //get everything in the log table
            command = new SqlCeCommand("SELECT * FROM tblLog", con);
            //set command to dalog
            dalog = new SqlCeDataAdapter(command);
            dslog.Clear();
            //fill the dataset from the log table
            dalog.Fill(dslog);
            //save the number of entries
            logcount = dslog.Tables[0].Rows.Count;
            if (logcount > 6)
            {
                //get log food name from log table
                for (int i = 0; i < dslog.Tables[0].Rows.Count; i++)
                {
                    foods3[i].name = dslog.Tables[0].Rows[i].ItemArray[3].ToString();
                    //foods3[i].type = dslog.Tables[0].Rows[i].ItemArray[4].ToString();
                }
                //refresh ds
                dslog = new DataSet();
                //refresh da
                dalog = new SqlCeDataAdapter();
                //get everything in the food table
                command = new SqlCeCommand("SELECT * FROM tblFood", con);
                //refill the datagrid and show it again
                dalog = new SqlCeDataAdapter(command);
                dslog.Clear();
                dalog.Fill(dslog);
                for (int j = 0; j < logcount; j++)
                {
                    //MessageBox.Show("Checking for " + foods3[j].name);
                    for (int i = 0; i < dslog.Tables[0].Rows.Count; i++)
                    {
                        //MessageBox.Show("looking at " + dslog.Tables[0].Rows[i].ItemArray[1].ToString());
                        if (foods3[j].name == dslog.Tables[0].Rows[i].ItemArray[1].ToString())
                        {
                            //MessageBox.Show("Info found for " + foods3[j].name);
                            foods3[j].type = dslog.Tables[0].Rows[i].ItemArray[2].ToString();
                            foods3[j].quantity = (int)dslog.Tables[0].Rows[i].ItemArray[3];
                            if (dslog.Tables[0].Rows[i].ItemArray[5] != DBNull.Value)
                            {
                                //MessageBox.Show("Picture found for " + foods3[j].name);
                                byte[] photo;
                                MemoryStream m = null;
                                photo = (byte[])dslog.Tables[0].Rows[i].ItemArray[5];
                                m = new MemoryStream(photo);
                                foods3[j].icon = (Bitmap)Image.FromStream(m);
                                foods3[j].hasicon = true;
                            }

                        }

                    }
                    if (foods3[j].quantity >= 1)
                    {
                        dl3.insert(foods3[j]);
                        insertcount++;

                    }
                }
            }
                con.Close();
            //if there are enough log entires to fill the recent items return true else return false
                if (insertcount > 6)
                    return true;
                else
                    return false;
        }

        
        void checkDate()
        {
          
            //open connection to sql db
            con.Open();
            //dauser used for user db
            dauser = new SqlCeDataAdapter();
            //command to get all users from the user table
            command = new SqlCeCommand("SELECT * FROM tblUser", con);
            //set the dauser to the previous command
            dauser = new SqlCeDataAdapter(command);
            //clear the ds before filling it
            dsuser.Clear();
            //fill the ds with the data from the table user
            dauser.Fill(dsuser);            
            //close connection
            

            //check to see if current user isn't default
            if (CUDS.currentuser != "defaultuser")
            {
                //set command to update the row the user has selected by using the unique item ID
                command = new SqlCeCommand("SELECT * FROM tblUser WHERE UserName = @UserName", con);
                SqlCeDataReader reader = null;
                SqlCeParameter param = null;
                param = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
                command.Parameters.Add(param);
                command.Parameters["@UserName"].Size = 100;
                command.Parameters[0].Value = CUDS.currentuser;
                command.Prepare();
                //execute the search and save results in reader
                reader = command.ExecuteReader();
                //if pass user found show message
                while (reader.Read())
                {
                    //string s = reader["dailycalcount"].ToString();
                    string s = reader[5].ToString();
                    lastdateused = reader[6].ToString();
                    //MessageBox.Show("Last Date Used = " + reader[6].ToString() + " Current Date = " + currentdate);
                    if (currentdate == reader[6].ToString())
                    {
                        //MessageBox.Show("The dates are the same");
                        //MessageBox.Show(s);
                        mealcalories = Convert.ToInt32(s);
                    }
                    if (currentdate != reader[6].ToString())
                    {
                        //MessageBox.Show("The dates are different");
                        mealcalories = 0;
                        SqlCeCommand command2 = con.CreateCommand();
                        command2.CommandText = "UPDATE tblUser SET lastdateused = @lastdateused, dailycalcount = @dailycalcount WHERE UserName = @UserName";
                        SqlCeParameter param2 = null;
                        param2 = new SqlCeParameter("@lastdateused", SqlDbType.NVarChar, 100);
                        command2.Parameters.Add(param2);
                        param2 = new SqlCeParameter("@dailycalcount", SqlDbType.Int);
                        command2.Parameters.Add(param2);
                        param2 = new SqlCeParameter("@UserName", SqlDbType.NVarChar, 100);
                        command2.Parameters.Add(param2);
                        command2.Parameters["@lastdateused"].Size = 100;
                        command2.Parameters["@UserName"].Size = 100;
                        command2.Parameters[0].Value = currentdate;
                        command2.Parameters[1].Value = 0;
                        command2.Parameters[2].Value = CUDS.currentuser;
                        command2.Prepare();
                        //execute the command and update the daily calories
                        command2.ExecuteNonQuery();                        
                    }
                }
            }
            con.Close();
            
        }

        //previous button pushed
        void previous()
        {
            if (counter > 0)
                //dec the counter
                counter--;
            //hide button next if needed
            if (counter <= 0)
            {
                button12.Visible = false;
                button13.Visible = true;
            }
            //show button next if needed
            if (counter < ds.Tables[0].Rows.Count - 6)
            {                
                button13.Visible = true;
            }
            //MessageBox.Show(counter.ToString());
            //show the correct 6 nodes
            dl.display6nodes(counter, l, ds.Tables[0].Rows.Count, n, p);


        }

        //next button pushed
        void next()
        {
            if (counter < ds.Tables[0].Rows.Count)
                //inc the counter
                counter++;
            //show button previous if needed
            if (counter > 0)
            {
                button12.Visible = true;
            }
            //hide button next if needed.
            if (counter >= ds.Tables[0].Rows.Count - 6)
            {
                 button13.Visible = false;
            }
            //MessageBox.Show(ds.Tables[0].Rows.Count.ToString());
            //MessageBox.Show(counter.ToString());
            //show the correct 6 nodes
            if (function == 1)
                dl.display6nodes(counter, l, ds.Tables[0].Rows.Count - 5, n, p);
            if (function == 0)
                dl2.display6nodes(counter, l, ds.Tables[0].Rows.Count - 5, n, p); 
        }

        //check to mask sure buttons are shown if both aren't
        void showpreviousnext()
        {
            if (ds.Tables[0].Rows.Count > 6)
            {

                button13.Visible = true;
            }
            if (counter > 0)
            {
                button12.Visible = true;
            }

        }
        //used if user icon is changed to show icon from another form
        public void showicon()
        {
            picUserIcon.Image = usericon;
        }



        //setup the food linked list
        private void button14_Click(object sender, EventArgs e)
        {
            showmain();
        }


        //previous button
        private void button12_Click(object sender, EventArgs e)
        {
            previous();
        }

        //next button
        private void button13_Click(object sender, EventArgs e)
        {
            next();
        }


        //add to meal or cart based on the function of the main form
        //checks to see if there is food in the food db which if there isn't 
        //the labels would be set to - and it would do nothing
        //if function is set to 1 add to meal if its 2 then add to cart
        private void button6_Click(object sender, EventArgs e)
        {
            if (lblNode1.Text != "-" && function == 1)
            {
                addMeal(lblNode1, numericUpDown1);
            }
            if (lblNode1.Text != "-" && function == 0)
            {
                addtocart(lblNode1, numericUpDown1);
            }
        }


        //add to meal or cart based on the function of the main form
        //checks to see if there is food in the food db which if there isn't 
        //the labels would be set to - and it would do nothing
        //if function is set to 1 add to meal if its 2 then add to cart
        private void button7_Click(object sender, EventArgs e)
        {
            if (lblNode2.Text != "-" && function == 1)
            {
                addMeal(lblNode2, numericUpDown2);
            }
            if (lblNode2.Text != "-" && function == 0)
            {
                addtocart(lblNode2, numericUpDown2);
            }
        }

        //add to meal or cart based on the function of the main form
        //checks to see if there is food in the food db which if there isn't 
        //the labels would be set to - and it would do nothing
        //if function is set to 1 add to meal if its 2 then add to cart
        private void button8_Click(object sender, EventArgs e)
        {
            if (lblNode3.Text != "-" && function == 1)
            {
                addMeal(lblNode3, numericUpDown3);
            }
            if (lblNode3.Text != "-" && function == 0)
            {
                addtocart(lblNode3, numericUpDown3);
            }
        }
        //add to meal or cart based on the function of the main form
        //checks to see if there is food in the food db which if there isn't 
        //the labels would be set to - and it would do nothing
        //if function is set to 1 add to meal if its 2 then add to cart
        private void button9_Click(object sender, EventArgs e)
        {
            if (lblNode4.Text != "-" && function == 1)
            {
                addMeal(lblNode4, numericUpDown4);
            }
            if (lblNode4.Text != "-" && function == 0)
            {
                addtocart(lblNode4, numericUpDown4);
            }
        }
        //add to meal or cart based on the function of the main form
        //checks to see if there is food in the food db which if there isn't 
        //the labels would be set to - and it would do nothing
        //if function is set to 1 add to meal if its 2 then add to cart
        private void button11_Click(object sender, EventArgs e)
        {
            if (lblNode5.Text != "-" && function == 1)
            {
                addMeal(lblNode5, numericUpDown5);
            }
            if (lblNode5.Text != "-" && function == 0)
            {
                addtocart(lblNode5, numericUpDown5);
            }
        }
        //add to meal or cart based on the function of the main form
        //checks to see if there is food in the food db which if there isn't 
        //the labels would be set to - and it would do nothing
        //if function is set to 1 add to meal if its 2 then add to cart
        private void button10_Click(object sender, EventArgs e)
        {
            if (lblNode6.Text != "-" && function == 1)
            {
                addMeal(lblNode6, numericUpDown6);
            }
            if (lblNode6.Text != "-" && function == 0)
            {
                addtocart(lblNode6, numericUpDown6);
            }
        }

        //quick adds recent item to meal
        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text != "-")
            addMeal(button1, 1);
            viewMeal();
        }
        //quick adds recent item to meal
        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text != "-")
                addMeal(button2, 1);
            viewMeal();
        }
        //quick adds recent item to meal
        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.Text != "-")
                addMeal(button3, 1);
            viewMeal();
        }
        //quick adds recent item to meal
        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text != "-")
                addMeal(button4, 1);
            viewMeal();
        }
        //quick adds recent item to meal
        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text != "-")
                addMeal(button5, 1);
            viewMeal();
        }
        //show current user details form if changes are made refresh main form
        private void button18_Click(object sender, EventArgs e)
        {
            this.TopMost = false;
            CUDS form2 = new CUDS(m, CUDS.currentuser);
            form2.ShowDialog();
            if (changesmade)
                showmain();
            this.TopMost = true;

        }
        //shows recipes browser if items are in the cart recipes are rated if not all instock status is checked 
        //and recipes aren't rated
        private void button19_Click(object sender, EventArgs e)
        {
            this.TopMost = false;
            if (cartc > -1)
                rateRecipes1();            
            else
            {
                recipebrowser rb = new recipebrowser(foods, m);
                rb.ShowDialog();
            }
            this.TopMost = true;
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            
            //lets the form accept key events
            this.KeyPreview = true;
            //refresh main form and set default sort
            showmain();
            //showmain("SELECT * FROM tblFood where quantity > 0 ORDER BY foodname"); 

            // hide down buttons
            if (numericUpDown1.Value == 1)
                button24.Visible = false;
            if (numericUpDown2.Value == 1)
                button25.Visible = false;
            if (numericUpDown3.Value == 1)
                button27.Visible = false;
            if (numericUpDown4.Value == 1)
                button29.Visible = false;
            if (numericUpDown5.Value == 1)
                button31.Visible = false;
            if (numericUpDown6.Value == 1)
                button33.Visible = false;


        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            bool nonNumberEntered; //input wasn't a number

            // Initialize the flag to false.
            nonNumberEntered = false;
            // Determine whether the keystroke is a number from the top of the keyboard.
            //if (e.KeyCode == Keys.Enter) { MessageBox.Show("Enter pressed", "Attention"); }
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                // Determine whether the keystroke is a number from the keypad.
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    // Determine whether the keystroke is a backspace.
                    if (e.KeyCode != Keys.Back)
                    {
                        // A non-numerical keystroke was pressed.
                        // Set the flag to true and evaluate in KeyPress event.
                        nonNumberEntered = true;
                    }
                }
            }
            //If shift key was pressed, it's not a number.
            if (Control.ModifierKeys == Keys.Shift)
            {
                nonNumberEntered = true;
            }
            // Check for the flag being set in the KeyDown event.
            //if the key pressed was a letter
            if (nonNumberEntered == true)
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }

            if (nonNumberEntered == false)
            {
                //append the key to the end of the input collecting string
                sKey += (char)e.KeyValue;
                //check keyed length
                int sKeyLen = sKey.Length;
                //if 12 then whole upc was entered call scanner form and reset key
                if (sKeyLen == 12)
                {
                    //this.TopMost = false;
                    foodaddscanner form4 = new foodaddscanner(sKey, m);
                    form4.ShowDialog();
                    sKey = "";
                    //this.TopMost = true;
                }
            }
        }
        //used to dec qty qty of food item
        void downclick(NumericUpDown n, Button b, Button b2)
        {
            if (n.Value > 1)
                n.Value--;
            if (n.Value == 1)
                b.Visible = false;
            //if value is less than the max show this button
            if (n.Value < n.Maximum)
                b2.Visible = true;
        }
        //used to inc qty of food item
        void upclick(NumericUpDown n, Button b, Button b2)
        {
            
            //if value is equal to the max hide this button
            if (n.Value == n.Maximum)
                b2.Visible = false;
            // or else inc the count
            else
            n.Value++;

            if (n.Value > 1)
                b.Visible = true;
        }

        //switched between meal and cart view
        public void mealcartswitch()
        {
            //if current view is Meal
            if (function == 0)
            {
                //show cart view
                lblCart.Text = "Shopping List View";
                cmdCheckOut.Text = "Print!";
                //hide Meal edit buttons
                button35.Visible = false;
                button36.Visible = false;
                button17.Visible = false;
                //show cart in listbox                
                viewCart();
                //up 15 26 28 30 32 34
                //down 24 25 27 29 31 33
                //hide up buttons
                button15.Visible = false;
                button26.Visible = false;
                button28.Visible = false;
                button30.Visible = false;
                button32.Visible = false;
                button34.Visible = false;
                //hide down buttons
                button24.Visible = false;
                button25.Visible = false;
                button27.Visible = false;
                button29.Visible = false;
                button31.Visible = false;
                button33.Visible = false;
                //hide recipe button
                button19.Visible = false;

            }
        
            //if current view is Shopping List
            if (function == 1)
            {
                //show meal view
                lblCart.Text = "Current Meal View";
                cmdCheckOut.Text = "Eat!";
                //show Meal edit buttons
                button35.Visible = true;
                button36.Visible = true;
                button17.Visible = true;
                //show Meal in listbox
                viewMeal();
                //show up buttons
                button15.Visible = true;
                button26.Visible = true;
                button28.Visible = true;
                button30.Visible = true;
                button32.Visible = true;
                button34.Visible = true;
                //hide down buttons
                button24.Visible = false;
                button25.Visible = false;
                button27.Visible = false;
                button29.Visible = false;
                button31.Visible = false;
                button33.Visible = false;
                //show recipe button
                button19.Visible = true;
                
            }

        }
        //used to enter new qty for meal item
        private void button17_Click(object sender, EventArgs e)
        {
            this.TopMost = false;
            if (lstCart.SelectedIndex != -1)
            {
                if (cartc >= 0)
                    editMeal();
            }
            else
                MessageBox.Show("Nothing in meal!");
            this.TopMost = true;
        }
        //used to remove item from meal or cart
        //function 1 is meal 0 is cart
        //checks to see if something is selected in listbox before calling methods
        private void button21_Click(object sender, EventArgs e)
        {
            if (lstCart.SelectedIndex == -1)
                MessageBox.Show("Nothing Selected!");
            if (lstCart.SelectedIndex != -1 && function == 1)
            {
                if (cartc >= 0)
                    deleteMeal();
                else
                    MessageBox.Show("Meal Empty !! ");
            }
            if (lstCart.SelectedIndex != -1 && function == 0)
            {
                if (shoppingcartcount >= 0)
                    deleteCart();
                else
                    MessageBox.Show("Shopping List Empty !! ");
            }
 

        }
//
        private void button23_Click(object sender, EventArgs e)
        {
            if (cartc >= 0 && function == 1)
            {
                checkOut();
                showmain();
            }

            if (shoppingcartcount >= 0 && function == 0)
            {
                checkOutCart();                
                showmain();
            }

            if (cartc < 0 && function == 1)
                MessageBox.Show("Nothing in meal!");

            if (shoppingcartcount < 0 && function == 0)
                MessageBox.Show("Nothing in Shopping List!");

        }

        private void button16_Click(object sender, EventArgs e)
        {
            da.Update(ds);
            Close();
        }


        private void pictureBox100_Click(object sender, EventArgs e)
        {
            this.TopMost = false;
            if (lblNode1.Text != "-")
            {
                foodadd fi = new foodadd(m, lblNode1.Text, lblNode1, numericUpDown1);
                fi.ShowDialog();
            }
            this.TopMost = true;
        }

        private void pictureBox200_Click(object sender, EventArgs e)
        {
            if (lblNode2.Text != "-")
            {
                foodadd fi = new foodadd(m, lblNode2.Text, lblNode2, numericUpDown2);
                fi.ShowDialog();
            }
        }

        private void pictureBox300_Click(object sender, EventArgs e)
        {
            if (lblNode3.Text != "-")
            {
                foodadd fi = new foodadd(m, lblNode3.Text, lblNode3, numericUpDown3);
                fi.ShowDialog();
            }
        }

        private void pictureBox400_Click(object sender, EventArgs e)
        {
            if (lblNode4.Text != "-")
            {
                foodadd fi = new foodadd(m, lblNode4.Text, lblNode4, numericUpDown4);
                fi.ShowDialog();
            }
        }

        private void pictureBox500_Click(object sender, EventArgs e)
        {
            if (lblNode5.Text != "-")
            {
                foodadd fi = new foodadd(m, lblNode5.Text, lblNode5, numericUpDown5);
                fi.ShowDialog();
            }
        }

        private void pictureBox600_Click(object sender, EventArgs e)
        {
            if (lblNode6.Text != "-")
            {
                foodadd fi = new foodadd(m, lblNode6.Text, lblNode6, numericUpDown6);
                fi.ShowDialog();
            }
        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            upclick(numericUpDown1, button24, button15);
        }

        private void button24_Click(object sender, EventArgs e)
        {
            downclick(numericUpDown1, button24, button15);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            upclick(numericUpDown2, button25, button26);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            downclick(numericUpDown2, button25, button26);
        }

        

        private void button28_Click(object sender, EventArgs e)
        {
            upclick(numericUpDown3, button27, button28);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            downclick(numericUpDown3, button27, button28);
        }

        private void button30_Click(object sender, EventArgs e)
        {
            //4, 29
            upclick(numericUpDown4, button29, button30);
        }

        private void button29_Click(object sender, EventArgs e)
        {
            downclick(numericUpDown4, button29, button30);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            //5 31
            upclick(numericUpDown5, button31, button32);
        }

        private void button31_Click(object sender, EventArgs e)
        {
            downclick(numericUpDown5, button31, button32);
        }

        private void button34_Click(object sender, EventArgs e)
        {
            //6 33
            upclick(numericUpDown6, button33, button34);
        }

        private void button33_Click(object sender, EventArgs e)
        {
            downclick(numericUpDown6, button33, button34);
        }

        private void button36_Click(object sender, EventArgs e)
        {
            if (lstCart.SelectedIndex != -1)
            {
                if (cartc >= 0)
                    editMealUpDown(1);
            }
            
        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (lstCart.SelectedIndex != -1)
            {
                if (cartc >= 0)
                    editMealUpDown(0);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //show tells the showmethod what to show
            
            //combobox sets string that tells show method which string to use for sql command
            if (comboBox1.SelectedIndex == 0)
            {
                show = "SELECT * FROM tblFood where quantity > 0 ORDER BY quantity DESC";
                function = 1;
                mealcartswitch();
            }
            if (comboBox1.SelectedIndex == 1)
            {
                show = "SELECT * FROM tblFood INNER JOIN tblUPC ON tblFood.foodname = tblUPC.foodname where quantity > 0 ORDER BY calories DESC";
                function = 1;
                mealcartswitch();
                showmain(show, show);
            } 
            if (comboBox1.SelectedIndex == 2)
            {
                show = "SELECT * FROM tblFood where quantity > 0 ORDER BY foodname ASC";
                function = 1;
                mealcartswitch();
            }
            if (comboBox1.SelectedIndex == 3)
            {
                show = "SELECT * FROM tblFood where quantity <= Depletedcount ORDER BY foodname ASC";
                function = 0;
                mealcartswitch();
            }
            if (comboBox1.SelectedIndex == 4)
            {
                show = "SELECT * FROM tblFood where quantity <= Depletedcount ORDER BY quantity DESC";
                function = 0;
                mealcartswitch();
            }
            showmain(show);

        }

        private void picUserIcon_Click(object sender, EventArgs e)
        {
            this.TopMost = false;
            CUDS form2 = new CUDS(m, CUDS.currentuser);
            form2.ShowDialog();
            if (changesmade)
                showmain();
            this.TopMost = true;
        }

        private void button37_Click(object sender, EventArgs e)
        {
            if (button37.Text != "-")
                addMeal(button37, 1);
            viewMeal();
        }

        private void button38_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            foodbrowser fb = new foodbrowser(m);
            fb.ShowDialog();
        }

    }



}
