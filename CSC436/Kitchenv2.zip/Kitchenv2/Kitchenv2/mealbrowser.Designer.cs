﻿namespace Kitchenv2
{
    partial class mealbrowser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button21 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(116, 149);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(81, 24);
            this.button21.TabIndex = 295;
            this.button21.Text = "Remove";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(281, 95);
            this.listBox1.TabIndex = 294;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(11, 149);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(81, 24);
            this.button17.TabIndex = 293;
            this.button17.Text = "Edit Meal";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(212, 149);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(81, 24);
            this.button16.TabIndex = 292;
            this.button16.Text = "Check Out";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // meal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(313, 199);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Name = "meal";
            this.Text = "meal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
    }
}