﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Kitchenv2
{
    class Link
    {
        public string linkString; // string the link is holding

        public int linkNumber; //number of the link 

        public Link next; // next link in list

        public Link previous; // previous link in list

        public int max; //quantity of food item

        public bool hasicon; //does link have image

        public Bitmap icon; //foodicon

        public Link(Form1.fooditem f, int l)
        {
            //takes in the string the link will hold and sets it to linkstring
            linkString = f.name;
            max = f.quantity;
            linkNumber = l;
            previous = null;
            next = null;
            if (f.hasicon)
            {
                hasicon = true;
                icon = f.icon;                
            }
        }
        //returns the link string for display reasons
        public string displayLink()
        {
            return linkString;
        }
        public int getLinkNumber()
        {
            return linkNumber;
        }
        public bool iconpresent()
        {
            if (hasicon)
                return true;
            else
                return false;

        }
        public bool checkLinkNumber(int num)
        {
            if (num == linkNumber)
            return true;
            else 
                return false;
        }
        public bool isNext()
        {
            if (next != null)
                return true;
            else
                return false;
        }

    }
}
