// Implementation file JarType.cpp
// This module exports a JarType ADT
//============================================

#include "stdafx.h"
#include "JarType.h"
#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

// CONSTRUCTORS

JarType::JarType ()    // default constructor
// POST: #units in jar is 0
{  
	numUnits = 0;
}

JarType::JarType (int n)
// PRE: n >= 0
// POST: #units in jar is 0
{  
	numUnits = n;
}

int JarType::Quantity () const
// PRE: n>= 0
// POST: returns number of units assigned to instance of JarType
{  
	return numUnits;
}

JarType JarType::operator- (const JarType& jar2) const
// PRE: explicitly passed JarType jar2 to be subtracted from implicitly passed JarType
// POST: returns JarType newjar resultant data back to implicitly passed JarType
{
	JarType newjar;
	newjar.numUnits = numUnits - jar2.numUnits;
	return newjar;
}

JarType JarType::operator/ (const JarType& jar2) const
// PRE: explicitly passed JarType jar2 to be divided into implicitly passed JarType
// POST: returns JarType newjar resultant data back to implicitly passed JarType
{
	JarType newjar;
	newjar.numUnits = numUnits / jar2.numUnits;
	return newjar;
}

bool JarType::operator== (const JarType& jar2) const
// PRE: explicitly passed JarType jar2 to be evaluated for equality against implicitly passed JarType
// POST: returns boolean true/false resultant data
{
	return ( numUnits == jar2.numUnits );
}

bool JarType::operator< (const JarType& jar2) const
// PRE: n>= 0
// POST: returns number of units assigned to instance of JarType
{
	return ( numUnits < jar2.numUnits );
}

bool JarType::operator> (const JarType& jar2) const
// PRE: n>= 0
// POST: returns number of units assigned to instance of JarType
{
	return ( numUnits > jar2.numUnits );
}

bool JarType::operator!= (const JarType& jar2) const
// PRE: explicitly passed JarType jar2 to be evaluated for inequality against implicitly passed JarType
// POST: returns boolean true/false resultant data
{
	return ( numUnits != jar2.numUnits );
}

const JarType operator+ (const JarType& jar1, const JarType& jar2)
// PRE: explicitly passed JarType jar1 to be added to explicitly passed JarType jar2
// POST: returns JarType newjar resultant data back to pass location
{
	JarType newjar;
	newjar = jar1.numUnits + jar2.numUnits;
	return newjar;
}

const JarType operator* (const JarType& jar1, const JarType& jar2)
// PRE: explicitly passed JarType jar1 to be multiplied by explicitly passed JarType jar2
// POST: returns JarType newjar resultant data back to pass location
{
	JarType newjar;
	newjar = jar1.numUnits * jar2.numUnits;
	return newjar;
}

ostream& operator<< (ostream& out1, JarType& jar1)
// PRE: explicitly passed JarType jar1 to have numUnits data output to screen through 
//	explicitly passed output stream object ostream out1
// POST: returns explicitly passed output stream object ostream out1 back to pass location to be displayed
{
	out1 << jar1.numUnits;
	return out1;
}

istream& operator>> (istream& in1, JarType& jar1)
// PRE: explicitly passed JarType jar1 to have numUnits data input into from user through 
//	explicitly passed input stream object istream in1
// POST: returns explicitly passed input stream object istream in1 back to pass location to be stored
{
	in1 >> jar1.numUnits;
	return in1;
}