/*  I have chosen to include the JarType implementation within the JarType.cpp file
//  and include the JarType.h header file.  JarType.h contains all the function prototypes
	and p3main.cpp contains all of the function implementations.

	Cody Adams
	CSC 275
	03/02/07
	Program Assignment #3

*/
#include "stdafx.h"
#include "JarType.h"
#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

void main()
{	
	//Output header containing author information
	cout << "Cody Adams" << endl << "CSC275" << endl << "03/05/07" << endl << "Program Assignment #3" << endl;
	cout << endl;

	JarType Jar1, Jar2 (15), Jar3 (3);

	cout << "Testing addition of two jars: ";
	Jar1 = Jar2 + Jar3;
	cout << "  Jar2 = " << Jar2.Quantity() << " + Jar3 = " << Jar3.Quantity()
		<< " Result is Jar1 = "  << Jar1.Quantity() << endl;
	cout << "\nTesting adding an integer to a jar object: ";
	Jar1 = Jar2 + 5;
	cout << "  Jar2 = " << Jar2.Quantity() << " + 5  Result is Jar1 = "  << Jar1.Quantity()<< endl;

	cout << "\nTesting adding a jar object to an integer: ";
	Jar1 = 13 + Jar2;
	cout << " 13 + Jar2 = " << Jar1.Quantity()<< endl<< endl;

	cout << "Testing subtraction of two jars: ";
	Jar1 = Jar2 - Jar3;
	cout << "  Jar2 = " << Jar2.Quantity() << " - Jar3 = " << Jar3.Quantity()
		<< " Result is Jar1 = "  << Jar1.Quantity() << endl<< endl;
	cout << "Testing Multiplication of two jars: ";
	Jar1 = Jar2 * Jar3;
	cout << "  Jar2 = " << Jar2.Quantity() << " * Jar3 = " << Jar3.Quantity()
		<< " Result is Jar1 = "  << Jar1.Quantity() << endl<< endl;

	cout << "Testing Division of two jars: ";
	Jar1 = Jar2 / Jar3;
	cout << "  Jar2 = " << Jar2.Quantity() << " / Jar3 = " << Jar3.Quantity()
		<< " Result is Jar1 = "  << Jar1.Quantity() << endl;

	cout << "\nRelational operators with  Jar1 = " << Jar1.Quantity()
		<< "  and Jar2 = " << Jar2.Quantity()  << endl;

	cout << "Testing < operator: ";
	if ( Jar1 < Jar2 )
		cout << "Jar1 < Jar2\n";
	else
		cout << "Jar1 not less than Jar2\n";

	cout << "Testing != operator: ";
	if ( Jar1 != Jar2)
		cout << "Jar1 NOT equal to Jar2\n";
	else
		cout << "Jar1 equals Jar2\n";

	cout << "Testing > operator: ";
	if ( Jar1 > Jar2)
		cout << "Jar1 > Jar2\n";
	else
		cout << "Jar1 NOT > Jar2\n";

	cout << "\nReading in data to a JarType, please enter integer data: ";
	cin  >> Jar1;
	cout << "\nData read and assigned to Jar1 was: ";
	cout << Jar1.Quantity() ;

	cout << "\nTesting output operation << Jar1 = " << Jar1 
		<< "   Jar2 = " << Jar2 << "  Jar3=  " << Jar3 << endl;

	cout << "\n\nTesting >> and << operations again\nEnter two integers for Jar2 & Jar3: ";
	cin >> Jar2 >> Jar3;
	cout << "\n Jar2 = "<< Jar2 << "  Jar3 =  " << Jar3 << endl;

} // end main