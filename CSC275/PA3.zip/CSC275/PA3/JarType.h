/*
	Cody Adams
	CSC 275
	03/02/07
	Program Assignment #3
	JarType.h header file with function prototypes
*/

using namespace std;
#include <iostream>


class JarType 
{

  
public:
		
	// CONSTRUCTORS
	
	JarType ();
	// POST: #units in jar is 0

	JarType (int n);
	// POST: #units in jar is n

	// CONSTANT member function allow you to view data without modification
	int Quantity () const;
	// PRE:  n>= 0
	// POST: returns number of units assigned to instance of JarType
	
	JarType operator- () const;

	JarType operator- (const JarType& jar2) const;
	// PRE: explicitly passed JarType jar2 to be subtracted from implicitly passed JarType
	// POST: returns JarType newjar resultant data back to implicitly passed JarType

	JarType operator/ (const JarType& jar2) const;
	// PRE: explicitly passed JarType jar2 to be divided into implicitly passed JarType
	// POST: returns JarType newjar resultant data back to implicitly passed JarType

	bool operator== (const JarType& jar2) const;
	// PRE: explicitly passed JarType jar2 to be evaluated for equality against implicitly passed JarType
	// POST: returns boolean true/false resultant data

	bool operator< (const JarType& jar2) const;
	// PRE: n>= 0
	// POST: returns number of units assigned to instance of JarType

	bool operator> (const JarType& jar2) const;
	// PRE: n>= 0
	// POST: returns number of units assigned to instance of JarType

	bool operator!= (const JarType& jar2) const;
	// PRE: explicitly passed JarType jar2 to be evaluated for inequality against implicitly passed JarType
	// POST: returns boolean true/false resultant data

	friend const JarType operator+ (const JarType& jar1, const JarType& jar2);
	// PRE: explicitly passed JarType jar1 to be added to explicitly passed JarType jar2
	// POST: returns JarType newjar resultant data back to pass location

	friend const JarType operator* (const JarType& jar1, const JarType& jar2);
	// PRE: explicitly passed JarType jar1 to be multiplied by explicitly passed JarType jar2
	// POST: returns JarType newjar resultant data back to pass location
	
	friend ostream& operator<< (ostream& out1, JarType& jar1);
	// PRE: explicitly passed JarType jar1 to have numUnits data output to screen through 
	//	explicitly passed output stream object ostream out1
	// POST: returns explicitly passed output stream object ostream out1 back to pass location to be displayed

	friend istream& operator>> (istream& in1, JarType& jar1);
	// PRE: explicitly passed JarType jar1 to have numUnits data input into from user through 
	//	explicitly passed input stream object istream in1
	// POST: returns explicitly passed input stream object istream in1 back to pass location to be stored

private:
    //Class member that stores the integer portion of JarType 
	int  numUnits;

};
