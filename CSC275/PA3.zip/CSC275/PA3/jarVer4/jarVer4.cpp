#include "stdafx.h"
// JarVer4.cpp : This extends my JarType example by illustrating separating client code
//               from implementation.  Specification of class in file jar.h, while implementation
//               in file jar.cpp
#include<iostream>
#include "JarType.h"
using namespace std;

void main()
{
  JarType Jar1, Jar2 (5), MyJar = JarType (20);

cout<<"This is a program that tests the JarType class!"<< endl;
cout<<"Class defined in two external files jar.cpp & jar.h!"<< endl<< endl;
cout << "Jar1 = " << Jar1.getQuantity() <<endl;
cout << "Jar2 = " << Jar2.getQuantity() <<endl;
cout << "MyJar = " << MyJar.getQuantity() <<endl;

Jar2.setAdd (40);
Jar2.setAdd (15);
cout << "\nAfter calls to Jar2.setAdd Quantity = " << Jar2.getQuantity() << endl;


MyJar = Jar2;
cout << "After assigning Jar2 to MyJar = "<< MyJar.getQuantity() << endl;

/* The following code generates an error:
   error C2676: binary '==' : 'JarType' does not define this operator or
   a conversion to a type acceptable to the predefined operator

if ( MyJar == Jar2)
   cout << "\nWith == test MyJar & Jar2 equal\n";
 else
   cout << "\nWith == test MyJar & Jar2 NOT EQUAL\n";
*/

}
