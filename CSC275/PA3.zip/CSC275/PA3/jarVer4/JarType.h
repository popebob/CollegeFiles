#pragma once

class JarType
{
  public:
    // CONSTRUCTORS
    	JarType(void);
    // POST: #units in jar is 0

    JarType (int n);
    // POST: #units in jar is n

  //MODIFICATION member functions
    void setAdd(int n);
    // PRE:  n>= 0
    // POST: n units have been added to jar

  // CONSTANT member function allow you to view data without modification
    int getQuantity () const;
  // PRE:  n>= 0
  // POST: returns number of units assigned to instance of JarType

  private:
     int  numUnits;
  };