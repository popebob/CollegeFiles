// jarVer1.cpp :
//   In the original version a member function named InitToEmpty() must be called to initialize
//  a jar object.
//

#include "stdafx.h"
#include<iostream>
using namespace std;

class JarType {
  public:
  // MODIFICATION member functions
    void  InitToEmpty();
    // POST: #units in jar is 0
    // NOTE:  This routine must be called prior to
    //        Add or Quantity.

    void setAdd(int n);
    // PRE: InitToEmpty has been invoked at least once && n>= 0
    // POST: n units have been added to jar

  // CONST member functions
    int getQuantity () const;
  // PRE: InitToEmpty has been invoked at least once && n>= 0
  // POST: Gives view of data, without any change.

  private:
     int  numUnits;
  };


void main()
{
  JarType Jar1, Jar2, MyJar;
  int amount;

  Jar1.InitToEmpty();
  amount = Jar1.getQuantity();

  cout<<"Version one of JarType class, test program!"<< endl;
  cout << "\nAfter call to Jar1.InitToEmpty amount = " << amount <<endl;

  Jar2.InitToEmpty();
  Jar2.setAdd (40);
  Jar2.setAdd (15);
  cout << "\nAfter calls to  Jar2.setAdd (40); & Jar2.Add (15); getQuantity = " << Jar2.getQuantity() << endl;

  MyJar.InitToEmpty();
  MyJar = Jar2;
  amount = MyJar.getQuantity();

  cout << "\nAfter assignment, MyJar = Jar2; MyJar amount = "<< amount << endl;

}

   // Public member functions of class

    void  JarType::InitToEmpty()
    // POST: #units in jar is 0
    // NOTE:  This routine must be called prior to
    //        Add or Quantity.
    {  numUnits = 0;
    }

    void JarType::setAdd(int n)
    // PRE: InitToEmpty has been invoked at least once && n>= 0
    // POST: n units have been added to jar
    { numUnits += n;
    }

   // CONSTANT member functions
    int JarType::getQuantity () const
   // PRE: InitToEmpty has been invoked at least once && n>= 0
   // POST: Gives view of data, without any change.
    {  return numUnits;
    }


