// jarClass.cpp : In this second version of the JarType class we have removed the member function
//  InitToEmpty(), and provided constructors to initialize data.
//
//  Also introduced is the concept of overloaded constructors since we have defined two, one with no
//  arguments, and the second constructor takes one argument.

#include "stdafx.h"
#include<iostream>
using namespace std;

class JarType {
  public:
   // CONSTRUCTORS
    JarType();      // default constructor
    // POST: #units in jar is 0

    JarType(int n); 
    // POST: #units in jar is n and n >=0

  // MODIFICATION member functions
    void setAdd(int n);
    // PRE: InitToEmpty has been invoked at least once && n>= 0
    // POST: n units have been added to jar

  // CONST member functions which allow you to view data
    int getQuantity () const ;
	

  private:
     int  numUnits;
  };

void main()
{
JarType Jar1, Jar2 (5), MyJar = JarType (20);

cout<<"Second version of JarType class with constructors, tested by this program!"<< endl;
cout << "Jar1 = " << Jar1.getQuantity() <<endl;
cout << "Jar2 = " << Jar2.getQuantity() <<endl;
cout << "MyJar = " << MyJar.getQuantity() <<endl<<endl;

MyJar = Jar2;
cout << "After assigning MyJar = Jar2; MyJar.Quantity = "<< MyJar.getQuantity() << endl<<endl;
Jar2.setAdd (40);
Jar2.setAdd (15);
cout << "After calls to Jar2.setAdd (40); & Jar2.setAdd (15); Jar2.Quantity = " << Jar2.getQuantity() << endl;

}

   // Public member functions of class
    JarType::JarType() {
		numUnits = 0;
	}     // default constructor
    // POST: #units in jar is 0

    JarType::JarType(int n) 
	  { numUnits = n; }
    // POST: #units in jar is n and n >=0

    void JarType::setAdd(int n)
    // PRE: InitToEmpty has been invoked at least once && n>= 0
    // POST: n units have been added to jar
    { numUnits += n;
    }

   // CONSTANT member functions
    int JarType::getQuantity () const
   // PRE: InitToEmpty has been invoked at least once && n>= 0
   // POST: Gives view of data, without any change.
    {  return numUnits;
    }




