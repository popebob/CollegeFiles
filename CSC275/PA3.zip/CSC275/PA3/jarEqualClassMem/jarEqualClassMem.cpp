// jarEqualClassMem.cpp : Defines the entry point for the console application.
//  In this example  the JarType class defines an isEqual member function as 
//  a class member.

#include "stdafx.h"
#include<iostream>
#include<conio.h> 
using namespace std;
#include "JarType.h"

void main()
{
JarType Jar1, Jar2 (5), MyJar = JarType (20);

cout<<"\n\nThis is a program that tests the JarType class!"<< endl;
cout << "Jar1 = " << Jar1.getQuantity() <<endl;
cout << "Jar2 = " << Jar2.getQuantity() <<endl;
cout << "MyJar = " << MyJar.getQuantity() <<endl;

Jar2.setAdd (40);
Jar2.setAdd (15);
cout << "After calls to Jar2.setAdd (40; & Jar2.setAdd (15); Jar2 getQuantity: " << Jar2.getQuantity() << endl;

MyJar = Jar2;
cout << "After assigning Jar2 to MyJar Quantity of MyJar is: "<< MyJar.getQuantity() << endl;

/*
if (MyJar == Jar2)
	 cout << endl<< "MyJar == Jar2, result is TRUE"<< endl;
else
     cout << endl<< "MyJar == Jar2, result is TRUE"<< endl;
*/

if (Jar1.isEqual ( Jar2) )
	 cout << endl<< "Jar1.isEqual ( jar2) result is TRUE"<< endl;
else
     cout << endl<< "Jar1.isEqual ( jar2) result is TRUE"<< endl;

}
