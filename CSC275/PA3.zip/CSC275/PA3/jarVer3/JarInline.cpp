// This version JarVer3, defines all of the member functions inline.  This is possible, because the
// implementation code is just one statement.  It would not be appropriate to define a more complex member function
// inline.
//

#include "stdafx.h"
#include<iostream>
using namespace std;

// All of these member functions are defined inline since they are
// only one instruction each.

class JarType {
  public:
   // CONSTRUCTORS
    JarType() { numUnits = 0; }     // default constructor
    // POST: #units in jar is 0

    JarType(int n) { numUnits = n; }
    // POST: #units in jar is n and n >=0

  // MODIFICATION member functions
    void setAdd(int n) { numUnits += n; }
    // PRE: InitToEmpty has been invoked at least once && n>= 0
    // POST: n units have been setAdded to jar

  // CONST member functions which allow you to view data
    int getQuantity () const  { return numUnits; }
  // PRE: InitToEmpty has been invoked at least once && n>= 0

  private:
     int  numUnits;
  };

void main()
{
JarType Jar1, Jar2 (5), MyJar = JarType (20);
int amount;

cout<<"Testing JarType which includes constructors and \ninline implementations of class!"<< endl;
cout << "Jar1 = " << Jar1.getQuantity() <<endl;
cout << "Jar2 = " << Jar2.getQuantity() <<endl;
cout << "MyJar = " << MyJar.getQuantity() <<endl;

Jar2.setAdd (40);
Jar2.setAdd (15);
cout << "\nAfter calls to Jar2.setAdd (40); & Jar2.setAdd (15); Quantity = " << Jar2.getQuantity() << endl;


MyJar = Jar2;
cout << "After assigning MyJar = Jar2; Quantity= "<< MyJar.getQuantity() << endl;

}