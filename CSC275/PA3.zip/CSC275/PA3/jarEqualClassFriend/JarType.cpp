#include "StdAfx.h"
#include ".\jartype.h"

// This module exports a JarType ADT
//============================================
// Private members of class:  int numUnits
// CONSTRUCTORS
    JarType:: JarType ()    // default constructor
    // POST: #units in jar is 0
   {  numUnits = 0;
    }

     JarType:: JarType (int n)
    // PRE: n >= 0
    // POST: #units in jar is 0
   {  numUnits = n;
   }

    void JarType::  setAdd ( int n)
    // PRE:  n >= 0
    // POST: n units have been added to jar
    { numUnits += n;
    }

    int JarType::getQuantity () const
  // PRE: n>= 0
  // POST: returns number of units assigned to instance of JarType
    {  return numUnits;
    }

   bool isEqual ( /* in */ JarType firstJar, JarType secondJar ) 
  // POST: Returns TRUE if this jar and otherJar contain the same # units.
	{
		  int num1 = firstJar.numUnits;
		  int num2 = secondJar.numUnits;

          return ( num1 == num2  );
    }

