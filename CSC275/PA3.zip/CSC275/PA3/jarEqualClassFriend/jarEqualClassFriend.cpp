// jarEqualClassFriend.cpp : Defines the entry point for the console application.

#include "stdafx.h"
#include<iostream>
#include<conio.h> 
using namespace std;
#include "JarType.h"

void main()
{
JarType Jar1 (5), Jar2 (5);
JarType MyJar = JarType (20);

cout<<"\n\nThis is a program that tests the JarType class!"<< endl;
cout << "Jar1 = " << Jar1.getQuantity() <<endl;
cout << "Jar2 = " << Jar2.getQuantity() <<endl;


if (isEqual ( Jar1, Jar2) )
	 cout << "isEqual ( Jar1, Jar2) result is TRUE"<< endl;
else
     cout << "isEqual ( Jar1, Jar2)result is FALSE"<< endl;


cout <<endl << "MyJar = " << MyJar.getQuantity() << ", Jar2 = "<< Jar2.getQuantity() <<endl;
if (isEqual ( MyJar, Jar2) )
	 cout  << "isEqual (MyJar, Jar2) result is TRUE"<< endl;
else
     cout  << "isEqual (MyJar, Jar2)result is FALSE"<< endl;

Jar2.setAdd (40);
Jar2.setAdd (15);
cout << "\nAfter calls to Jar2.Add (40; & Jar2.Add (15);\nJar2 Quantity: " << Jar2.getQuantity() << endl;

MyJar = Jar2;
cout << "\nAfter assignment: MyJar = Jar2; \nQuantity of MyJar is: "<< MyJar.getQuantity() ;

/*
if (MyJar == Jar2)
	 cout << endl<< "MyJar == Jar2, result is TRUE"<< endl;
else
     cout << endl<< "MyJar == Jar2, result is FALSE"<< endl;
*/

if (isEqual ( MyJar, Jar2) )
	 cout << endl<< "isEqual (MyJar, Jar2) result is TRUE"<< endl;
else
     cout << endl<< "isEqual (MyJar, Jar2)result is FALSE"<< endl;

cout << endl;
}  // end main