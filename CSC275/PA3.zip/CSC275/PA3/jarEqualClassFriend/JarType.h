#pragma once

class JarType {
  public:
    // CONSTRUCTORS
    JarType ();
    // POST: #units in jar is 0

    JarType (int n);
    // POST: #units in jar is n

 
	//MODIFICATION member functions
    void setAdd(int n);
    // PRE:  n>= 0
    // POST: n units have been added to jar

  // CONSTANT member function allow you to view data without modification
    int getQuantity () const;
  // PRE:  n>= 0
  // POST: returns number of units assigned to instance of JarType

   friend bool isEqual ( /* in */ JarType firstJar, JarType secondJar );

   private:
     int  numUnits;
  };


