/*
	Cody Adams
	CSC 275
	03/02/07
	Program Assignment #3

*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cctype>
#include "stdafx.h"
#include "JarType.h" //Implementation file JarType.cpp; This module exports a JarType ADT

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{

	return 0;
}

// Public member functions of class
// CONSTRUCTORS
JarType::JarType ()    // default constructor
	// POST: #units in jar is 0
{  
	numUnits = 0;
	TotalJars ++;
}

JarType::JarType (int n)
	// PRE: n >= 0
	// POST: #units in jar is 0
{  
	numUnits = n;
	TotalJars ++;
}

void JarType::  void Add(int numUnits)
	// PRE:  n >= 0
	// POST: n units have been added to jar
	{ 
		this.numUnits += numUnits;
	}

int JarType::Quantity () const
// PRE: n>= 0
// POST: returns number of units assigned to instance of JarType
	{  
		return numUnits;
	}

bool JarType ::operator == ( JarType otherjar) const
	{
		return ( numUnits == otherjar.numUnits );
	}