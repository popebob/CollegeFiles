#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <cctype>
#include <queue>
#include "pageq.h"

int main()
{
    pageq PageQ;
    for ( int q = 0; q < 28; q++ )
		PageQ.add(q);
    PageQ.printQ();
    return 0;
}
