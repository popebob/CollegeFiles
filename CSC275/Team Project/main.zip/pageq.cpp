#include "StdAfx.h"
#include ".\pageq.h"
/*
PageQueue source code
Cody Adams
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <cctype>
#include <queue>

using namespace std;

/*
pageq � a queue class of page numbers, for occurances of a word in the book.
Minimum operations required for this class include:
	1.	constructor � make an empty queue
		**pageq()**
	2.	Qinsert (PageNum) � If PageNum is not in the queue, add  PageNum to the end of this queue.
		**add(int)**
	3.	PrintQ () � prints out from front to back the numbers in this queue.
		**printQ()**
	4.	destructor, if the queue is implemented as a dynamic data structure.
		**Maybe Not needed**
*/

void pageq::add(int pagenum)
{
    if ( pq.empty() )
   	{
        cout << "Pushing: " << pagenum << endl;
        pq.push(pagenum);
    }
    else if ( pagenum != pq.back() ) 
	{
        cout << "Pushing: " << pagenum << endl;
        pq.push(pagenum);
    }
}

void pageq::printQ()
{
    cout << endl << pq.size() << " occurences found" << endl;
	for (int x = 0; x < pq.size(); x++)
	{
      int temp;
      temp = pq.front();
      cout << pq.front() << ", ";
      pq.pop();
      pq.push(temp);
    }
	
}
