﻿Public Structure Employee
    Dim EmpName As String
    Dim Phone As String
    Dim Address As String
    Dim HoursWorked As Double
    Dim RegHours As Double
    Dim OTHours As Double
    Dim Rate As Double
    Dim Pay As Double
End Structure


